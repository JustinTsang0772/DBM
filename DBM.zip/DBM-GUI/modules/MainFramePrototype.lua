local L = DBM_GUI_L

local isRetail = DBM:IsRetail()

---@class DBMGUI
local DBM_GUI = DBM_GUI

local select, ipairs, mfloor, mmax, mmin = select, ipairs, math.floor, math.max, math.min
local strlower, strgsub, tsort, tconcat = string.lower, string.gsub, table.sort, table.concat
local CreateFrame, GameFontNormal, C_Timer = CreateFrame, GameFontNormal, C_Timer
local DBM = DBM

---@class DBMOptionsFrame: Frame
---@field tabs table
---@field searchClearButton Button
---@field searchCountText FontString
---@field LoadAndShowFrame fun(self: DBMOptionsFrame, subFrame: Frame)
local frame = CreateFrame("Frame", "DBM_GUI_OptionsFrame", UIParent, "NineSlicePanelTemplate")

local selectedPagePerTab = {}
local searchTextCache = {}
local cachedSearchQuery
local cachedSearchResults
local normalizedSearchCache = {}
local normalizedSearchCacheEntries = 0
local cachedListFrame
local cachedListScrollBar
local cachedContainerFOV
local cachedContainerScrollBar
local cachedPanelContainer
local cachedDropDown

local function resetSearchResultsCache()
	cachedSearchQuery = nil
	cachedSearchResults = nil
end

local function cacheNormalizedSearchValue(rawText, value)
	if normalizedSearchCacheEntries >= 256 then
		normalizedSearchCache = {}
		normalizedSearchCacheEntries = 0
	end
	if normalizedSearchCache[rawText] == nil then
		normalizedSearchCacheEntries = normalizedSearchCacheEntries + 1
	end
	normalizedSearchCache[rawText] = value
end

local function GetListFrame()
	if not cachedListFrame then
		local listFrame = _G[frame:GetName() .. "List"]
		if listFrame then
			cachedListFrame = listFrame
		end
	end
	return cachedListFrame
end

local function GetListScrollBar()
	if not cachedListScrollBar then
		local listFrame = GetListFrame()
		if listFrame then
			cachedListScrollBar = _G[listFrame:GetName() .. "ScrollBar"]
		end
	end
	return cachedListScrollBar
end

local function GetContainerFOV()
	if not cachedContainerFOV then
		local fov = _G["DBM_GUI_OptionsFramePanelContainerFOV"]
		if fov then
			cachedContainerFOV = fov
		end
	end
	return cachedContainerFOV
end

local function GetContainerScrollBar()
	if not cachedContainerScrollBar then
		local fov = GetContainerFOV()
		if fov then
			cachedContainerScrollBar = _G[fov:GetName() .. "ScrollBar"]
		end
	end
	return cachedContainerScrollBar
end

local function GetPanelContainer()
	if not cachedPanelContainer then
		local panel = _G["DBM_GUI_OptionsFramePanelContainer"]
		if panel then
			cachedPanelContainer = panel
		end
	end
	return cachedPanelContainer
end

local function GetDropDown()
	if not cachedDropDown then
		local dropdown = _G["DBM_GUI_DropDown"]
		if dropdown then
			cachedDropDown = dropdown
		end
	end
	return cachedDropDown
end

local function truncateTextWithEllipsis(fontString, text, maxWidth)
	text = text or ""
	fontString:SetText(text)
	if fontString:GetStringWidth() <= maxWidth then
		return text
	end

	local chars = {}
	for ch in text:gmatch("[%z\1-\127\194-\244][\128-\191]*") do
		chars[#chars + 1] = ch
	end
	if #chars == 0 then
		return text
	end

	local ellipsis = "..."
	fontString:SetText(ellipsis)
	if fontString:GetStringWidth() > maxWidth then
		return ""
	end

	local best = ellipsis
	local low, high = 1, #chars
	while low <= high do
		local mid = math.floor((low + high) / 2)
		local candidate = table.concat(chars, "", 1, mid) .. ellipsis
		fontString:SetText(candidate)
		if fontString:GetStringWidth() <= maxWidth then
			best = candidate
			low = mid + 1
		else
			high = mid - 1
		end
	end

	return best
end

local function normalizeSearchText(text)
	if not text then
		return ""
	end
	if DBM:issecretvalue(text) then
		return ""
	end
	local okText, rawText = pcall(tostring, text)
	if not okText or not rawText then
		return ""
	end
	local cached = normalizedSearchCache[rawText]
	if cached ~= nil then
		return cached
	end
	local ok, normalized = pcall(function()
		local value = rawText
		value = strgsub(value, "|c%x%x%x%x%x%x%x%x", "")
		value = strgsub(value, "|r", "")
		value = strgsub(value, "|T.-|t", " ")
		value = strgsub(value, "|H.-|h(.-)|h", "%1")
		value = strgsub(value, "<.->", " ")
		value = strgsub(value, "%s+", " ")
		return strlower(value:match("^%s*(.-)%s*$") or "")
	end)
	if ok and normalized then
		cacheNormalizedSearchValue(rawText, normalized)
		return normalized
	end
	cacheNormalizedSearchValue(rawText, "")
	return ""
end

local function safeGetText(control)
	if not control or not control.GetText then
		return nil
	end
	local ok, text = pcall(control.GetText, control)
	if ok and not DBM:issecretvalue(text) then
		return text
	end
	return nil
end


local function appendSearchText(parts, text)
	local normalized = normalizeSearchText(text)
	if normalized ~= "" then
		parts[#parts + 1] = normalized
	end
end

local function appendControlSearchText(parts, control)
	if control.mytype == "ability" then
		-- Search/index contract for ability groups:
		-- Use only precomputed control.searchText (static original title + static ID).
		-- Do NOT index visible title regions here, because they can include dynamic rename text.
		-- This keeps search cache stable and prevents rename strings from becoming search keys.
		appendSearchText(parts, control.searchText)
		return
	end
	appendSearchText(parts, control.text)
	appendSearchText(parts, safeGetText(control.textObj))
	appendSearchText(parts, safeGetText(control))
	if control.GetName then
		local name = control:GetName()
		if name then
			local textRegion = _G[name .. "Text"]
			appendSearchText(parts, safeGetText(textRegion))
			local titleRegion = _G[name .. "Title"]
			appendSearchText(parts, safeGetText(titleRegion))
			local titleTextRegion = _G[name .. "TitleText"]
			appendSearchText(parts, safeGetText(titleTextRegion))
		end
	end
	if control.GetNumRegions and control:GetNumRegions() > 0 then
		for _, region in ipairs({ control:GetRegions() }) do
			if region.GetObjectType and region:GetObjectType() == "FontString" then
				appendSearchText(parts, safeGetText(region))
			end
		end
	end
end

local function collectFrameSearchText(targetFrame, parts, visited, entries)
	if not targetFrame or visited[targetFrame] then
		return
	end
	visited[targetFrame] = true
	appendSearchText(parts, targetFrame.displayName)
	appendSearchText(parts, targetFrame.modId)

	appendControlSearchText(parts, targetFrame)

	local childParts = {}
	local childCount = targetFrame.GetNumChildren and targetFrame:GetNumChildren() or select("#", targetFrame:GetChildren())
	if childCount == 0 then
		return
	end
	for _, child in ipairs({ targetFrame:GetChildren() }) do
		for i = #childParts, 1, -1 do
			childParts[i] = nil
		end
		appendControlSearchText(childParts, child)
		if #childParts > 0 then
			local childText = tconcat(childParts, "\n")
			parts[#parts + 1] = childText
			entries[#entries + 1] = {
				control = child,
				text = childText
			}
		end
		collectFrameSearchText(child, parts, visited, entries)
	end
end

local function getFrameSearchData(targetFrame)
	if searchTextCache[targetFrame] then
		return searchTextCache[targetFrame]
	end
	local parts, entries = {}, {}
	collectFrameSearchText(targetFrame, parts, {}, entries)
	searchTextCache[targetFrame] = {
		fullText = tconcat(parts, "\n"),
		entries = entries
	}
	return searchTextCache[targetFrame]
end

function frame:InvalidateSearchCache(targetFrame)
	if targetFrame then
		searchTextCache[targetFrame] = nil
	else
		searchTextCache = {}
	end
	resetSearchResultsCache()
end

local function updateAbilityToggleTexture(abilityFrame)
	local toggleButton = _G[abilityFrame:GetName() .. "Button"]
	if toggleButton and toggleButton.toggle then
		toggleButton.toggle:SetNormalTexture(abilityFrame.hidden and 130838 or 130821) -- "Interface\\Buttons\\UI-PlusButton-UP", "Interface\\Buttons\\UI-MinusButton-UP"
		toggleButton.toggle:SetPushedTexture(abilityFrame.hidden and 130836 or 130820) -- "Interface\\Buttons\\UI-PlusButton-DOWN", "Interface\\Buttons\\UI-MinusButton-DOWN"
	end
end

local function expandParentsForControl(targetFrame, control)
	local parent = control and control:GetParent()
	local changed = false
	while parent and parent ~= targetFrame do
		if parent.mytype == "ability" and parent.hidden then
			parent.hidden = false
			updateAbilityToggleTexture(parent)
			changed = true
		end
		parent = parent:GetParent()
	end
	return changed
end

function frame:SetSearchQuery(query)
	query = normalizeSearchText(query)
	if self.searchQuery == query then
		return
	end
	self.searchQuery = query
	resetSearchResultsCache()
	local listFrame = GetListFrame()
	if listFrame then
		listFrame.offset = 0
		local scrollBar = GetListScrollBar()
		if scrollBar and scrollBar.SetValue then
			scrollBar:SetValue(0)
		end
	end
	self:UpdateMenuFrame()
end

function frame:SetSearchStatus(searching, count)
	if self.searchClearButton then
		self.searchClearButton:SetShown(searching)
	end
	if self.searchCountText then
		if searching then
			count = count or 0
			if count == 1 then
				self.searchCountText:SetText(L.SearchMatch:format(count))
			else
				self.searchCountText:SetText(L.SearchMatches:format(count))
			end
		else
			self.searchCountText:SetText("")
		end
	end
end

function frame:IsFrameSearchable(targetFrame, tabId)
	if tabId == DBM_GUI.Enums.Tabs.CORE or tabId == DBM_GUI.Enums.Tabs.TOOLS then
		return true
	end
	-- Only index frames once their UI has actually been built to avoid caching empty results
	if targetFrame.isLoaded then
		return true
	end
	if targetFrame.addonId and C_AddOns and C_AddOns.IsAddOnLoaded then
		-- Addon is loaded but only index the frame once it has child controls
		local childCount = targetFrame.GetNumChildren and targetFrame:GetNumChildren() or select("#", targetFrame:GetChildren())
		return C_AddOns.IsAddOnLoaded(targetFrame.addonId) and childCount > 0
	end
	local childCount = targetFrame.GetNumChildren and targetFrame:GetNumChildren() or select("#", targetFrame:GetChildren())
	return childCount > 0
end

function frame:GetSearchResults()
	local query = self.searchQuery
	if not query or query == "" then
		resetSearchResultsCache()
		return nil
	end
	if cachedSearchQuery == query and cachedSearchResults then
		return cachedSearchResults
	end
	local results, seen = {}, {}
	for tabId, tabData in ipairs(DBM_GUI.tabs) do
		for _, node in ipairs(tabData.buttons) do
			local targetFrame = node.frame
			if targetFrame and not seen[targetFrame] and not node.hidden and self:IsFrameSearchable(targetFrame, tabId) then
				seen[targetFrame] = true
				local data = getFrameSearchData(targetFrame)
				if data.fullText:find(query, 1, true) then
					local matchedControl
					for _, entry in ipairs(data.entries) do
						if entry.text:find(query, 1, true) then
							matchedControl = entry.control
							break
						end
					end
					results[#results + 1] = {
						frame = targetFrame,
						displayName = ("[%s] %s"):format((self.tabs[tabId] and self.tabs[tabId].name) or "?", targetFrame.displayName or "?"),
						tab = tabId,
						sortName = strlower(targetFrame.displayName or ""),
						matchControl = matchedControl
					}
				end
			end
		end
	end
	tsort(results, function(a, b)
		if a.tab == b.tab then
			return a.sortName < b.sortName
		end
		return a.tab < b.tab
	end)
	cachedSearchQuery = query
	cachedSearchResults = results
	return results
end

function frame:UpdateMenuFrame()
	local listFrame = GetListFrame()
	if not listFrame or not listFrame.buttons then
		return
	end
	local searching = self.searchQuery and self.searchQuery ~= ""
	local displayedElements = searching and self:GetSearchResults() or (self.tab and DBM_GUI.tabs[self.tab]:GetVisibleTabs() or {})
	self:SetSearchStatus(searching, #displayedElements)
	local bigList = mfloor((listFrame:GetHeight() - 8) / 18)
	local scrollBar = GetListScrollBar()
	if #displayedElements > bigList then
		scrollBar:Show()
		scrollBar:SetMinMaxValues(0, (#displayedElements - bigList) * 18)
	else
		scrollBar:Hide()
		scrollBar:SetValue(0)
	end
	for i = 1, #listFrame.buttons do
		local button = listFrame.buttons[i]
		if button._dbmWasLocked then
			button:UnlockHighlight()
			button._dbmWasLocked = nil
		end
		local element = displayedElements[i + (listFrame.offset or 0)]
		if not element or i > bigList then
			button:Hide()
			button:SetHeight(-1)
		else
			if searching then
				self:DisplayButton(button, element.frame, element.displayName, true, element.matchControl)
			else
				self:DisplayButton(button, element.frame)
			end
			if (searching and DBM_GUI.currentViewing or (self.tab and self.tabs[self.tab].selection)) == element.frame then
				button:LockHighlight()
				button._dbmWasLocked = true
			end
		end
	end
end

function frame:DisplayButton(button, element, displayName, hideToggle, matchControl)
	local depth = hideToggle and 1 or element.depth
	local haschilds = not hideToggle and element.haschilds
	local textLeft = (haschilds and 14 or 6) + 8 * depth
	button:Show()
	button:SetHeight(18)
	button.element = element
	button.searchMatchedControl = matchControl
	element.selectButton = button
	button.text:ClearAllPoints()
	button.text:SetPoint("LEFT", textLeft, 2)
	button.text:SetPoint("RIGHT", button, "RIGHT", -6, 2)
	button.text:SetJustifyH("LEFT")
	if button.text.SetWordWrap then
		button.text:SetWordWrap(false)
	end
	if button.text.SetNonSpaceWrap then
		button.text:SetNonSpaceWrap(false)
	end
	button.text:SetWidth(button:GetWidth() - textLeft - 6)
	button.toggle:ClearAllPoints()
	button.toggle:SetPoint("LEFT", 8 * depth - 2, 1)
	button.text:SetFontObject(haschilds and GameFontNormal or GameFontWhite)
	button.text:SetTextScale(0.9)
	if haschilds then
		button.toggle:SetNormalTexture(element.showSub and 130821 or 130838) -- "Interface\\Buttons\\UI-MinusButton-UP", "Interface\\Buttons\\UI-PlusButton-UP"
		button.toggle:SetPushedTexture(element.showSub and 130820 or 130836) -- "Interface\\Buttons\\UI-MinusButton-DOWN", "Interface\\Buttons\\UI-PlusButton-DOWN"
		button.toggle:Show()
	else
		button.toggle:Hide()
	end
	local fullDisplayName = displayName or element.displayName or ""
	button.text:SetText(truncateTextWithEllipsis(button.text, fullDisplayName, button:GetWidth() - textLeft - 6))
	button.text:Show()
end

function frame:HighlightSearchControl(control)
	if not control then
		return
	end
	if not self.searchHighlightFrame then
		---@class DBMOptionsFrameSearchHighlight: Frame, BackdropTemplate
		local highlight = CreateFrame("Frame", nil, _G["DBM_GUI_OptionsFramePanelContainer"], "BackdropTemplate")
		highlight.backdropInfo = {
			bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", -- 137056
			edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", -- 137057
			edgeSize = 16,
			tileEdge = true
		}
		highlight:ApplyBackdrop()
		highlight:SetBackdropColor(1, 0.82, 0, 0.2)
		highlight:SetBackdropBorderColor(1, 0.82, 0, 1)
		highlight:SetFrameStrata("DIALOG")
		highlight:SetFrameLevel(300)
		highlight:Hide()
		self.searchHighlightFrame = highlight
		self.searchHighlightToken = 0
	end
	self.searchHighlightToken = self.searchHighlightToken + 1
	local token = self.searchHighlightToken
	self.searchHighlightFrame:ClearAllPoints()
	self.searchHighlightFrame:SetParent(control:GetParent() or _G["DBM_GUI_OptionsFramePanelContainer"])
	self.searchHighlightFrame:SetPoint("TOPLEFT", control, "TOPLEFT", -5, 5)
	self.searchHighlightFrame:SetPoint("BOTTOMRIGHT", control, "BOTTOMRIGHT", 5, -5)
	self.searchHighlightFrame:Show()
	C_Timer.After(6, function()
		if self.searchHighlightToken == token and self.searchHighlightFrame then
			self.searchHighlightFrame:Hide()
		end
	end)
end

function frame:RevealSearchMatch(targetFrame, control)
	if not targetFrame or not control then
		return
	end
	if expandParentsForControl(targetFrame, control) then
		self:DisplayFrame(targetFrame, true)
	end
	C_Timer.After(0, function()
		local scrollBar = GetContainerScrollBar()
		if scrollBar and scrollBar:IsShown() then
			local panelTop = targetFrame:GetTop()
			local controlTop = control:GetTop()
			if panelTop and controlTop then
				local desired = panelTop - controlTop - 40
				if desired < 0 then
					desired = 0
				end
				local _, max = scrollBar:GetMinMaxValues()
				scrollBar:SetValue(mmin(desired, max))
			end
		end
		self:HighlightSearchControl(control)
	end)
end

function frame:ClearSelection()
	local listFrame = GetListFrame()
	if not listFrame or not listFrame.buttons then
		return
	end
	for _, button in ipairs(listFrame.buttons) do
		button:UnlockHighlight()
		button._dbmWasLocked = nil
	end
end

local function resize(targetFrame, hasScroll)
	local frameHeight = 20
	for _, child in ipairs({ targetFrame:GetChildren() }) do
		if child.mytype == "area" or child.mytype == "ability" then
			if hasScroll then
				child:SetPoint("TOPRIGHT", "DBM_GUI_OptionsFramePanelContainerFOVScrollBar", "TOPLEFT", -5, 0)
			else
				child:SetPoint("TOPRIGHT", "DBM_GUI_OptionsFramePanelContainerFOV", "TOPRIGHT", -5, 0)
			end
			local width = targetFrame:GetWidth() - 30
			if not child.isStats then
				local neededHeight, lastObject = 25, nil
				for _, child2 in ipairs({ child:GetChildren() }) do
					local child2Name = child2:GetName()
					if child.mytype == "ability" and child2.mytype then
						child2:SetShown(not child.hidden)
						if child2.mytype == "spelldesc" and child2Name then
							child2:SetShown(child2.hasDesc and true or child.hidden)
							local child2Text = _G[child2Name .. "Text"]
							child2:SetHeight(child2Text:GetStringHeight())
						end
					end
					if child2.mytype and child2:IsVisible() then
						if child2.mytype == "textblock" then
							if child2.autowidth and child2Name then
								local child2Text = _G[child2Name .. "Text"]
								child2Text:SetWidth(width - 30)
								child2:SetSize(width, child2Text:GetStringHeight())
							end
							lastObject = child2
						elseif child2.mytype == "spelldesc" then
							lastObject = child2
						elseif child2.mytype == "checkbutton" then
							local buttonText = child2.textObj
							buttonText:SetText(child2.text)
							local height = buttonText:GetContentHeight()
							buttonText:SetSize(buttonText:GetWidth(), height)
							buttonText:SetText(child2.text)
							height = buttonText:GetContentHeight()
							if not child2.customPoint then
								if lastObject then
									child2:SetPointOld("TOPLEFT", lastObject, "BOTTOMLEFT", 0, -mmax((lastObject.textObj and lastObject.textObj:GetContentHeight() or 0) - lastObject:GetHeight() + 6, 5))
								else
									child2:SetPointOld("TOPLEFT", 10, -12)
								end
								child2.myheight = mmax(height + 12, 30)
							end
							lastObject = child2
						elseif child2.mytype == "line" then
							child2:SetWidth(width - 20)
							if child2Name then
								local child2BG = _G[child2Name .. "BG"]
								local child2Text = _G[child2Name .. "Text"]
								child2BG:SetWidth(width - child2Text:GetWidth() - 25)
							end
							if lastObject and lastObject.myheight then
								child2:ClearAllPoints()
								child2:SetPoint("TOPLEFT", lastObject, "TOPLEFT", 0, -lastObject.myheight)
							end
							lastObject = child2
						end
						neededHeight = neededHeight + (child2.myheight or child2:GetHeight())
					elseif child2.myheight and child2:IsVisible() then
						neededHeight = neededHeight + child2.myheight
					end
				end
				child:SetHeight(neededHeight)
			end
			frameHeight = frameHeight + child:GetHeight() + 20
		elseif child.mytype == "line" then
			local width = targetFrame:GetWidth() - 30 + (child.extraWidth or 0)
			child:SetWidth(width - 20)
			local childName = child:GetName()
			local childBG = _G[childName .. "BG"]
			local childText = _G[childName .. "Text"]
			childBG:SetWidth(width - childText:GetWidth() - 25)
			frameHeight = frameHeight + 32
		elseif child.myheight then
			frameHeight = frameHeight + child.myheight
		end
	end
	return frameHeight
end

local bossPreview
function frame:DisplayFrame(targetFrame, secondResize)
	local childCount = targetFrame.GetNumChildren and targetFrame:GetNumChildren() or select("#", targetFrame:GetChildren())
	if childCount == 0 then
		return
	end
	selectedPagePerTab[self.tab] = targetFrame
	local scrollBar = GetContainerScrollBar()
	scrollBar:Show()
	local changed = DBM_GUI.currentViewing ~= targetFrame
	if DBM_GUI.currentViewing and changed then
		DBM_GUI.currentViewing:Hide()
	end
	DBM_GUI.currentViewing = targetFrame
	local dropDown = GetDropDown()
	if dropDown and dropDown.IsShown and dropDown:IsShown() then
		dropDown:Hide()
	end
	local FOV = GetContainerFOV()
	FOV:SetScrollChild(targetFrame)
	FOV:Show()
	if changed then
		targetFrame:Show()
	end
	targetFrame:SetSize(FOV:GetSize())
	local panelContainer = GetPanelContainer()
	local mymax = resize(targetFrame, true) - panelContainer:GetHeight()
	if mymax <= 0 then
		mymax = 0
	end
	if mymax > 0 then
		scrollBar:SetMinMaxValues(0, mymax)
		if changed then
			scrollBar:SetValue(0)
		end
	else
		scrollBar:Hide()
		scrollBar:SetValue(0)
		scrollBar:SetMinMaxValues(0, 0)
		secondResize = true
	end
	if secondResize ~= false then
		resize(targetFrame, scrollBar:IsVisible())
	end
	if changed then
		-- Areas resolve their width during the first display frame. Re-layout on the next frame so controls
		-- (notably SimpleHTML checkbox labels) use the same settled geometry as when a panel is revisited.
		C_Timer.After(0, function()
			if DBM_GUI.currentViewing == targetFrame then
				local deferredScrollBar = GetContainerScrollBar()
				local deferredFOV = GetContainerFOV()
				local deferredPanelContainer = GetPanelContainer()
				targetFrame:SetSize(deferredFOV:GetSize())
				deferredScrollBar:Show()
				local deferredMax = resize(targetFrame, true) - deferredPanelContainer:GetHeight()
				if deferredMax > 0 then
					deferredScrollBar:SetMinMaxValues(0, deferredMax)
					resize(targetFrame, true)
				else
					deferredScrollBar:Hide()
					deferredScrollBar:SetValue(0)
					deferredScrollBar:SetMinMaxValues(0, 0)
					resize(targetFrame, false)
				end
			end
		end)
	end
	if targetFrame.searchMatchedControl then
		self:RevealSearchMatch(targetFrame, targetFrame.searchMatchedControl)
		targetFrame.searchMatchedControl = nil
	end
	if DBM.Options.EnableModels then
		if not bossPreview then
			bossPreview = CreateFrame("PlayerModel", "DBM_BossPreview", panelContainer)
			bossPreview:SetPoint("BOTTOMRIGHT", "DBM_GUI_OptionsFramePanelContainer", "BOTTOMRIGHT", -5, 5)
			bossPreview:SetSize(300, 300)
			bossPreview:SetPortraitZoom(0.4)
			bossPreview:SetRotation(0)
			bossPreview:SetClampRectInsets(0, 0, 24, 0)
		end
		bossPreview:Hide()
		for _, mod in ipairs(DBM.Mods) do
			if mod.panel and mod.panel.frame and mod.panel.frame == targetFrame then
				bossPreview.currentMod = mod
				bossPreview:Show()
				bossPreview:ClearModel()
				bossPreview:SetModelScale(1)
				bossPreview:SetPosition(mod.modelOffsetX or 0, mod.modelOffsetY or 0, mod.modelOffsetZ or 0)
				bossPreview:SetFacing(mod.modelRotation or 0)
				bossPreview:SetSequence(mod.modelSequence or 4)
				bossPreview:SetDisplayInfo(mod.modelId or 0)
				if mod.modelSoundShort and DBM.Options.ModelSoundValue == "Short" then
					DBM:PlaySoundFile(mod.modelSoundShort)
				elseif mod.modelSoundLong and DBM.Options.ModelSoundValue == "Long" then
					DBM:PlaySoundFile(mod.modelSoundLong)
				end
				break
			end
		end
	end
end

if not isRetail then
	frame.tabsGroup = CreateRadioButtonGroup()
end

function frame:CreateTab(tab)
	tab:Hide()
	local i = #self.tabs + 1
	self.tabs[i] = tab
	DBM_GUI:CreateNewFauxScrollFrameList()
	---@class DBMOptionsFrameTabButtonTemplate: Button
	---@field Text FontString -- From MinimalTabTemplate/PanelTopTabButtonTemplate
	local button = CreateFrame("Button", frame:GetName() .. "Tab" .. i, self, isRetail and "PanelTopTabButtonTemplate" or "MinimalTabTemplate")
	button.Text:SetText(tab.name)
	if isRetail then
		PanelTemplates_SetNumTabs(self, i)
	else
		self.tabsGroup:AddButton(button)
		button:SetSize(button.Text:GetStringWidth() + 18, 33)
	end
	if i == 1 then
		button:SetPoint("TOPLEFT", self:GetName(), 20, -29)
	else
		button:SetPoint("TOPLEFT", "DBM_GUI_OptionsFrameTab" .. (i - 1), "TOPRIGHT", 5, 0)
	end
	button:SetScript("OnClick", function()
		self:ShowTab(i)
	end)
end

local _count = 0
function frame:ShowTab(tab)
	self.tab = tab
	self:UpdateMenuFrame()
	local hasSearch = self.searchQuery and self.searchQuery ~= ""
	if (tab == 1 and _count % 2 == 0) or (tab == 2 and _count % 2 == 1) then
		_count = _count + 1
		if _count == 5 then
			_count = 0
			DBM:PlaySoundFile(1304911, true)
		end
	else
		_count = 0
	end
	if isRetail then
		PanelTemplates_SetTab(self, tab)
	else
		self.tabsGroup:SelectAtIndex(tab)
	end
	if bossPreview then
		bossPreview:Hide()
	end
	if selectedPagePerTab[tab] then
		self:DisplayFrame(selectedPagePerTab[tab])
	elseif DBM_GUI.currentViewing then
		DBM_GUI.currentViewing:Hide()
		DBM_GUI.currentViewing = nil
	end
	if not hasSearch and not selectedPagePerTab[tab] and tab == DBM_GUI.Enums.Tabs.CORE then -- Core Options, default show "Core & GUI" frame
		self:LoadAndShowFrame(DBM_GUI.tabs[self.tab].buttons[2].frame)
	elseif not hasSearch and not selectedPagePerTab[tab] and tab == DBM_GUI.Enums.Tabs.TOOLS then -- Tools
		self:LoadAndShowFrame(DBM_GUI.tabs[self.tab].buttons[1].frame)
	end
end
