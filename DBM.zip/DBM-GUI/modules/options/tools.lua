local L		= DBM_GUI_L
local CL	= DBM_CORE_L

---@class DBMGUI
local DBM_GUI = DBM_GUI

DBM_GUI.CAT_TOOLS = DBM_GUI:CreateNewPanel("TOOLS", "tools")

DBM_GUI.tabs[DBM_GUI.Enums.Tabs.TOOLS].buttons[1].hidden = true -- Hide the category

local area		= DBM_GUI.CAT_TOOLS:CreateArea(L.OTabTools)

local latency = area:CreateButton(L.Tools_LatencyCheck, 120, 30)
latency:SetPoint("TOPLEFT", area.frame, "TOPLEFT", 10, -10)
latency:SetScript("OnClick", function()
	DBM.Latency:Show()
end)

local durability = area:CreateButton(L.Tools_DurabilityCheck, 120, 30)
durability.myheight = 0
durability:SetPoint("LEFT", latency, "RIGHT", 10, 0)
durability:SetScript("OnClick", function()
	DBM.Durability:Show()
end)

local gear = area:CreateButton(L.Tools_GearCheck, 120, 30)
gear.myheight = 0
gear:SetPoint("LEFT", durability, "RIGHT", 10, 0)
gear:SetScript("OnClick", function()
	DBM.GearCheck:Show()
end)

local lastToolButton = gear
if DBM.Consumables then
	local consumables = area:CreateButton(L.Tools_ConsumablesCheck, 120, 30)
	consumables.myheight = 0
	consumables:SetPoint("LEFT", gear, "RIGHT", 10, 0)
	consumables:SetScript("OnClick", function()
		DBM.Consumables:Show()
	end)
	lastToolButton = consumables
end

--we'll want it to be last button so it's easier to hide on classic
if DBM:IsRetail() then
	local keystone = area:CreateButton(L.Tools_KeystoneCheck, 120, 30)
	keystone.myheight = 0
	keystone:SetPoint("LEFT", lastToolButton, "RIGHT", 10, 0)
	keystone:SetScript("OnClick", function()
		DBM.Keystones:Show()
	end)

	local area1b = DBM_GUI.CAT_TOOLS:CreateArea(L.Tools_BrezArea)

	local showBrezFrame = area1b:CreateCheckButton(L.Tools_ShowBrezFrame, true, nil, "ShowBrezFrame")

	if showBrezFrame then
		showBrezFrame:HookScript("OnClick", function()
			if DBM.BattleRezTimer then
				DBM.BattleRezTimer:CheckSupported()
			end
		end)
	end

	local BrezFonts = DBM_GUI:MixinSharedMedia3("font", {
		{
			text	= DEFAULT,
			value	= "standardFont"
		},
		{
			text	= "Arial",
			value	= "Fonts\\ARIALN.TTF"
		},
		{
			text	= "Skurri",
			value	= "Fonts\\SKURRI_CYR.ttf"
		},
		{
			text	= "Morpheus",
			value	= "Fonts\\MORPHEUS_CYR.ttf"
		}
	})

	local BrezFontDropDown = area1b:CreateDropdown(L.FontType, BrezFonts, "DBM", "BrezFont", function(value)
		DBM.Options.BrezFont = value
		if DBM.BattleRezTimer then
			DBM.BattleRezTimer:UpdateStyle()
		end
	end)
	local isNewDropdown = BrezFontDropDown.mytype == "dropdown2"
	BrezFontDropDown:SetPoint("TOPLEFT", showBrezFrame, "TOPLEFT", isNewDropdown and 20 or 0, -40)
	BrezFontDropDown.myheight = isNewDropdown and 25 or 20

	local fontSizeSlider = area1b:CreateSlider(L.FontSize, 8, 40, 1, 180, DBM.Options.BrezFontSize or 18, function(value)
		DBM.Options.BrezFontSize = value
		if DBM.BattleRezTimer then
			DBM.BattleRezTimer:UpdateStyle()
		end
	end)
	fontSizeSlider:SetPoint("TOPLEFT", BrezFontDropDown, "TOPRIGHT", 50, 0)
	fontSizeSlider.myheight = 0
	area1b.frame:HookScript("OnShow", function()
		fontSizeSlider:SetValueSilent(DBM.Options.BrezFontSize or 18)
	end)

	local movemebutton = area1b:CreateButton(L.MoveMe, 100, 16)
	movemebutton:SetPoint("TOPRIGHT", area1b.frame, "TOPRIGHT", -2, -4)
	movemebutton:SetNormalFontObject(GameFontNormalSmall)
	movemebutton:SetHighlightFontObject(GameFontNormalSmall)
	movemebutton:SetScript("OnClick", function()
		if DBM.BattleRezTimer:IsShown() then
			DBM.BattleRezTimer:Hide()
		else
			DBM.BattleRezTimer:Show()
		end
	end)

	local area1c = DBM_GUI.CAT_TOOLS:CreateArea(L.Tools_KeystoneArea)
	area1c:CreateCheckButton(L.Tools_ShowKeystoneOnComplete, true, nil, "ShowKeystoneOnComplete")
	local addChallengeTeleports = area1c:CreateCheckButton(L.Tools_AddChallengeTeleports or "Add teleports to Challenges UI", true, nil, "AddChallengeTeleports")
	if addChallengeTeleports then
		addChallengeTeleports:HookScript("OnClick", function()
			if DBM.Keystones and DBM.Keystones.RefreshChallengesUI then
				DBM.Keystones:RefreshChallengesUI()
			end
		end)
	end
	area1c:CreateCheckButton(L.Tools_OverrideKeystoneSlash, true, nil, "OverrideKeystoneSlash")
end

if DBM.Consumables then
	local area1d = DBM_GUI.CAT_TOOLS:CreateArea(L.Tools_ConsumablesArea)
	area1d:CreateCheckButton(L.Tools_ShowConsumablesOnReadyCheck, true, nil, "ShowConsumablesOnReadyCheck")
end

local area2 = DBM_GUI.CAT_TOOLS:CreateArea(L.Tools_BreakTimer)

local duration = area2:CreateEditBox(L.Tools_Duration, "")
duration.myheight = 30
duration:SetPoint("TOPLEFT", area2.frame, "TOPLEFT", 15, -25)

local startBtn = area2:CreateButton(L.Tools_BreakTimer)
startBtn.myheight = 0
startBtn:SetPoint("LEFT", duration, "RIGHT", 10, 0)
startBtn:SetScript("OnClick", function()
	DBM:CreateBreakTimer(tonumber(duration:GetText()) or 10)
end)

local area3 = DBM_GUI.CAT_TOOLS:CreateArea(L.Tools_PizzaTimer)

local duration2 = area3:CreateEditBox(L.Tools_Duration, "")
duration2.myheight = 30
duration2:SetPoint("TOPLEFT", area3.frame, "TOPLEFT", 15, -25)

local message = area3:CreateEditBox(L.Tools_Message, "", 300, 20)
message.myheight = 40
message:SetPoint("TOPLEFT", duration2, "BOTTOMLEFT", 0, -20)

local startBtn2 = area3:CreateButton(L.Tools_PizzaTimer)
startBtn2.myheight = 0
startBtn2:SetPoint("LEFT", duration2, "RIGHT", 10, 0)
startBtn2:SetScript("OnClick", function()
	local difficultyIndex = DBM:GetCurrentDifficulty()
	local permission = true
	if DBM:GetRaidRank() == 0 or difficultyIndex == 7 or difficultyIndex == 17 or IsTrialAccount() then
		DBM:AddMsg(CL.ERROR_NO_PERMISSION)
		permission = false
	end
	local time, text = duration2:GetText(), message:GetText()
	if not time and not text then
		DBM:AddMsg(CL.PIZZA_ERROR_USAGE)
		return
	end
	local _min, _sec = string.split(":", time)
	local min = tonumber(_min or "") or 0
	local sec = tonumber(_sec or "")
	if min and not sec then
		sec = min
		min = 0
	end
	DBM:CreatePizzaTimer(min * 60 + sec, text, permission)
end)
