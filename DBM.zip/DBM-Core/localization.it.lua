if GetLocale() ~= "itIT" then return end
if not DBM_CORE_L then DBM_CORE_L = {} end

local L = DBM_CORE_L
L.CONSUMABLES_SHAMAN_IMBUES = {"Furia del Vento", "Lingua di Fuoco", "Terra Benefica"}
L.CONSUMABLES_PALADIN_IMBUES = {"Rito della Santificazione", "Rito del Giuramento"}
L.AURA_FONT_RESET	= "Sono state rilevate impostazioni non valide per il carattere del testo delle aure; sono state ripristinate a quelle predefinite."

local dateTable = date("*t")
if dateTable.day and dateTable.month and dateTable.day == 1 and dateTable.month == 4 then
	L.DEADLY_BOSS_MODS					= "Harmless Minion Mods"
	L.DBM								= "HMM"
end

L.HOW_TO_USE_MOD		= "Benvenuto in "..L.DBM..". Scrivi /dbm help per avere una lista dei comandi supportati. Per accedere alle opzioni scrivi in chat /dbm. Carica le zone specifiche per configurare manualmente ogni settaggio di ogni boss. "..L.DBM.." prova a farlo per te controllando la tua specializzazione alla prima esecuzione, ma alcuni potrebbero volere alcune opzioni attivate."
L.SILENT_REMINDER		= "Avviso: "..L.DBM.." è in modalità silente."
L.NEWS_UPDATE			= "|h|c11ff1111Notizie|r|h: DBM è stato aggiornato con la funzione di rinomina delle abilità. Digita /dbm, vai alla categoria dei mod (incursioni, spedizioni, ecc.) e apri il mod in cui vuoi rinominare le abilità."
L.NEWS_UPDATE_REPEAT	= "|h|c11ff1111Notizie|r|h: DBM è stato aggiornato con modifiche alla struttura dei mod, così classic e mainline possono ora usare moduli unificati (identici). Questo significa che i moduli incursione di Vanilla (incluso SoD), TBC, Wrath e Cata devono ora essere scaricati separatamente usando gli stessi pacchetti della versione retail. Ti trovi in un'incursione con un modulo mancante. Questo messaggio continuerà a mostrarsi (e non avrai avvisi funzionanti per questa zona) finché non installerai il modulo incursione mancante."

L.COPY_URL_DIALOG_NEWS	= "Per leggere le ultime notizie, visita il link sottostante"

L.LOAD_MOD_ERROR			= "Errore nel caricamento della Boss Mod %s: %s"
L.LOAD_MOD_SUCCESS			= "Caricate '%s' mod. Per opzioni quali avvisi sonori e avvertimenti personalizzati, digitare /dbm."
L.LOAD_MOD_COMBAT			= "Caricamento di '%s' rimandato al termine del combattimento"
L.LOAD_GUI_ERROR			= "Non riesco a caricare l'Interfaccia: %s"
L.LOAD_GUI_COMBAT			= "L'Interfaccia non può essere inizializzata in combattimento, verrà caricata al termine dello stesso. Caricata, potrai aprirla anche in combattimento."
L.BAD_LOAD					= ""..L.DBM.." non è stato in grado di caricare completamente la mod in quanto in combattimento. Al termine dello stesso, esegui /console reloadui il prima possibile."
L.LOAD_MOD_VER_MISMATCH		= "%s non può essere caricata in quanto DBM-Core non rispetta i requisiti. E' richiesta la versione aggiornata."
L.LOAD_MOD_EXP_MISMATCH		= "%s non può essere caricata in quanto è sviluppata per un'espansione di WoW non ancora disponibile. Quando diverrà disponibile, questa mod funzionerà."
L.LOAD_MOD_TOC_MISMATCH		= "%s non può essere caricata in quanto è sviluppata per una patch di WoW (%s) non ancora disponibile. Quando diverrà disponibile, questa mod funzionerà."
L.LOAD_MOD_DISABLED			= "%s è installata ma disabilitata. Questa mod non sarà caricata finchè non la abiliterai."
L.LOAD_MOD_DISABLED_PLURAL	= "%s sono installati ma disabilitati. Queste mod non saranno caricate finché non le abiliterai."
L.MOD_MISSING				= "Nessun modulo incursione"
L.NOT_INSTALLED				= "Non installato"

L.COPY_URL_DIALOG	= "Copia URL"
L.COPY_WA_DIALOG	= "Copia Chiave Incantesimo"

--Post Patch 7.1
L.TEXT_ONLY_RANGE	= "Il distanziometro è limitato al solo testo, poiché Blizzard ha disabilitato alcune funzionalità in quest'area."
L.NO_RANGE			= "Il Radar Distanziometro non può essere utilizzato nelle istanze. Verrà utilizzato il precedente riquadro testuale"
L.NO_ARROW			= "La Freccia non può essere usata nelle istanze"
L.HUDMAP_NOT_INSTALLED	= "DBM-HudMap non è installato o non è abilitato."
L.NO_COMMS			= "La comunicazione degli addon non può essere utilizzata durante gli incontri o le istanze M+ attive. Utilizza nuovamente questo comando dopo la fine dell'incontro o dell'istanza."

L.DYNAMIC_DIFFICULTY_CLUMP	= ""..L.DBM.." ha disabilitato il riquadro distanziometro per questo combattimento per insufficienti informazioni sulle distanze richieste con un gruppo di queste dimensioni."
L.DYNAMIC_ADD_COUNT			= ""..L.DBM.." ha disabilitato gli avvisi sulla quantità degli add per questo combattimento per insufficienti informazioni sul numero di add presenti con un gruppo di queste dimensioni."
L.DYNAMIC_MULTIPLE			= ""..L.DBM.." ha disabilitato diverse funzionalità per questo combattimento per insufficienti informazioni su alcune meccaniche con un gruppo di queste dimensioni."

L.LOOT_SPEC_REMINDER	= "La tua specializzazione è %s. La tua preferenza per il bottino è %s."

L.BIGWIGS_ICON_CONFLICT	= ""..L.DBM.." ha rilevato l'abilitazione delle icone incursioni sia in BigWigs che in "..L.DBM..". Disabilita le icone in uno dei due per evitare conflitti"

L.MOD_AVAILABLE	= "%s è disponibile per questa ziona. E' possibile scaricare la mod da Curse, WoWI o deadlybossmods.com"

L.COMBAT_STARTED				= "%s ingaggiato. Buona fortuna e Divertiti! :)"
L.COMBAT_STARTED_IN_PROGRESS	= "Ingaggiato combattimento in corso contro %s. Buona fortuna e Divertiti! :)"
L.GUILD_COMBAT_STARTED			= "%s è stato ingaggiato dal gruppo di gilda di %s"
L.SCENARIO_STARTED				= "%s iniziato. Buona fortuna e Divertiti! :)"
L.SCENARIO_STARTED_IN_PROGRESS	= "Unito allo scenario %s in corso. Buona fortuna e Divertiti! :)"
L.BOSS_DOWN						= "%s sconfitto in %s!"
L.BOSS_DOWN_I					= "%s sconfitto! Hai totalizzato %d vittorie."
L.BOSS_DOWN_L					= "%s sconfitto in %s! La tua ultima uccisione ha richiesto %s, quella più veloce %s. Hai totalizzato %d uccisioni."
L.BOSS_DOWN_NR					= "%s sconfitto in %s! E' un nuovo record! (Precedente di %s). Hai totalizzato %d uccisioni."
L.RAID_DOWN						= "%s completato in %s!"
L.RAID_DOWN_L					= "%s completato in %s! Il tuo completamento più veloce ha richiesto %s."
L.RAID_DOWN_NR					= "%s completato in %s! È un nuovo record! (Il precedente era %s)."
L.GUILD_BOSS_DOWN				= "%s è stato sconfitto dal gruppo di gilda di %s dopo %s!"
L.SCENARIO_COMPLETE				= "%s completato dopo %s!"
L.SCENARIO_COMPLETE_I			= "%s completato! Hai totalizzato %d completamenti."
L.SCENARIO_COMPLETE_L			= "%s completato dopo %s! Il tuo ultimo completamento ha richiesto %s e quello più veloce %s. Hai totalizzato %d completamenti."
L.SCENARIO_COMPLETE_NR			= "%s completato dopo %s! E' un nuovo record! (Precedente di %s). Hai totalizzato %d completamenti."
L.COMBAT_ENDED_AT				= "Combattimento contro %s (%s) terminato dopo %s."
L.COMBAT_ENDED_AT_LONG			= "Combattimento contro %s (%s) terminato dopo %s. Sei stato eliminato %d volte a questa difficoltà."
L.COMBAT_ENDED					= "Combattimento contro %s terminato dopo %s."
L.COMBAT_ENDED_LONG				= "Combattimento contro %s terminato dopo %s. Hai totalizzato %d disfatte a questa difficoltà."
L.GUILD_COMBAT_ENDED_AT			= "Il gruppo di gilda di %s ha subito una disfatta contro %s (%s) dopo %s."
L.GUILD_COMBAT_ENDED			= "Il gruppo di gilda di %s ha subito una disfatta contro %s dopo %s."
L.SCENARIO_ENDED_AT				= "%s è terminato dopo %s."
L.SCENARIO_ENDED_AT_LONG		= "%s è terminato dopo %s. Hai totalizzato %d fallimenti a questa difficoltà."
L.COMBAT_STATE_RECOVERED		= "%s è stato ingaggiato %s fa, ripristino temporizzatori..."
L.TRANSCRIPTOR_LOG_START		= "Avviato registro di Transcriptor."
L.TRANSCRIPTOR_LOG_END			= "Terminato registro di Transcriptor."

L.MOVIE_SKIPPED		= ""..L.DBM.." ha tentato di saltare automaticamente un filmato."
L.MOVIE_NOTSKIPPED	= L.DBM .. " ha rilevato una scena tagliata che può essere saltata, ma NON l\'ha saltata a causa di un bug di Blizzard. Quando questo bug verrà risolto, il salto verrà riabilitato"
L.BONUS_SKIPPED		= ""..L.DBM.." ha chiuso automaticamente il riquadro del bottino bonus. Se richiesto, è possibile riaprirlo digitando /dbmbonusroll entro 3 minuti"

L.AFK_WARNING		= "Sei AFK e in combattimento (%d percento di vita rimanente), esecuzione avviso sonoro. Se non sei AFK, togliti dallo stato AFK flag o disabilita questa opzione in 'funzionalità aggiuntive'."
L.LOWHEALTH_WARNING	= "Vita bassa (%d percento di vita rimanente), esecuzione avviso sonoro. Puoi disabilitare questa opzione in 'funzionalità aggiuntive'."
L.ENTERING_COMBAT	= "Ingresso in combattimento"
L.LEAVING_COMBAT	= "Uscita dal combattimento"

L.RAID_DIFFICULTY_CHANGED		= "Il livello di difficoltà dell'incursione è stato impostato su %s."
L.DUNGEON_DIFFICULTY_CHANGED	= "Il livello di difficoltà della spedizione è stato impostato su %s."
L.DUNGEONS						= "Spedizioni: "

L.PROFILE_NOT_FOUND				= "<"..L.DBM.."> Il tuo profilo attuale è corrotto. "..L.DBM.." caricherà il profilo '%s'."
L.PROFILE_CREATED				= "Profilo '%s' creato."
L.PROFILE_CREATE_ERROR			= "Creazione profilo fallita. Nome profilo non valido."
L.PROFILE_CREATE_ERROR_D		= "Creazione profilo fallita. Il profilo '%s' esistente."
L.PROFILE_APPLIED				= "Profilo '%s' applicato."
L.PROFILE_APPLY_ERROR			= "Applicazione profilo fallita. Il profilo '%s' non esiste."
L.PROFILE_COPIED				= "Profilo '%s' copiato."
L.PROFILE_COPY_ERROR			= "Copia profilo fallita. Il profilo '%s' non esiste."
L.PROFILE_COPY_ERROR_SELF		= "Impossibile copiare il profilo su se stesso."
L.PROFILE_DELETED				= "Profilo '%s' eliminato. Verrà applicato il profilo '%s'."
L.PROFILE_DELETE_ERROR			= "Cancellazione prodilo fallita. Il profilo '%s' non esiste."
L.PROFILE_CANNOT_DELETE			= "Impossibile eliminare il profilo '%s'."
L.MPROFILE_COPY_SUCCESS			= "Le impostazioni mod di %s (spec %d) sono state copiate."
L.MPROFILE_COPY_SELF_ERROR		= "Impossibile copiare le impostazioni personaggio sullo stesso"
L.MPROFILE_COPY_S_ERROR			= "Sorgente corrotta. Impostazioni non copiate o parziali. Copia fallita."
L.MPROFILE_COPYS_SUCCESS		= "Le impostazioni sonore o le note di %s (spec %d) sono state copiate."
L.MPROFILE_COPYS_SELF_ERROR		= "Impossibile copiare i suoni o le note personaggio sullo stesso"
L.MPROFILE_COPYS_S_ERROR		= "Sorgente corrotta. Impostazioni sonore o note non copiate o parziali. Copia fallita."
L.MPROFILE_DELETE_SUCCESS		= "Impostazioni mod di %s (spec %d) eliminate."
L.MPROFILE_DELETE_SELF_ERROR	= "Impossibile eliminare impostazioni mod in uso."
L.MPROFILE_DELETE_S_ERROR		= "Sorgente corrotta. Impostazioni non cancellate o parziali. Cancellazione fallita."

L.NOTE_SHARE_SUCCESS	= "%s ha condiviso le sue note per %s"
L.NOTE_SHARE_LINK		= "Clicca qui per aprire la nota"
L.NOTE_SHARE_FAIL		= "%s ha tentato di condividere una nota testuale con te per %s. Tuttavia, la mod associata con questa abilità non è installata o non è caricata. Se necessiti di questa nota, assicurati di caricare la mod che usano per le note e chiedi di condividerla nuovamente"

L.NOTEHEADER				= "Scrivi il testo della tua nota per %s. Racchiudendo i nomi giocatori con >< li colorerà in base alla classe. Per avvisi richiamati più volte, separare le note con '/'"
L.NOTEFOOTER				= "Premi 'Ok' per accettare le modifiche o 'Annulla' per declinarle"
L.NOTESHAREDHEADER			= "%s ha condiviso la seguente nota testuale per %s. Se accetti, sovrascriverà la tua attuale nota"
L.NOTESHARED				= "Le tue note sono state inviate al gruppo"
L.NOTESHAREERRORSOLO		= "Solitario? Non dovresti passarti le tue stesse note"
L.NOTESHAREERRORBLANK		= "Impossibile condividere note in bianco"
L.NOTESHAREERRORGROUPFINDER	= "Le note non possono essere condivise nei CdB, Ricerca Incursioni o Spedizioni"
L.NOTESHAREERRORALREADYOPEN	= "Impossibile aprire il collegamento a una nota condivisa mentre è aperto l'editor al fine di prevenire la perdita della nota attualmente in modifica"

L.ALLMOD_DEFAULT_LOADED	= "Le opzioni predefinite delle mod di quest'istanza sono state caricate."
L.ALLMOD_STATS_RESETED	= "Le statistiche della mod sono state resettate."
L.MOD_DEFAULT_LOADED	= "Le opzioni predefinite del combattimento sono state caricate."

L.WORLDBOSS_ENGAGED		= "%s è stato probabilmente ingaggiato sul reame con il %s di vita. (Inviato da %s)"
L.WORLDBOSS_DEFEATED	= "%s è stato probabilmente sconfitto sul reame (Inviato da %s)."
L.WORLDBUFF_STARTED		= "Il buff %s è iniziato sul tuo reame per la fazione %s (Inviato da %s)."

L.TIMER_FORMAT_SECS	= "%.2f |4secondo:secondi;"
L.TIMER_FORMAT_MINS	= "%d |4minuto:minuti;"
L.TIMER_FORMAT		= "%d |4minuto:minuti; e %.2f |4secondo:secondi;"

L.MIN		= "min"
L.MIN_FMT	= "%d min"
L.SEC		= "sec"
L.SEC_FMT	= "%s sec"

L.GENERIC_WARNING_OTHERS	= "e un altro"
L.GENERIC_WARNING_OTHERS2	= "e %d altri"
L.GENERIC_TRASH_TARGET	= "%s: %s"
L.GENERIC_WARNING_BERSERK	= "Furia tra %s %s"
L.GENERIC_TIMER_BERSERK		= "Furia"
L.OPTION_TIMER_BERSERK		= "Visualizza Temporizzatore $spell:26662"
L.BAD						= "Cattivo"

L.OPTION_CATEGORY_TIMERS	= "Barre"
--Sub cats for "announce" object
L.OPTION_CATEGORY_WARNINGS			= "Annunci Generali"
L.OPTION_CATEGORY_WARNINGS_YOU		= "Annunci Personali"
L.OPTION_CATEGORY_WARNINGS_OTHER	= "Annunci Bersaglio"
L.OPTION_CATEGORY_WARNINGS_ROLE		= "Annunci Ruolo"
L.OPTION_CATEGORY_SPECWARNINGS		= "Annunci Speciali"

L.OPTION_CATEGORY_SOUNDS	= "Souni"
--Misc object broken down into sub cats
L.OPTION_CATEGORY_DROPDOWNS		= "Tendine" -- Still put in MISC sub group, just used for line separators since multiple of these on a fight (or even having on of these at all) is rare.
L.OPTION_CATEGORY_YELLS			= "Urla"
L.OPTION_CATEGORY_NAMEPLATES	= "Barre dei Nomi"
L.OPTION_CATEGORY_ICONS			= "Icone"
L.OPTION_CATEGORY_PAURAS		= "Aure Private"

L.AUTO_RESPONDED	= "Risposta Automatica."
L.STATUS_WHISPER	= "%s: %s, %d/%d Giocatori vivi"
-- Boss
L.AUTO_RESPOND_WHISPER				= "%s sta combattendo %s (%s, %d/%d giocatori vivi)"
L.WHISPER_COMBAT_END_KILL			= "%s ha sconfitto %s!"
L.WHISPER_COMBAT_END_KILL_STATS		= "%s ha sconfitto %s! Hanno totalizzato %d vittorie."
L.WHISPER_COMBAT_END_WIPE_AT		= "%s ha subito una disfatta da %s al %s"
L.WHISPER_COMBAT_END_WIPE_STATS_AT	= "%s ha subito una disfatta da %s al %s. Ha totalizzato %d disfatte in questa difficoltà."
--Scenarios (no percents. words like "fighting" or "wipe" changed to better fit scenarios)
L.AUTO_RESPOND_WHISPER_SCENARIO		= "%s è occupato con %s (%d/%d persone vive)"
L.WHISPER_SCENARIO_END_KILL			= "%s ha completato %s!"
L.WHISPER_SCENARIO_END_KILL_STATS	= "%s ha completato %s! Ha totalizzato %d vittorie."
L.WHISPER_SCENARIO_END_WIPE			= "%s non ha completato %s"
L.WHISPER_SCENARIO_END_WIPE_STATS	= "%s non ha completato %s. Ha totalizzato %d total disfatte in questa difficoltà."

L.VERSIONCHECK_HEADER		= L.DEADLY_BOSS_MODS.." - Versione"
L.VERSIONCHECK_ENTRY		= "%s: %s (%s)"
L.VERSIONCHECK_ENTRY_TWO	= "%s: %s (%s) e %s (%s)" -- Due Boss mods
L.VERSIONCHECK_ENTRY_NO_DBM	= "%s: "..L.DBM.." non installato"
L.VERSIONCHECK_FOOTER		= "%d giocatori hanno "..L.DEADLY_BOSS_MODS..""
L.VERSIONCHECK_OUTDATED		= "I seguenti %d giocatore/i hanno una versione obsoleta delle boss mod: %s"
L.YOUR_VERSION_OUTDATED		= "La tua versione di "..L.DEADLY_BOSS_MODS.." è obsoleta. Visita http://www.deadlybossmods.com per ottenere l'ultima versione."
L.VOICE_PACK_OUTDATED		= "Il pacchetto vocale selezionato non contiene alcuni suoni supportati da "..L.DBM..". Alcuni avvisi sonori verranno eseguiti con i suoni predefiniti. Scarica una nuova versione del pacchetto vocale o contatta l'autore per un aggiornamento contenente l'audio mancante"
L.VOICE_MISSING				= "Hai selezionato un pacchetto vocale "..L.DBM.." non trovato. Se è un errore, assicurati che il pacchetto vocale sia correttamente installato e abilitato negli addon."
L.VOICE_DISABLED			= "Hai almeno un pacchetto vocale "..L.DBM.." installato ma nessuno abilitato. Se desideri usare un pacchetto vocale, assicurati che sia selezionato in 'Avvisi Parlati', altrimenti disinstalla i pacchetti vocali inutilizzati per nascondere questo messaggio"
L.VOICE_COUNT_MISSING		= "Conto alla rovescia %d è impostato su un pacchetto vocale/conteggio non trovato. E' stato reimportato all'opzione predefinita: %s."
L.BIG_WIGS					= "BigWigs"
L.WEAKAURA_KEY				= " (|cff359030ID:|r %s)"
L.RENAME					= " (|cff359030Rinomina:|r |cff71d5ff%s|r)"

L.UPDATEREMINDER_HEADER				= "La tua versione di "..L.DEADLY_BOSS_MODS.." e' obsoleta.\n La Versione %s (%s) e' disponibile per il download su Curse, WoWI o da deadlybossmods.com"
L.UPDATEREMINDER_HEADER_SUBMODULE	= "Il tuo modulo %s è obsoleto.\nLa versione %s è disponibile per il download tramite Curse, Wago, WoWI o dalla pagina GitHub Releases"
L.UPDATEREMINDER_FOOTER				= "Premi " .. (IsMacClient() and "Cmd-C" or "Ctrl-C")  .. " per copiare il link di download negli appunti."
L.UPDATEREMINDER_FOOTER_GENERIC		= "Premi " .. (IsMacClient() and "Cmd-C" or "Ctrl-C")  .. " per copiare il link negli appunti."
L.UPDATEREMINDER_DISABLE			= "AVVISO: A causa della notevole obsolescenza, "..L.DEADLY_BOSS_MODS.." è stato forzatamente disabilitato e non può essere utilizzato fino all'aggiornamento. Questo per assicurarsi che vecchio e incompatibile codice non causi problemi a te e al tuo gruppo."
L.UPDATEREMINDER_DISABLETEST		= "AVVISO: Poiché la tua versione di " .. L.DEADLY_BOSS_MODS .. " è obsoleta e questo è un reame di test/beta, è stata forzatamente disabilitata e non può essere usata finché non verrà aggiornata. Questo per assicurarsi che i mod obsoleti non vengano usati per generare feedback di test"
L.UPDATEREMINDER_HOTFIX				= "La versione v in uso ha problemi con il combattimento di questo boss che sono stati corretti con l'ultima versione aggiornata"
L.UPDATEREMINDER_HOTFIX_ALPHA		= "La versione "..L.DBM.." in uso ha problemi con il combattimento di questo boss che sono stati corretti con la prossima versione in arrivo (o nella versione alfa)"
L.UPDATEREMINDER_MAJORPATCH			= "AVVISO: Data l'obsolescenza di "..L.DEADLY_BOSS_MODS..", "..L.DBM.." è stato disabilitato fino ad aggiornamento, trattandosi di una patch maggiore. Questo è per assicurarsi che il vecchio e incompatibile codice non causi problemi a te o al tuo gruppo. Assicurati di scaricare una nuova versione da deadlybossmods.com, Curse o WoWI il prima possibile."
L.VEM								= "AVVISO: Stai eseguento sia "..L.DEADLY_BOSS_MODS.." che Voice Encounter Mods. "..L.DBM.." non funzionerà con questa configurazione e quindi non verrà caricato."
L.OUTDATEDPROFILES					= "AVVISO: DBM-Profiles è incompatibile con questa versione di "..L.DBM..". Deve essere rimosso per utilizzare "..L.DBM..", per evitare conflitti."
L.OUTDATEDSPELLTIMERS				= "AVVISO: DBM-SpellTimers rompe " .. L.DBM .. " e deve essere disabilitato affinché " .. L.DBM .. " funzioni correttamente."
L.OUTDATEDRLT						= "AVVISO: DBM-RaidLeadTools rompe " .. L.DBM .. ". DBM-RaidLeadTools non è più supportato e deve essere rimosso affinché " .. L.DBM .. " funzioni correttamente."
L.VICTORYSOUND						= "AVVISO: DBM-VictorySound non è compatibile con questa versione di " .. L.DBM .. ". Deve essere rimosso prima che " .. L.DBM .. " possa procedere, per evitare conflitti."
L.DPMCORE							= "AVVISO: Deadly PvP mods è discontinuato e incompatibile con questa versione di "..L.DBM..". Deve essere rimosso per utilizzare "..L.DBM..", per evitare conflitti."
L.DBMLDB							= "AVVISO: DBM-LDB è ora incluso in DBM-Core. Anche se non dannoso, è consigliabile rimuovere 'DBM-LDB' dalla cartella addon"
L.DBMLOOTREMINDER					= "AVVISO: è installato il mod di terze parti DBM-LootReminder. Questo addon non è più compatibile con il client retail di WoW e farà sì che " .. L.DBM .. " si rompa e non possa inviare temporizzatore di pull. Si consiglia di disinstallare questo addon"
L.UPDATE_REQUIRES_RELAUNCH			= "AVVISO: Questo aggiornamento "..L.DBM.." non funzionerà correttamente a meno di un riavvio del gioco. Questo aggiornamento contiene nuovi file o modifiche al file .toc che non possono essere caricate con ReloadUI. Potresti avere malfunzionamenti o errori se continui senza riavviare."
L.OUT_OF_DATE_NAG					= "La versione di "..L.DEADLY_BOSS_MODS.." è obsoleta. Ti consigliamo di aggiornarla per questo combattimento, così da non perdere avvisi, temporizzatore o messaggi importanti da comunicare al resto dell'incursione."
L.HARDCODED_FALLBACK				= L.DBM .. " ha rilevato un risultato inatteso in una mod codificata internamente. " .. L.DBM .. " userà temporizzatore e avvisi Blizzard per questo scontro."
L.DBM_INSTALL_REMINDER_HEADER		= "Rilevata un'installazione DBM incompleta!"
L.DBM_INSTALL_REMINDER_EXPLAIN		= "Benvenuto in %s. I mod di DBM per i boss di questa zona sono inclusi nel %s che non hai installato. DBM non mostrerà temporizzatori o avvisi in questa zona finché non installerai il %s!"
L.DBM_INSTALL_REMINDER_DISABLE		= "Disabilita tutti gli avvisi e i temporizzatori di DBM in questa zona." -- Used when we believe it's a user error that the mod isn't installed (i.e., current raids)
L.DBM_INSTALL_REMINDER_DISABLE2		= "Non mostrare più questo messaggio per questo pacchetto." -- Used for unimportant mods, i.e., dungeons
L.DBM_INSTALL_REMINDER_DL_WAGO		= "Premi " .. (IsMacClient() and "Cmd-C" or "Ctrl-C") .. " per copiare il link di Wago.io negli appunti."
L.DBM_INSTALL_REMINDER_DL_CURSE		= "Premi " .. (IsMacClient() and "Cmd-C" or "Ctrl-C") .. " per copiare il link di Curseforge negli appunti."
L.DBM_INSTALL_PACKAGE_VANILLA		= "Pacchetto Vanilla e Season of Discovery"
L.DBM_INSTALL_PACKAGE_BCC			= "Pacchetto Burning Crusade"
L.DBM_INSTALL_PACKAGE_WRATH			= "Pacchetto Wrath"
L.DBM_INSTALL_PACKAGE_CATA			= "Pacchetto Cataclysm"
L.DBM_INSTALL_PACKAGE_MOP			= "Pacchetto Mist of Pandaria"
L.DBM_INSTALL_PACKAGE_DUNGEON		= "Pacchetto Spedizioni, Delves, Sfide ed Eventi"
L.PLATER_NP_AURAS_MSG				= L.DBM .. " include una funzionalità avanzata per mostrare i temporizzatore di ricarica dei nemici usando icone sulle barre dei nomi. Questa è attiva per impostazione predefinita per la maggior parte degli utenti, ma per gli utenti di Plater è disattivata di default nelle opzioni di Plater a meno che non la abiliti. Per ottenere il massimo da " .. L.DBM .. " (e Plater) si consiglia di abilitare questa funzionalità in Plater nella sezione \'Buff Special\'. Se non vuoi più vedere questo messaggio, puoi anche disabilitare completamente l\'opzione \'Icone di ricarica sulle barre dei nomi\' nel pannello di disabilitazione globale o in quello delle barre dei nomi di DBM"

L.MOVABLE_BAR		= "Trascinami!"
L.MOVABLE_FRAMES	= "Riquadri Trascinabili"

L.PIZZA_SYNC_INFO	= "|Hplayer:%1$s|h[%1$s]|h ti ha mandato un temporizzatore "..L.DBM..": '%2$s'\n|Haddon:DBM:cancel:%2$s:nil|h|cff3588ff[Cancella questo temporizzatore]|r|h |Haddon:DBM:ignore:%2$s:%1$s|h|cff3588ff[Ignora temporizzatore da %1$s]|r|h"
--L.PIZZA_SYNC_INFO					= "|Hplayer:%1$s|h[%1$s]|h ti ha inviato un temporizzatore "..L.DBM..""
L.PIZZA_CONFIRM_IGNORE	= "Sei sicuro di voler ignorare i temporizzatore DMB da %s per questa sessione?"
L.PIZZA_ERROR_USAGE		= "Uso: /dbm [broadcast] timer <time> <text>"

L.MINIMAP_TOOLTIP_HEADER	= L.DEADLY_BOSS_MODS -- (Identico all'Inglese)
L.MINIMAP_TOOLTIP_FOOTER	= "Tieni premuto Shift per trascinare liberamente"

L.RANGE_TEST_READY				= "Test della portata degli oggetti (%s): richiesta dei dati per %d oggetti. Mantieni l'unità selezionata e resta fuori dal combattimento."
L.RANGE_TEST_INVALID			= "Il test della portata degli oggetti richiede un'unità amichevole o ostile viva e visibile e deve essere eseguito fuori dal combattimento."
L.RANGE_TEST_UNSUPPORTED		= "Test della portata degli oggetti: le API per la portata o la cache degli oggetti non sono disponibili su questo client."
L.RANGE_TEST_ABORTED			= "Test della portata degli oggetti annullato: l'unità è cambiata, non è più disponibile oppure è iniziato un combattimento/caricamento."
L.RANGE_TEST_PASS				= "%d iarde: oggetto %d (%s), IsItemInRange=%s%s"
L.RANGE_TEST_FAIL				= "%d iarde: nessun oggetto utilizzabile (nil con dati in cache: %d, errori/timeout della cache: %d)."
L.RANGE_TEST_INCOMPLETE		= "%d iarde: incompleto (nil con dati in cache: %d, errori/timeout della cache: %d)."
L.RANGE_TEST_PARTIAL			= " (non è stato possibile memorizzare nella cache i candidati precedenti)"
L.RANGE_TEST_HEADER				= "Risultati della portata degli oggetti di DBM (%s). Copia questa stringa; le portate includono +3 iarde."
L.RANGE_TEST_NODATA				= "Nessun test della portata degli oggetti completato è disponibile. Esegui prima DBM:TestRanges."
L.RANGE_TEST_DONE				= "Test della portata degli oggetti completato: %d superati, %d falliti, %d incompleti. Usa DBM:ShowRangeTestResults() per copiare i risultati."
L.RANGE_TEST_SELF				= "Un test su te stesso non dimostra che questi oggetti funzionino su un altro giocatore."
L.RANGE_DISTANCE_NOCANDIDATES	= "Esegui DBM:TestRanges e attendi oggetti utilizzabili prima di misurarne le distanze."
L.RANGE_DISTANCE_INVALID		= "La calibrazione richiede un'altra unità viva e visibile, fuori dal combattimento e in mappe senza restrizioni. Si consiglia un giocatore del gruppo/incursione all'aperto."
L.RANGE_DISTANCE_UNAVAILABLE	= "Calibrazione: letture verificate e non segrete di UnitDistanceSquared o API di portata degli oggetti non disponibili. Prova un giocatore del gruppo/incursione all'aperto."
L.RANGE_DISTANCE_READY		= "Misurazione di %d oggetti (tolleranza +/-0,5 iarde). L'altro giocatore deve restare fermo; allontanati e torna lentamente attraversando i limiti. Ferma/esporta con DBM:StopRangeDistances(true)."
L.RANGE_DISTANCE_REACQUIRE	= "Seleziona di nuovo il bersaglio originale per continuare la calibrazione della portata."
L.RANGE_DISTANCE_ABORTED		= "Calibrazione interrotta: unità, combattimento, caricamento, restrizioni o disponibilità della distanza cambiati. Dati parziali conservati; nessun risultato superato."
L.RANGE_DISTANCE_NODATA		= "Nessuna calibrazione fermata disponibile. Esegui DBM:TestRangeDistances e poi DBM:StopRangeDistances."
L.RANGE_DISTANCE_HEADER		= "Calibrazione delle distanze DBM. Copia questa stringa; le portate previste includono +3 iarde, con tolleranza di +/-0,5 iarde."
L.RANGE_DISTANCE_ROW			= "%d iarde: oggetto %d (%s), %s; true più lontano=%s, false più vicino=%s; true/false=%d/%d, discrepanze=%d, non disponibili=%d%s"
L.RANGE_DISTANCE_PASS		= "SUPERATO"
L.RANGE_DISTANCE_FAIL		= "FALLITO"
L.RANGE_DISTANCE_INCOMPLETE	= "INCOMPLETO (limite poco osservato, letture contraddittorie, campioni non disponibili o prova interrotta)"
L.RANGE_DISTANCE_DONE			= "Calibrazione fermata: %d superati, %d falliti, %d incompleti. Usa DBM:ShowRangeDistanceResults() per copiare i risultati."

L.RANGECHECK_HEADER				= "Distanziometro (%dm)"
L.RANGECHECK_HEADERT			= "Distanziometro (%dm-%dP)"
L.RANGECHECK_RHEADER			= "Distanziometro Inverso (%dD)"
L.RANGECHECK_RHEADERT			= "Distanziometro Inverso (%dm-%dP)"
L.RANGECHECK_SETRANGE			= "Imposta distanza"
L.RANGECHECK_SETTHRESHOLD		= "Imposta soglia giocatore"
L.RANGECHECK_SOUNDS				= "Souni"
L.RANGECHECK_SOUND_OPTION_1		= "Souna quando un giocatore e' in prossimita'"
L.RANGECHECK_SOUND_OPTION_2		= "Souna quando piu' giocatori sono in prossimita'"
L.RANGECHECK_SOUND_0			= "Nessun suono"
L.RANGECHECK_SOUND_1			= "Suono Standard"
L.RANGECHECK_SOUND_2			= "Beep Noioso"
L.RANGECHECK_SETRANGE_TO		= "%d m"
L.RANGECHECK_OPTION_FRAMES		= "Riquadri"
L.RANGECHECK_OPTION_RADAR		= "Visualizza Riquadro Radar"
L.RANGECHECK_OPTION_TEXT		= "Visualizza Riquadro Testuale"
L.RANGECHECK_OPTION_BOTH		= "Visualizza Entrambi i Riquadri"
L.RANGERADAR_HEADER				= "Distanza:%d Giocatori:%d"
L.RANGERADAR_RHEADER			= "Dist.Inv:%d Giocatori:%d"
L.RANGERADAR_IN_RANGE_TEXT		= "%d vicini (%0.1fm)" -- Multi
L.RANGECHECK_IN_RANGE_TEXT		= "%d vicini" -- Text based doesn't need (%dyd), especially since it's not very accurate to the specific yard anyways
L.RANGERADAR_IN_RANGE_TEXTONE	= "%s (%0.1fm)" -- One target

L.INFOFRAME_TITLE			= L.DBM .. " Riquadro Info"
L.INFOFRAME_BOSS_DISTANCE			= "Distanza dei boss"
L.INFOFRAME_BOSS_DISTANCE_RANGE		= "%dm - %dm"
L.INFOFRAME_BOSS_DISTANCE_OVER		= "> %dm"
L.INFOFRAME_SHOW_SELF		= "Visualizza sempre la tua forza"		-- Always show your own power value even if you are below the threshold
L.INFOFRAME_SETLINES		= "Imposta linee massime"
L.INFOFRAME_SETSTRATA		= "Imposta livello del riquadro"
L.INFOFRAME_SETCOLS			= "Imposta colonne massime"
L.INFOFRAME_LINESDEFAULT	= "Imposta per mod"
L.INFOFRAME_LINES_TO		= "%d linee"
L.INFOFRAME_COLS_TO			= "%d colonne"
L.INFOFRAME_POWER			= "Forza"
L.INFOFRAME_AGGRO			= "Aggro"
L.INFOFRAME_MAIN			= "Principale:"--Main power
L.INFOFRAME_ALT				= "Alt:"--Alternate Power

L.LFG_INVITE	= "Invito LFG"

--Common slash commands
L.SLASHCMD_HELP	= {--AI translated (check me)
	"Comandi slash disponibili:",
	"-----------------",
	"/dbm unlock: Mostra un temporizzatore della barra di stato mobile (alias: move).",
	"/dbm pull <sec>: Invia un temporizzatore di ingaggio di <sec> secondi all'incursione (richiede la promozione. alias: pull).",
	"/dbm break <min>: Invia un temporizzatore di pausa di <min> minuti all'incursione (richiede la promozione. alias: break).",
	"/dbm timer: Avvia un temporizzatore personalizzato di " .. L.DBM .. ", vedere '/dbm timer' per dettagli.",
	"/dbm key: Esegue controlli delle chiavi M+ e delle valutazioni su party/gilda e scorciatoie per i teletrasporti delle dungeon. (alias: key, keys, keystone)",
	"/dbm lag: Esegue un controllo della latenza per tutta l'incursione.",
	"/dbm durability: Esegue un controllo della durabilità per tutta l'incursione.",
	"/dbm consumables: Esegue un controllo dei consumabili per tutta l'incursione (alias: cons, consumes).",
	"/dbm brez: Mostra il riquadro del temporizzatore di resurrezione da combattimento per il posizionamento.",--AI translated (check me)
	"/dbm help2: Mostra comandi slash aggiuntivi"
}
--Less used slash commands
L.SLASHCMD_HELP2	= {--AI translated (check me)
	"Comandi slash disponibili:",
	"-----------------",
	"/dbm version: Controlla la versione del boss mod (alias: ver).",
	"/dbm version2: Controlla la versione del boss mod e invia un messaggio agli utenti obsoleti (alias: ver2).",
	"/range <numero> o /distance <numero>: Mostra il riquadro di distanza. /rrange o /rdistance per invertire i colori.",
	"/dbm arrow: Mostra la freccia " .. L.DBM .. ", vedere '/dbm arrow help' per dettagli.",
	"/dbm hud: Mostra l'HUD " .. L.DBM .. ", vedere '/dbm hud' per dettagli.",
	"/dbm dbtdebug: Mostra diagnostica delle barre del tempo ripulita per le segnalazioni di errore."
}
L.DBT_DEBUG_HEADER		= "Diagnostica DBT (ripulita; nessun testo di incontro o segreto)"
L.DBT_DEBUG_EMPTY		= "Nessun aggiornamento di stile DBT è stato acquisito dal ricaricamento dell'interfaccia."
L.DBT_DEBUG_DISABLED	= "L'acquisizione è disattivata. Abilita la modalità di debug di DBM prima di riprodurre il problema."
L.DBT_DEBUG_NOTICE		= "Includi questo output della chat nella segnalazione di errore."
L.TIMER_USAGE			= {
	"Comandi Temporizzatore "..L.DBM..":",
	"-----------------",
	"/dbm timer <sec> <testo>: Avvia un temporizzatore di <sec> secondi con il testo <testo>.",
	"/dbm ltimer <sec> <testo>: Avvia un temporizzatore a ciclo continuo fino ad annullamento.",
	"(Il prefisso 'Broadcast' di qualunque temporizzatore lo condivide se capogruppo/assistente)",
	"/dbm timer endloop: Termina il ciclo di un temporizzatore."
}

L.ERROR_NO_PERMISSION			= "Non hai i permessi per eseguire questo comando."
L.ERROR_NO_PERMISSION_COMBAT	= "Il temporizzatore Pull/Pausa non può essere inviato mentre un incontro è in corso"
L.PULL_TIME_TOO_SHORT			= "Il temporizzatore di pull deve durare più di 3 secondi."
L.PULL_TIME_TOO_LONG			= "Pull temporizzatore cannot be longer than 60 seconds"

L.BREAK_USAGE			= "Il temporizzatore della pausa non può durare più di 60 minuti. Assicurati di aver inserito il tempo in minuti e non in secondi."
L.BREAK_START			= "Inizia la pausa -- hai %s! (Iniziata da %s)"
L.BREAK_MIN				= "La pausa termina tra %s minuto/i!"
L.BREAK_SEC				= "La pausa termina tra %s secondi!"
L.TIMER_BREAK			= "Ora della pausa!"
L.ANNOUNCE_BREAK_OVER	= "La pausa è finita dopo %s."

L.TIMER_PULL				= "Ingaggio"
L.ANNOUNCE_PULL				= "Ingaggio tra %d s. (Iniziato da %s)"
L.ANNOUNCE_PULL_NOW			= "Ingaggia ora!"
L.ANNOUNCE_PULL_TARGET		= "Ingaggio di %s tra %d s. (Iniziato da %s)"
L.ANNOUNCE_PULL_NOW_TARGET	= "Ingaggia %s ora!"
L.GEAR_WARNING				= "Avviso: Controlla l'equipaggiamento. Il livello oggetti equipaggiato è %d meno di quello in borsa."
L.GEAR_WARNING_WEAPON		= "Avviso: Controlla di aver equipaggiato l'arma corretta."
L.GEAR_FISHING_POLE			= "Canna da Pesca"

L.ACHIEVEMENT_TIMER_SPEED_KILL	= "Uccisione Rapida" -- BATTLE_PET_SOURCE_6

-- Auto-generated Warning Localizations
L.AUTO_ANNOUNCE_TEXTS.you			= "%s su di TE"
L.AUTO_ANNOUNCE_TEXTS.target		= "%s su >%%s<"
L.AUTO_ANNOUNCE_TEXTS.targetsource	= ">%%s< casta %s su >%%s<"
L.AUTO_ANNOUNCE_TEXTS.targetcount	= "%s (%%s) su >%%s<"
L.AUTO_ANNOUNCE_TEXTS.blizztarget	= "%s (%%s) su >%%s<"
L.AUTO_ANNOUNCE_TEXTS.spell			= "%s"
L.AUTO_ANNOUNCE_TEXTS.incoming		= "%s debuff in arrivo"
L.AUTO_ANNOUNCE_TEXTS.incomingcount	= "%s debuff in arrivo (%%s)"
L.AUTO_ANNOUNCE_TEXTS.ends			= "%s terminato"
L.AUTO_ANNOUNCE_TEXTS.endtarget		= "%s terminato: >%%s<"
L.AUTO_ANNOUNCE_TEXTS.fades			= "%s svanito"
L.AUTO_ANNOUNCE_TEXTS.fadesoon		= "%s sta per svanire"
L.AUTO_ANNOUNCE_TEXTS.addsleft		= "%s rimanenti: %%d"
L.AUTO_ANNOUNCE_TEXTS.cast			= "Castando %s: %.1f s"
L.AUTO_ANNOUNCE_TEXTS.soon			= "%s a breve"
L.AUTO_ANNOUNCE_TEXTS.sooncount		= "%s (%%s) a breve"
L.AUTO_ANNOUNCE_TEXTS.countdown		= "%s tra %%ds"
L.AUTO_ANNOUNCE_TEXTS.prewarn		= "%s tra %s"
L.AUTO_ANNOUNCE_TEXTS.bait			= "%s a breve - attiralo ora"
L.AUTO_ANNOUNCE_TEXTS.stage			= "Fase %s"
L.AUTO_ANNOUNCE_TEXTS.prestage		= "Fase %s a breve"
L.AUTO_ANNOUNCE_TEXTS.count			= "%s (%%s)"
L.AUTO_ANNOUNCE_TEXTS.stack			= "%s su >%%s< (%%d)"
L.AUTO_ANNOUNCE_TEXTS.moveto		= "%s - vai a >%%s<"

local prewarnOption = "Mostra preavvisi per $spell:%s"
L.AUTO_ANNOUNCE_OPTIONS.you				= "Annuncia quando affetto da $spell:%s"
L.AUTO_ANNOUNCE_OPTIONS.target			= "Annuncia bersagli di $spell:%s"
L.AUTO_ANNOUNCE_OPTIONS.targetNF		= "Annuncia bersagli di $spell:%s (ignora il filtro globale dei bersagli)"
L.AUTO_ANNOUNCE_OPTIONS.targetsource	= "Annuncia bersagli di $spell:%s (con sorgente)"
L.AUTO_ANNOUNCE_OPTIONS.targetcount		= "Annuncia bersagli di $spell:%s (con conteggio)"
L.AUTO_ANNOUNCE_OPTIONS.blizztarget		= "Annuncia bersagli di $spell:%s (con conteggio)"
L.AUTO_ANNOUNCE_OPTIONS.spell			= "Mostra avvisi per $spell:%s"
L.AUTO_ANNOUNCE_OPTIONS.incoming		= "Annuncia quando $spell:%s ha debuff in arrivo"
L.AUTO_ANNOUNCE_OPTIONS.incomingcount	= "Annuncia (con conteggio) quando $spell:%s ha debuff in arrivo"
L.AUTO_ANNOUNCE_OPTIONS.ends			= "Mostra avviso al termine di $spell:%s"
L.AUTO_ANNOUNCE_OPTIONS.endtarget		= "Mostra avviso al termine di $spell:%s"
L.AUTO_ANNOUNCE_OPTIONS.fades			= "Mostra avviso allo svanire di $spell:%s"
L.AUTO_ANNOUNCE_OPTIONS.fadesoon		= "Mostra avviso quando $spell:%s sta per svanire"
L.AUTO_ANNOUNCE_OPTIONS.addsleft		= "Annuncia la quantità di $spell:%s rimanenti"
L.AUTO_ANNOUNCE_OPTIONS.cast			= "Mostra avviso al cast di $spell:%s"
L.AUTO_ANNOUNCE_OPTIONS.soon			= prewarnOption
L.AUTO_ANNOUNCE_OPTIONS.sooncount		= "Mostra preavvisi per $spell:%s (con conteggio)"
L.AUTO_ANNOUNCE_OPTIONS.countdown		= "Mostra spam di conto alla rovescia del preavviso per $spell:%s"
L.AUTO_ANNOUNCE_OPTIONS.prewarn			= prewarnOption
L.AUTO_ANNOUNCE_OPTIONS.bait			= "Mostra preavvisi (per attirare) per $spell:%s"
L.AUTO_ANNOUNCE_OPTIONS.stage			= "Annuncia Fase %s"
L.AUTO_ANNOUNCE_OPTIONS.stagechange		= "Annuncia cambi fase"
L.AUTO_ANNOUNCE_OPTIONS.prestage		= "Mostra preavviso per la Fase %s"
L.AUTO_ANNOUNCE_OPTIONS.count			= "Mostra avviso per $spell:%s (con conteggio)"
L.AUTO_ANNOUNCE_OPTIONS.stack			= "Annuncia stack di $spell:%s"
L.AUTO_ANNOUNCE_OPTIONS.moveto			= "Mostra avvisi per muoverti da qualcuno o qualcosa per $spell:%s"

L.AUTO_SPEC_WARN_TEXTS.spell			= "%s!"
L.AUTO_SPEC_WARN_TEXTS.ends				= "%s terminata"
L.AUTO_SPEC_WARN_TEXTS.endtarget		= "%s terminata: >%%s<"
L.AUTO_SPEC_WARN_TEXTS.fades			= "%s svanita"
L.AUTO_SPEC_WARN_TEXTS.soon				= "%s a breve"
L.AUTO_SPEC_WARN_TEXTS.sooncount		= "%s (%%s) a breve"
L.AUTO_SPEC_WARN_TEXTS.bait				= "%s a breve - attiralo subito"
L.AUTO_SPEC_WARN_TEXTS.prewarn			= "%s tra %s"
L.AUTO_SPEC_WARN_TEXTS.dispel			= "%s su >%%s< - dispellalo subito"
L.AUTO_SPEC_WARN_TEXTS.interrupt		= "%s - interrompi >%%s<!"
L.AUTO_SPEC_WARN_TEXTS.interruptcount	= "%s - interrompi >%%s<! (%%d)"
L.AUTO_SPEC_WARN_TEXTS.you				= "%s su di te"
L.AUTO_SPEC_WARN_TEXTS.youcount			= "%s (%%s) su di te"
L.AUTO_SPEC_WARN_TEXTS.youpos			= "%s (Posizione: %%s) su di te"
L.AUTO_SPEC_WARN_TEXTS.youposcount		= "%s (%%s) (Posizione: %%s) su di te"
L.AUTO_SPEC_WARN_TEXTS.soakpos			= "%s (Entra in Posizione: %%s)"
L.AUTO_SPEC_WARN_TEXTS.target			= "%s su >%%s<"
L.AUTO_SPEC_WARN_TEXTS.targetcount		= "%s (%%s) su >%%s< "
L.AUTO_SPEC_WARN_TEXTS.blizztarget		= "%s (%%s) su >%%s< "
L.AUTO_SPEC_WARN_TEXTS.blizzyou			= "%s (%%s) su di te"
L.AUTO_SPEC_WARN_TEXTS.defensive		= "%s - difensivi"
L.AUTO_SPEC_WARN_TEXTS.taunt			= "%s su >%%s< - tauntalo subito"
L.AUTO_SPEC_WARN_TEXTS.close			= "%s su >%%s< vicino a te"
L.AUTO_SPEC_WARN_TEXTS.move				= "%s - spostati"
L.AUTO_SPEC_WARN_TEXTS.keepmove			= "%s - continua a muoverti"
L.AUTO_SPEC_WARN_TEXTS.stopmove			= "%s - fermati"
L.AUTO_SPEC_WARN_TEXTS.dodge			= "%s - evita l'attacco"
L.AUTO_SPEC_WARN_TEXTS.dodgecount		= "%s (%%s) - evita l'attacco"
L.AUTO_SPEC_WARN_TEXTS.dodgeloc			= "%s - evita da %%s"
L.AUTO_SPEC_WARN_TEXTS.moveaway			= "%s - spostati dagli altri"
L.AUTO_SPEC_WARN_TEXTS.moveawaycount	= "%s (%%s) - spostati dagli altri"
L.AUTO_SPEC_WARN_TEXTS.moveto			= "%s - spostati a >%%s<"
L.AUTO_SPEC_WARN_TEXTS.soak				= "%s - entraci"
L.AUTO_SPEC_WARN_TEXTS.soakcount		= "%s - entraci (%%s)"
L.AUTO_SPEC_WARN_TEXTS.jump				= "%s - salta"
L.AUTO_SPEC_WARN_TEXTS.run				= "%s - scappa"
L.AUTO_SPEC_WARN_TEXTS.runcount			= "%s - scappa (%%s)"
L.AUTO_SPEC_WARN_TEXTS.cast				= "%s - non castare"
L.AUTO_SPEC_WARN_TEXTS.lookaway			= "%s su %%s - distogli lo sguardo"
L.AUTO_SPEC_WARN_TEXTS.reflect			= "%s su >%%s< - non attaccare"
L.AUTO_SPEC_WARN_TEXTS.count			= "%s! (%%s)"
L.AUTO_SPEC_WARN_TEXTS.stack			= "%%d stack di %s su di te"
L.AUTO_SPEC_WARN_TEXTS.switch			= "%s - cambio bersaglio"
L.AUTO_SPEC_WARN_TEXTS.switchcount		= "%s - cambio bersaglio (%%s)"
L.AUTO_SPEC_WARN_TEXTS.gtfo				= "%%s sotto di te - spostati"
L.AUTO_SPEC_WARN_TEXTS.adds				= "Add in Arrivo - cambio bersaglio"
--L.AUTO_SPEC_WARN_TEXTS.addscount							= "Incoming Adds - switch targets (%%s)"--Basically a generic of switch
L.AUTO_SPEC_WARN_TEXTS.addscustom	= "Add in Arrivo - %%s"
L.AUTO_SPEC_WARN_TEXTS.targetchange	= "Cambio Bersaglio - passa a %%s"

-- Auto-generated Special Warning Localizations
L.AUTO_SPEC_WARN_OPTIONS.spell			= "Mostra avviso speciale per $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.ends			= "Mostra avviso speciale al termine di $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.endtarget		= "Mostra avviso speciale (con bersaglio) al termine di $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.fades			= "Mostra avviso speciale allo svanire di $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.soon			= "Mostra preavviso speciale per $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.sooncount		= "Mostra preavviso speciale (con conteggio) per $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.bait			= "Mostra preavviso speciale (per attirare) per $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.prewarn		= "Mostra preavviso speciale di %s secondi prima di $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.dispel			= "Mostra avviso speciale per dispel di $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.interrupt		= "Mostra avviso speciale per interrompere $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.interruptcount	= "Mostra avviso speciale (con conteggio) per interrompere $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.you			= "Mostra avviso speciale quando affetto da $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.youcount		= "Mostra avviso speciale (con conteggio) quando affetto da $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.youpos			= "Mostra avviso speciale (con posizione) quando affetto da $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.youposcount	= "Mostra avviso speciale (con posizione e conteggio) quando affetto da $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.soakpos		= "Mostra avviso speciale (con posizione) per entrare dagli affetti da $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.target			= "Mostra avviso speciale quando qualcuno è affetto da $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.targetcount	= "Mostra avviso speciale (con conteggio) quando qualcuno è affetto da $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.blizztarget	= "Mostra avviso speciale (con conteggio) quando qualcuno è affetto da $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.blizzyou		= "Mostra avviso speciale (con conteggio) quando affetto da $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.defensive		= "Mostra avviso speciale per usare abilità difensive per $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.taunt			= "Mostra avviso speciale per tauntare quando l'altro difensore è affetto da $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.close			= "Mostra avviso speciale quando qualcuno vicino è affetto da $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.move			= "Mostra avviso speciale per spostarti da $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.keepmove		= "Mostra avviso speciale per continuare a muoverti con $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.stopmove		= "Mostra avviso speciale per fermarti con $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.dodge			= "Mostra avviso speciale per evitare $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.dodgecount		= "Mostra avviso speciale (con conteggio) per evitare $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.dodgeloc		= "Mostra avviso speciale (con posizione) per evitare $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.moveaway		= "Mostra avviso speciale per spostarsi dagli altri con $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.moveawaycount	= "Mostra avviso speciale (con conteggio) per spostarsi dagli altri con $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.moveto			= "Mostra avviso speciale per muoverti verso qualcuno o qualcosa per $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.soak			= "Mostra avviso speciale per entrare in $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.soakcount		= "Mostra avviso speciale (con conteggio) per entrarci con $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.jump			= "Mostra avviso speciale per muoverti per saltare per $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.run			= "Mostra avviso speciale per sfuggire da $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.runcount		= "Mostra avviso speciale (con conteggio) per scappare da $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.cast			= "Mostra avviso speciale per non castare per $spell:%s" -- Interruzione Abilità
L.AUTO_SPEC_WARN_OPTIONS.lookaway		= "Mostra avviso speciale per distogliere lo sguardo da $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.reflect		= "Mostra avviso speciale per non attaccare per $spell:%s" -- Riflesso Abilità
L.AUTO_SPEC_WARN_OPTIONS.count			= "Mostra avviso speciale (con conteggio) per $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.stack			= "Mostra avviso speciale quando affetto da >= %d stack di $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.switch			= "Mostra avviso speciale per cambiare bersaglio con $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.switchcount	= "Mostra avviso speciale (con conteggio) per cambiare bersaglio con $spell:%s"
L.AUTO_SPEC_WARN_OPTIONS.gtfo			= "Mostra avviso speciale per spostarsi dalle schifezze a terra"
L.AUTO_SPEC_WARN_OPTIONS.adds			= "Mostra avviso speciale per cambiare bersaglio per l'arrivo di add"
--L.AUTO_SPEC_WARN_OPTIONS.addscount							= "Show special announce (with count) to switch targets for incoming adds"
L.AUTO_SPEC_WARN_OPTIONS.addscustom		= "Mostra avviso speciale per l'arrivo di add"
L.AUTO_SPEC_WARN_OPTIONS.targetchange	= "Mostra avviso speciale per cambio bersaglio prioritario"

-- Auto-generated Timer Localizations
L.AUTO_TIMER_TEXTS.target		= "%s: %%s"
L.AUTO_TIMER_TEXTS.targetcount	= "%s (%%2$s): %%1$s" -- OPTIONAL
L.AUTO_TIMER_TEXTS.cast			= "%s"
L.AUTO_TIMER_TEXTS.castcount	= "%s (%%s)"
L.AUTO_TIMER_TEXTS.castsource	= "%s: %%s"
L.AUTO_TIMER_TEXTS.active		= "%s terminato" -- Buff/Debuff/Eventi su boss
L.AUTO_TIMER_TEXTS.fades		= "%s svanito" -- Buff/Debuff su giocatori
L.AUTO_TIMER_TEXTS.ai			= "%s IA"

L.AUTO_TIMER_TEXTS.cd			= "%s CD"
L.AUTO_TIMER_TEXTS.cdcount		= "%s (%%s) CD"
L.AUTO_TIMER_TEXTS.cdsource		= "%s CD: >%%s<"
L.AUTO_TIMER_TEXTS.cdspecial	= "CD Speciale"

L.AUTO_TIMER_TEXTS.next			= "%s"
L.AUTO_TIMER_TEXTS.nextcount	= "%s (%%s)"
L.AUTO_TIMER_TEXTS.nextsource	= "%s: %%s"
L.AUTO_TIMER_TEXTS.nextspecial	= "Prossimo Speciale"

L.AUTO_TIMER_TEXTS.achievement			= "%s"
L.AUTO_TIMER_TEXTS.stage				= "Prossima Fase"
L.AUTO_TIMER_TEXTS.stagecount			= "Fase %%s" --NOT BUGGED, stage is 2nd arg, spellID is ignored on purpose
L.AUTO_TIMER_TEXTS.stagecountcycle		= "Fase %%s (%%s)" --^^. Example: Stage 2 (3) for a fight that alternates stage 1 and stage 2, but also tracks total cycles
L.AUTO_TIMER_TEXTS.stagecontext			= "%s" -- OPTIONAL
L.AUTO_TIMER_TEXTS.stagecontextcount	= "%s (%%s)" -- OPTIONAL
L.AUTO_TIMER_TEXTS.intermission			= "Interfase"
L.AUTO_TIMER_TEXTS.intermissioncount	= "Interfase %%s"
L.AUTO_TIMER_TEXTS.adds					= "Adds"
L.AUTO_TIMER_TEXTS.addscount			= "Adds (%%s)"
L.AUTO_TIMER_TEXTS.addscustom			= "Adds (%%s)"
L.AUTO_TIMER_TEXTS.roleplay				= GUILD_INTEREST_RP
L.AUTO_TIMER_TEXTS.combat				= "Inizio combattimento"
--This basically clones np only bar option and display text from regular counterparts
L.AUTO_TIMER_TEXTS.cdnp		= L.AUTO_TIMER_TEXTS.cd -- OPTIONAL
L.AUTO_TIMER_TEXTS.nextnp	= L.AUTO_TIMER_TEXTS.next -- OPTIONAL
L.AUTO_TIMER_TEXTS.cdpnp	= L.AUTO_TIMER_TEXTS.cd -- OPTIONAL
L.AUTO_TIMER_TEXTS.nextpnp	= L.AUTO_TIMER_TEXTS.next -- OPTIONAL
L.AUTO_TIMER_TEXTS.castpnp	= L.AUTO_TIMER_TEXTS.cast -- OPTIONAL

L.AUTO_TIMER_OPTIONS.target				= "Mostra temporizzatore debuff di $spell:%s"
L.AUTO_TIMER_OPTIONS.targetcount		= "Mostra temporizzatore (con conteggio) debuff di $spell:%s"
L.AUTO_TIMER_OPTIONS.cast				= "Mostra temporizzatore cast di $spell:%s"
L.AUTO_TIMER_OPTIONS.castcount			= "Mostra temporizzatore (con conteggio) cast di $spell:%s"
L.AUTO_TIMER_OPTIONS.castsource			= "Mostra temporizzatore (con sorgente) cast di $spell:%s"
L.AUTO_TIMER_OPTIONS.active				= "Mostra temporizzatore durata di $spell:%s"
L.AUTO_TIMER_OPTIONS.fades				= "Mostra temporizzatore allo svanire di $spell:%s dai giocatori"
L.AUTO_TIMER_OPTIONS.ai					= "Mostra temporizzatore AI ricarica $spell:%s"
L.AUTO_TIMER_OPTIONS.cd					= "Mostra temporizzatore ricarica $spell:%s"
L.AUTO_TIMER_OPTIONS.cdcount			= "Mostra temporizzatore ricarica cooldown $spell:%s"
L.AUTO_TIMER_OPTIONS.cdnp				= "Mostra temporizzatore solo sulla Barra del Nome per la ricarica di $spell:%s"
L.AUTO_TIMER_OPTIONS.cdsource			= "Mostra temporizzatore (con sorgente) ricarica $spell:%s"
L.AUTO_TIMER_OPTIONS.cdspecial			= "Mostra temporizzatore ricarica dell'abilità speciale"
L.AUTO_TIMER_OPTIONS.cdcombo			= "Mostra temporizzatore per la ricarica di combo di abilità" --Used for combining 2 abilities into a single timer
L.AUTO_TIMER_OPTIONS.next				= "Mostra temporizzatore prossima $spell:%s"
L.AUTO_TIMER_OPTIONS.nextcount			= "Mostra temporizzatore prossima $spell:%s"
L.AUTO_TIMER_OPTIONS.nextnp				= "Mostra temporizzatore solo sulla Barra del Nome per la prossima $spell:%s"
L.AUTO_TIMER_OPTIONS.nextsource			= "Mostra temporizzatore (con sorgente) per prossima $spell:%s"
L.AUTO_TIMER_OPTIONS.nextspecial		= "Mostra temporizzatore prossima abilità speciale"
L.AUTO_TIMER_OPTIONS.nextcombo			= "Mostra temporizzatore per la prossima combo di abilità" --Used for combining 2 abilities into a single timer
L.AUTO_TIMER_OPTIONS.achievement		= "Mostra temporizzatore %s"
L.AUTO_TIMER_OPTIONS.stage				= "Mostra temporizzatore per prossima fase"
L.AUTO_TIMER_OPTIONS.stagecount			= "Mostra temporizzatore (con conteggio) per la prossima fase"
L.AUTO_TIMER_OPTIONS.stagecountcycle	= "Mostra temporizzatore (con conteggio fase e ciclo) per la prossima fase"
L.AUTO_TIMER_OPTIONS.stagecontext		= "Mostra temporizzatore per la prossima fase di $spell:%s"
L.AUTO_TIMER_OPTIONS.stagecontextcount	= "Mostra temporizzatore (con conteggio) per la prossima fase di $spell:%s"
L.AUTO_TIMER_OPTIONS.intermission		= "Mostra temporizzatore per la prossima interfase"
L.AUTO_TIMER_OPTIONS.intermissioncount	= "Mostra temporizzatore (con conteggio) per la prossima interfase"
L.AUTO_TIMER_OPTIONS.adds				= "Mostra temporizzatore add in arrivo"
L.AUTO_TIMER_OPTIONS.addscount			= "Mostra temporizzatore add (con conteggio) in arrivo"
L.AUTO_TIMER_OPTIONS.addscustom			= "Mostra temporizzatore add in arrivo"
L.AUTO_TIMER_OPTIONS.roleplay			= "Mostra temporizzatore durata gioco di ruolo"
L.AUTO_TIMER_OPTIONS.combat				= "Mostra temporizzatore inizio combattimento"

L.AUTO_ICONS_OPTION_TARGETS 			= "Imposta icone sui bersagli di $spell:%s"
L.AUTO_ICONS_OPTION_TARGETS_TANK_A 		= "Imposta icone sui bersagli di $spell:%s con priorità tank su melee su ranged e fallback alfabetico"
L.AUTO_ICONS_OPTION_TARGETS_TANK_R 		= "Imposta icone sui bersagli di $spell:%s con priorità tank su melee su ranged e fallback sul roster dell'incursione"
L.AUTO_ICONS_OPTION_TARGETS_MELEE_A 	= "Imposta icone sui bersagli di $spell:%s con priorità melee e fallback alfabetico"
L.AUTO_ICONS_OPTION_TARGETS_MELEE_R 	= "Imposta icone sui bersagli di $spell:%s con priorità melee e fallback sul roster dell'incursione"
L.AUTO_ICONS_OPTION_TARGETS_RANGED_A 	= "Imposta icone sui bersagli di $spell:%s con priorità ranged e fallback alfabetico"
L.AUTO_ICONS_OPTION_TARGETS_RANGED_R 	= "Imposta icone sui bersagli di $spell:%s con priorità ranged e fallback sul roster dell'incursione"
L.AUTO_ICONS_OPTION_TARGETS_ALPHA 		= "Imposta icone sui bersagli di $spell:%s con priorità alfabetica"
L.AUTO_ICONS_OPTION_TARGETS_ROSTER 		= "Imposta icone sui bersagli di $spell:%s con priorità sul roster dell'incursione"
L.AUTO_ICONS_OPTION_TARGETS_MRH 		= "Imposta icone sui bersagli di $spell:%s con priorità melee su ranged su healer e fallback sul roster dell'incursione"
L.AUTO_ICONS_OPTION_TARGETS_TOH 		= "Imposta icone sui bersagli di $spell:%s con priorità tank su DPS su healer e fallback sul roster dell'incursione"
L.AUTO_ICONS_OPTION_NPCS				= "Imposta icone su $spell:%s"
L.AUTO_ICONS_OPTION_CONFLICT			= " (Potrebbe entrare in conflitto con altre opzioni)"

L.AUTO_ARROW_OPTION_TEXT	= "Mostra la Freccia "..L.DBM.." per muoversi verso i bersagli affetti da $spell:%s"
L.AUTO_ARROW_OPTION_TEXT2	= "Mostra la Freccia "..L.DBM.." per scansarsi dai bersagli affetti da $spell:%s"
L.AUTO_ARROW_OPTION_TEXT3	= "Mostra la Freccia "..L.DBM.." per muoversi verso località specifiche per $spell:%s"

L.AUTO_YELL_OPTION_TEXT.shortyell		= "Urla quando affetto da $spell:%s"
L.AUTO_YELL_OPTION_TEXT.yell			= "Urla (con nome giocatore) quando affetto da $spell:%s"
L.AUTO_YELL_OPTION_TEXT.count			= "Urla (con conteggio) quando affetto da $spell:%s"
L.AUTO_YELL_OPTION_TEXT.fade			= "Urla (con conto alla rovescia e nome abilità) allo svanire di $spell:%s"
L.AUTO_YELL_OPTION_TEXT.shortfade		= "Urla (con conto alla rovescia) allo svanire di $spell:%s"
L.AUTO_YELL_OPTION_TEXT.iconfade		= "Urla (con conto alla rovescia ed icona) allo svanire di $spell:%s"
L.AUTO_YELL_OPTION_TEXT.position		= "Urla (con posizione) quando affetto da $spell:%s"
L.AUTO_YELL_OPTION_TEXT.shortposition	= "Urla (con posizione) quando affetto da $spell:%s"
L.AUTO_YELL_OPTION_TEXT.combo			= "Urla (con testo personalizzato) quando affetto da $spell:%s e altre allo stesso tempo"
L.AUTO_YELL_OPTION_TEXT.repeatplayer	= "Urla ripetutamente (con nome giocatore) quando affetto da $spell:%s"
L.AUTO_YELL_OPTION_TEXT.repeaticon		= "Urla ripetutamente (con icona) quando affetto da $spell:%s"

L.AUTO_YELL_ANNOUNCE_TEXT.shortyell		= "%s"
L.AUTO_YELL_ANNOUNCE_TEXT.yell			= "%s su " .. UnitName("player")
L.AUTO_YELL_ANNOUNCE_TEXT.count			= "%s su " .. UnitName("player") .. " (%%d)"
L.AUTO_YELL_ANNOUNCE_TEXT.fade			= "%s svanisce tra %%d"
L.AUTO_YELL_ANNOUNCE_TEXT.shortfade		= "%%d"
L.AUTO_YELL_ANNOUNCE_TEXT.iconfade		= "{rt%%2$d}%%1$d"
L.AUTO_YELL_ANNOUNCE_TEXT.position		= "%s %%s su {rt%%d}"..UnitName("player").."{rt%%d}"
L.AUTO_YELL_ANNOUNCE_TEXT.shortposition	= "{rt%%1$d}%s" --Icon, Spellname -- OPTIONAL
L.AUTO_YELL_ANNOUNCE_TEXT.combo			= "%s e %%s" -- Nome abilità (da opzioni, più nome abilità passata in arg)
L.AUTO_YELL_ANNOUNCE_TEXT.repeatplayer	= UnitName("player") --Doesn't need translation, it's just player name spam -- OPTIONAL
L.AUTO_YELL_ANNOUNCE_TEXT.repeaticon	= "{rt%%1$d}" --Doesn't need translation. It's just icon spam -- OPTIONAL

L.AUTO_YELL_CUSTOM_POSITION				= "{rt%d}%s"--Doesn't need translating. Has no strings
L.AUTO_YELL_CUSTOM_FADE					= "%s svanito"
L.AUTO_NAMEPLATE_OPTION_TEXT			= "Mostra l'Aura della Barra del Nome per $spell:%s"
L.AUTO_NAMEPLATE_OPTION_TEXT_FORCED		= "Mostra le Aure della Barra del Nome per $spell:%s usando solo " .. L.DBM
L.AUTO_RANGE_OPTION_TEXT				= "Mostra distanziometro (%s) per $spell:%s" -- string used for range so we can use things like "5/2" as a value for that field
L.AUTO_RANGE_OPTION_TEXT_SHORT			= "Mostra distanziometro (%s)" -- For when a range frame is just used for more than one thing
L.AUTO_RRANGE_OPTION_TEXT				= "Mostra distanziometro invertito (%s) per $spell:%s" -- Reverse range frame (green when players in range, red when not)
L.AUTO_RRANGE_OPTION_TEXT_SHORT			= "Mostra distanziometro invertito (%s)"
L.AUTO_INFO_FRAME_OPTION_TEXT			= "Mostra riquadro informativo per $spell:%s"
L.AUTO_INFO_FRAME_OPTION_TEXT2			= "Mostra riquadro informativo per la panoramica scontro"
L.AUTO_INFO_FRAME_OPTION_TEXT3			= "Mostra riquadro informativo per $spell:%s (quando viene raggiunta la soglia di %%s)"
L.AUTO_READY_CHECK_OPTION_TEXT			= "Riproduti il suono controllo gruppo al pull del boss (anche se non bersagliato)"
L.AUTO_GOSSIP_BUFFS						= "Seleziona automaticamente la/le scelta/e di dialogo per i buff da NPC o da professione"
L.AUTO_GOSSIP_PERFORM_ACTION			= "Seleziona automaticamente la/le scelta/e di dialogo per eseguire azioni (come usare i trasporti)"
L.AUTO_GOSSIP_START_ENCOUNTER			= "Seleziona automaticamente la scelta di dialogo per iniziare l'incontro"
L.AUTO_SPEEDCLEAR_OPTION_TEXT			= "Mostra temporizzatore per il completamento più veloce di questa zona"
L.AUTO_PRIVATEAURA_OPTION_TEXT			= "Esegui avvisi sonori di aura DBM per $spell:%s in questo scontro."
L.AUTO_PRIVATEAURA_OPTION_TARGET_TEXT	= "Esegui avvisi sonori di aura DBM quando sei bersagliato da $spell:%s."
L.AUTO_PRIVATEAURA_OPTION_GTFO_TEXT		= "Esegui avvisi sonori di aura DBM quando devi allontanarti da $spell:%s."
L.AUTO_PRIVATEAURA_OPTION_POST_TEXT		= "Esegui avvisi sonori di aura DBM per gli effetti persistenti di $spell:%s."
L.AUTO_CUSTOMTIMER_OPTION_TEXT			= "Mostra temporizzatore per $spell:%s"
L.AUTO_CUSTOMALERT_OPTION_TEXT			= "Imposta suono di avviso per quando $spell:%s sta per essere castato"

-- New special warnings
L.MOVE_WARNING_BAR				= "Annunci mobili"
L.MOVE_WARNING_MESSAGE			= "Grazie per utilizzare "..L.DEADLY_BOSS_MODS..""
L.MOVE_SPECIAL_WARNING_BAR		= "Avvisi speciali mobili"
L.MOVE_SPECIAL_WARNING_TEXT		= "Avvisi Speciali"
L.MOVE_PRIVATE_AURA_TEXT		= "<valore segreto> ti bersaglia con l'incantesimo <valore segreto>"
L.MOVE_PRIVATE_AURA_DISABLED	= "L'anteprima è disabilitata perché i Riquadri delle Aure sono disabilitati globalmente nelle opzioni."

L.ARROW_MOVABLE		= "Freccia mobile"
L.ARROW_WAY_USAGE	= "/dway <x> <y>: Crea una freccia che punta in una posizione specifica (utilizzando coordinate zona locale)"
L.ARROW_WAY_SUCCESS	= "Per nascondere la freccia, scrivi '/dbm arrow hide' o raggiungi la freccia"
L.ARROW_ERROR_USAGE	= {
	"Utilizzo di "..L.DBM.."-Arrow:",
	"-----------------",
	"/dbm arrow <x> <y>: Crea una freccia che punta in una posizione specifica (utilizzando coordinate mondo)",
	"/dbm arrow map <x> <y>: Crea una freccia che punta in una posizione specifica (utilizzando coordinate zona)",
	"/dbm arrow <giocatore>: Crea una freccia che punta verso un giocatore specifico nel tuo gruppo o nell'incursione (distingue tra maiuscole e minuscole!).",
	"/dbm arrow hide: Nasconde la freccia",
	"/dbm arrow move: Rende la freccia mobile"
}

L.SPEED_KILL_TIMER_TEXT		= "Record Vittoria"
L.SPEED_CLEAR_TIMER_TEXT	= "Migliore Clear"
L.TIMER_RESPAWN				= "Respawn %s"

L.LAG_HEADER			= L.DBM.." - Risultati Latenza"
L.DUR_HEADER			= L.DBM.." - Risultati Stato Equipaggiamento"
L.GEAR_HEADER			= L.DBM.. " - Controllo equipaggiamento"
L.GEAR_MISSING_GEMS		= "Gemme mancanti"
L.GEAR_MISSING_ENCHANTS	= "Incantamenti mancanti"
L.GEAR_DURABILITY					= "Dur. %"
L.GEAR_BROKEN						= "Rotto"
L.RAIDCHECKS_TAB_CONSUMABLES		= "Consumabili"
L.RAIDCHECKS_TAB_GEAR				= "Equipaggiamento"
L.RAIDCHECKS_TAB_LATENCY			= "Latenza"
L.CONSUMABLES_HEADER				= L.DBM.. " - Controllo consumabili"
L.CONSUMABLES_FLASK					= "Tonico"
L.CONSUMABLES_FOOD					= "Cibo"
L.CONSUMABLES_WEAPON				= "Arma"
L.CONSUMABLES_HS					= "Pietra della salute"
L.CONSUMABLES_RUNE					= "Runa"
L.CONSUMABLES_NA					= "N/D"
L.BREZ_HEADER						= "Resurrezione in combattimento"
L.KEYSTONES_HEADER		= L.DBM .. " - Chiavi"

L.OVERRIDE_ACTIVATED	= "Le sostituzioni di configurazione sono state attivate per questo incontro dal RL"

--LDB
L.LDB_TOOLTIP_HELP1	= "Clicca per aprire "..L.DBM..""
L.LDB_TOOLTIP_HELP2	= "Clicca col tasto destro per aprire la configurazione"
L.SILENTMODE_IS		= "Modalità silente: "

--L.WORLD_BUFFS.hordeOny							= "People of the Horde, citizens of Orgrimmar, come, gather round and celebrate a hero of the Horde",
--L.WORLD_BUFFS.allianceOny							= "Citizens and allies of Stormwind, on this day, history has been made.",
--L.WORLD_BUFFS.hordeNef							= "NEFARIAN IS SLAIN! People of Orgrimmar",
--L.WORLD_BUFFS.allianceNef							= "Citizens of the Alliance, the Lord of Blackrock is slain!",
--L.WORLD_BUFFS.zgHeart								= "Now, only one step remains to rid us of the Soulflayer's threat",
--L.WORLD_BUFFS.zgHeartBooty						= "The Blood God, the Soulflayer, has been defeated!  We are imperiled no longer!",
--L.WORLD_BUFFS.zgHeartYojamba						= "Begin the ritual, my servants.  We must banish the heart of Hakkar back into the void!",
--L.WORLD_BUFFS.rendHead							= "The false Warchief, Rend Blackhand, has fallen!",
--L.WORLD_BUFFS.blackfathomBoon						= "boon of Blackfathom"

-- Difficulty info not found in normal globals, used by both GUI and tooltip
L.FOLLOWER	= "Seguace"--i.e. the new dungeon type in 10.2.5. I haven't found a translated string yet
L.STORY		= PLAYER_DIFFICULTY_STORY_RAID or "Storia"--i.e. the new dungeon type in 11.0.0. I haven't found a translated string yet
L.DUOS		= "Duo"

-- Keystone dungeon names (keep to a max of 6 characters)
-- See https://wago.tools/db2/MapChallengeMode for ID => Dungeon Names
--L.KEYSTONE_NAMES[378] = 'HOA' -- Halls of Atonement
--L.KEYSTONE_NAMES[391] = 'STREET' -- Tazavesh: Streets of Wonder
--L.KEYSTONE_NAMES[392] = 'GAMBIT' -- Tazavesh: So'leah's Gambit
--L.KEYSTONE_NAMES[499] = 'PRIORY' -- Priority of the Sacred Flame
--L.KEYSTONE_NAMES[503] = 'ARAK' -- Ara-Kara, City of Echoes
--L.KEYSTONE_NAMES[505] = 'DAWN' -- The Dawnbreaker
--L.KEYSTONE_NAMES[525] = 'FLOOD' -- Operation Floodgate
--L.KEYSTONE_NAMES[542] = 'DOME' -- Eco-Dome Al'dani

-- Tests

-- Boss tooltip
L.TOOLTIP_DBM			= L.DBM .. " info"
L.TOOLTIP_ENRAGE_TIMER	= "Temporizzatore dell'Enrage"
L.TOOLTIP_KILLS			= "Uccisioni (%s)"
L.TOOLTIP_WIPES			= "Disfatte (%s)"
L.TOOLTIP_FASTEST		= "Uccisione più veloce (%s)"

-- Midnight jazz
L.MN_TIMELINE_HEADER	= "Vuoi usare la Timeline di Blizzard o le Barre di DBM?"
L.MN_BLIZZARD_TIMELINE	= "Timeline di Blizzard"
L.MN_DBM_TIMELINE		= "Barre di DBM"
L.MN_WARNIGS_HEADER		= "Vuoi usare gli Avvisi di Incontro di Blizzard o quelli di DBM?"
L.MN_BLIZZARD_WARNINGS	= "Avvisi di Blizzard"
L.MN_DBM_WARNINGS		= "Avvisi di DBM"
L.MN_TEXT_TIMERS_HEADER	= "Vuoi usare i timer testuali?\n(Usa i dati delle barre DBM, anche se non sono visibili)"
