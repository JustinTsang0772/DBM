---@class DBMCoreNamespace
local private = select(2, ...)

local twipe, unpack = table.wipe, unpack
local floor = math.floor
local GetTime = GetTime
local pairs = pairs
local LastInstanceMapID = -1

local schedulerFrame = CreateFrame("Frame", "DBMScheduler")
schedulerFrame:Hide()

---@class DBMScheduler: DBMModule
local module = private:NewModule("DBMScheduler")

--------------------------
--  OnUpdate/Scheduler  --
--------------------------

-- stack that stores a few tables (up to 8) which will be recycled
local popCachedTable, pushCachedTable
local numChachedTables = 0
local activeUpdateMods = {}
local activeUpdateFuncs = {}
local activeUpdateCount = 0
do
	local tableCache

	-- gets a table from the stack, it will then be recycled.
	function popCachedTable()
		local t = tableCache
		if t then
			tableCache = t.next
			numChachedTables = numChachedTables - 1
		end
		return t
	end

	-- tries to push a table on the stack
	-- only tables with <= 4 array entries are accepted as cached tables are only used for tasks with few arguments as we don't want to have big arrays wasting our precious memory space doing nothing...
	-- also, the maximum number of cached tables is limited to 8 as DBM rarely has more than eight scheduled tasks with less than 4 arguments at the same time
	-- this is just to re-use all the tables of the small tasks that are scheduled all the time (like the wipe detection)
	-- note that the cache does not use weak references anywhere for performance reasons, so a cached table will never be deleted by the garbage collector
	---@param t table
	function pushCachedTable(t)
		if numChachedTables < 8 and #t <= 4 then
			twipe(t)
			t.next = tableCache
			tableCache = t
			numChachedTables = numChachedTables + 1
		end
	end
end

-- priority queue (min-heap) that stores all scheduled tasks.
-- insert: O(log n)
-- deleteMin: O(log n)
-- getMin: O(1)
-- removeAllMatching: O(n)
local insert, removeAllMatching, getMin, deleteMin
do
	local heap = {}
	local firstFree = 1

	-- gets the next task
	function getMin()
		return heap[1]
	end

	-- restores the heap invariant by moving an item up
	local function siftUp(n)
		local parent = floor(n / 2)
		while n > 1 and heap[parent].time > heap[n].time do -- move the element up until the heap invariant is restored, meaning the element is at the top or the element's parent is <= the element
			heap[n], heap[parent] = heap[parent], heap[n] -- swap the element with its parent
			n = parent
			parent = floor(n / 2)
		end
	end

	-- restores the heap invariant by moving an item down
	local function siftDown(n)
		local m -- position of the smaller child
		while 2 * n < firstFree do -- #children >= 1
			-- swap the element with its smaller child
			if 2 * n + 1 == firstFree then -- n does not have a right child --> it only has a left child as #children >= 1
				m = 2 * n -- left child
			elseif heap[2 * n].time < heap[2 * n + 1].time then -- #children = 2 and left child < right child
				m = 2 * n -- left child
			else -- #children = 2 and right child is smaller than the left one
				m = 2 * n + 1 -- right
			end
			if heap[n].time <= heap[m].time then -- n is <= its smallest child --> heap invariant restored
				return
			end
			heap[n], heap[m] = heap[m], heap[n]
			n = m
		end
	end

	-- inserts a new element into the heap
	function insert(ele)
		heap[firstFree] = ele
		siftUp(firstFree)
		firstFree = firstFree + 1
	end

	-- deletes the min element
	function deleteMin()
		local min = heap[1]
		firstFree = firstFree - 1
		heap[1] = heap[firstFree]
		heap[firstFree] = nil
		siftDown(1)
		return min
	end

	-- removes multiple scheduled tasks from the heap
	-- note that this function is comparatively slow by design as it has to check all tasks and allows partial matches
	function removeAllMatching(f, mod, ...)
		-- remove all elements that match the signature, this destroys the heap and leaves a compacted array
		local v, match
		local foundMatch = false
		local writeIndex = 1
		local argCount = select("#", ...)
		for i = 1, firstFree - 1 do
			v = heap[i]
			match = (not f or v.func == f or v.loopFunc == f) and (not mod or v.mod == mod)
			if match and argCount > 0 then
				for j = 1, argCount do
					if select(j, ...) ~= v[j] then
						match = false
						break
					end
				end
			end
			if match then
				foundMatch = true
			else
				heap[writeIndex] = v
				writeIndex = writeIndex + 1
			end
		end
		-- rebuild the heap from the array in O(n)
		if foundMatch then
			for i = writeIndex, firstFree - 1 do
				heap[i] = nil
			end
			firstFree = writeIndex
			for i = floor((firstFree - 1) / 2), 1, -1 do
				siftDown(i)
			end
		end
	end
end

local nextModSyncSpamUpdate = 0
local function rebuildActiveUpdateFunctions()
	twipe(activeUpdateMods)
	twipe(activeUpdateFuncs)
	activeUpdateCount = 0
	for mod, func in pairs(private.updateFunctions) do
		if mod.Options.Enabled and (not mod.zones or mod.zones[LastInstanceMapID]) then
			activeUpdateCount = activeUpdateCount + 1
			activeUpdateMods[activeUpdateCount] = mod
			activeUpdateFuncs[activeUpdateCount] = func
		end
	end
	private.updateFunctionsDirty = false
end
--mainFrame:SetScript("OnUpdate", function(self, elapsed)
local function onUpdate(self, elapsed)
	local time = GetTime()

	-- execute scheduled tasks
	local nextTask = getMin()
	while nextTask and nextTask.func and nextTask.time <= time do
		deleteMin()
		nextTask.func(unpack(nextTask, 1, nextTask.n))
		pushCachedTable(nextTask)
		nextTask = getMin()
	end

	-- execute OnUpdate handlers of all modules
	if private.updateFunctionsDirty then
		rebuildActiveUpdateFunctions()
	end
	local foundModFunctions = activeUpdateCount
	for i = 1, activeUpdateCount do
		local mod = activeUpdateMods[i]
		local func = activeUpdateFuncs[i]
		mod.elapsed = (mod.elapsed or 0) + elapsed
		if mod.elapsed >= (mod.updateInterval or 0) then
			func(mod, mod.elapsed)
			mod.elapsed = 0
		end
	end

	-- clean up sync spam timers and auto respond spam blockers
	if time > nextModSyncSpamUpdate then
		nextModSyncSpamUpdate = time + 20
		-- Every 20 seconds, iterate over private.modSyncSpam with pairs to remove entries older than 8 seconds, which only prevents a small potential memory leak because the sync functions themselves also check the timestamp.
		for k, v in pairs(private.modSyncSpam) do
			if time - v > 8 then
				private.modSyncSpam[k] = nil
			end
		end
	end
	if not nextTask and foundModFunctions == 0 then -- Nothing left, stop scheduler
		schedulerFrame:SetScript("OnUpdate", nil)
		schedulerFrame:Hide()
	end
end

function module:StartScheduler()
	if not schedulerFrame:IsShown() then
		schedulerFrame:Show()
		schedulerFrame:SetScript("OnUpdate", onUpdate)
	end
end

--For updating zone cache locally
--without needing to monitor for changes in onupdate functions or registering zone change events
function module:UpdateZone()
	LastInstanceMapID = DBM and DBM:GetCurrentArea() or -1
	private.updateFunctionsDirty = true
	-- Ensure scheduler is running if there are update functions that may become active in the new zone
	-- Check if any handler would actually be active in the new zone before starting
	if private.updateFunctions then
		for mod, _ in pairs(private.updateFunctions) do
			if mod.Options.Enabled and (not mod.zones or mod.zones[LastInstanceMapID]) then
				module:StartScheduler()
				break
			end
		end
	end
end

local function schedule(t, f, mod, ...)
	if type(f) ~= "function" then
		error("usage: schedule(time, func, [mod, args...])", 2)
	end
	module:StartScheduler()
	local now = GetTime()
	local argCount = select("#", ...)
	local v
	if numChachedTables > 0 and argCount <= 4 then -- a cached table is available and all arguments fit into an array with four slots
		v = popCachedTable()
		v.time = now + t
		v.func = f
		v.mod = mod
		v.n = argCount
		for i = 1, argCount do
			v[i] = select(i, ...)
		end
		-- clear slots if necessary
		for i = argCount + 1, 4 do
			v[i] = nil
		end
	else -- create a new table
		v = {time = now + t, func = f, mod = mod, n = argCount, ...}
	end
	insert(v)
	return v
end

local function unschedule(f, mod, ...)
	if not f and not mod then
		--Dangerous to use, should only ever happen with a force disable
		removeAllMatching()
	end
	return removeAllMatching(f, mod, ...)
end

--Boss mod prototype usage methods (for announces countdowns/loops and yell scheduling
---@param time number?
---@param numAnnounces number?
---@param func any
---@param mod DBMMod
---@param prototype Announce|SpecialWarning|Timer|Yell|EnrageTimer
function module:ScheduleCountdown(time, numAnnounces, func, mod, prototype, ...)
	time = time or 5
	numAnnounces = numAnnounces or 3
	for i = 1, numAnnounces do
		--In event time is < numbmer of announces (ie 2 second time, with 3 announces)
		local validTime = time - i
		if validTime >= 1 then
			schedule(validTime, func, mod, prototype, i, ...)
		end
	end
end

do
	---@param time number|table
	---@param func any
	---@param mod DBMMod
	---@param prototype Announce|SpecialWarning|Timer|Yell|EnrageTimer
	---@param count number|string
	---@param isTimer boolean?
	---@param voiceString VPSound?
	function module:ScheduleLoop(time, func, mod, prototype, count, isTimer, voiceString)
		if type(time) == "table" then
			--Intervals are relative to the previous occurrence. Queue the finite
			--sequence normally so cancellation cannot leave a rescheduler behind.
			local delay = 0
			for i = (count or 0) + 1, #time do
				if isTimer then
					schedule(delay == 0 and 0.0001 or delay, func, mod, prototype, time[i], i)
					delay = delay + time[i]
				else
					delay = delay + time[i]
					schedule(delay, func, mod, prototype, voiceString or i)
				end
			end
		else
			if type(time) ~= "number" or time <= 0 then
				error("usage: ScheduleLoop requires a positive interval or a table of intervals", 2)
			end
			local repeatScheduleLoop
			local function queueNext(delay, nextCount)
				local task
				if isTimer then
					task = schedule(delay, repeatScheduleLoop, mod, prototype, time, nextCount)
				else
					task = schedule(delay, repeatScheduleLoop, mod, prototype, voiceString or nextCount)
				end
				--Keep the public callback and arguments matchable by Unschedule.
				task.loopFunc = func
			end
			repeatScheduleLoop = function(...)
				if count or isTimer then count = (count or 0) + 1 end
				--Queue before dispatch so cancellation inside func also cancels the loop.
				queueNext(time, (count or isTimer) and (count or 0) + 1 or nil)
				func(...)
			end
			queueNext(isTimer and 0.0001 or time, (count or isTimer) and (count or 0) + 1 or nil)
		end
	end

	function module:Schedule(t, f, mod, ...)
		if type(f) ~= "function" then
			error("usage: DBM:Schedule(time, func, [args...])", 2)
		end
		schedule(t, f, mod, ...)
	end

	function module:Unschedule(f, mod, ...)
		return unschedule(f, mod, ...)
	end
end

