---@class DBMCoreNamespace
local private = select(2, ...)

local L = DBM_CORE_L
local CL = DBM_COMMON_L

local DBMScheduler = private:GetModule("DBMScheduler")
local stringUtils = private:GetPrototype("StringUtils")
local checkEntry = private:GetPrototype("TableUtils").checkEntry
local RAID_CLASS_COLORS = _G["CUSTOM_CLASS_COLORS"] or RAID_CLASS_COLORS-- for Phanx' Class Colors

---@class DBM
local DBM = private:GetPrototype("DBM")
---@class DBMMod
local bossModPrototype = private:GetPrototype("DBMMod")

private.blizzTargetSpecialWarningQueue = private.blizzTargetSpecialWarningQueue or setmetatable({}, {__mode = "k"})
local blizzTargetSpecialWarningQueue = private.blizzTargetSpecialWarningQueue
private.blizzYouSpecialWarningQueue = private.blizzYouSpecialWarningQueue or setmetatable({}, {__mode = "k"})
local blizzYouSpecialWarningQueue = private.blizzYouSpecialWarningQueue

---@param queue table
---@param entry table
local function removeBlizzTargetSpecialWarningQueueEntry(queue, entry)
	for i = #queue.ordered, 1, -1 do
		if queue.ordered[i] == entry then
			table.remove(queue.ordered, i)
			break
		end
	end
end

---@param specWarnObject SpecialWarning
---@param count number?
---@param voiceName string?
---@param expireOverride number?
function DBM:QueueBlizzTargetSpecialWarning(specWarnObject, count, voiceName, expireOverride)
	if not specWarnObject or specWarnObject.announceType ~= "blizztarget" then return end
	local mod = specWarnObject.mod
	if not mod then return end
	local queue = blizzTargetSpecialWarningQueue[mod]
	if not queue then
		queue = {
			ordered = {}
		}
		blizzTargetSpecialWarningQueue[mod] = queue
	end
	local expireSeconds = type(expireOverride) == "number" and expireOverride > 0 and expireOverride or 1.5
	local entry = {
		specWarn = specWarnObject,
		count = count,
		voiceName = voiceName,
		expireSeconds = expireSeconds,
		queueTime = GetTime()
	}
	table.insert(queue.ordered, entry)
end

---@param formattedTargetName string
---@return boolean
function DBM:ConsumeBlizzTargetSpecialWarning(formattedTargetName)
	local now = GetTime()
	local consumed = false
	for mod, queue in pairs(blizzTargetSpecialWarningQueue) do
		while #queue.ordered > 0 and now - (queue.ordered[1].queueTime or 0) > (queue.ordered[1].expireSeconds or 1.5) do
			removeBlizzTargetSpecialWarningQueueEntry(queue, queue.ordered[1])
		end
		local entry
		if #queue.ordered > 0 then
			entry = queue.ordered[1]
			removeBlizzTargetSpecialWarningQueueEntry(queue, entry)
		end
		if #queue.ordered == 0 then
			blizzTargetSpecialWarningQueue[mod] = nil
		end
		if entry and entry.specWarn then
			private.blizzTargetConsuming = true
			local ok = xpcall(entry.specWarn.Show, geterrorhandler(), entry.specWarn, entry.count, formattedTargetName)
			private.blizzTargetConsuming = false
			if ok and entry.voiceName then
				entry.specWarn:Play(entry.voiceName)
			end
			consumed = consumed or ok
		end
	end
	return consumed
end

local playerName = private.playerName
private:RegisterPlayerNameCallback(function(_, name) playerName = name end)
local textureCode = " |T%s:12:12|t "

---@param queue table
---@param entry table
local function removeBlizzYouSpecialWarningQueueEntry(queue, entry)
	for i = #queue.ordered, 1, -1 do
		if queue.ordered[i] == entry then
			table.remove(queue.ordered, i)
			break
		end
	end
end

---@param specWarnObject SpecialWarning
---@param count number?
---@param voiceName string?
---@param expireOverride number?
---@param matchSeverity number? Only consume encounter warnings with this public severity; nil matches any severity.
function DBM:QueueBlizzYouSpecialWarning(specWarnObject, count, voiceName, expireOverride, matchSeverity)
	if not specWarnObject or specWarnObject.announceType ~= "blizzyou" then return end
	local mod = specWarnObject.mod
	if not mod then return end
	local queue = blizzYouSpecialWarningQueue[mod]
	if not queue then
		queue = { ordered = {} }
		blizzYouSpecialWarningQueue[mod] = queue
	end
	local expireSeconds = type(expireOverride) == "number" and expireOverride > 0 and expireOverride or 1.5
	local entry = {
		specWarn = specWarnObject,
		count = count,
		voiceName = voiceName,
		matchSeverity = matchSeverity,
		expireSeconds = expireSeconds,
		queueTime = GetTime()
	}
	table.insert(queue.ordered, entry)
end

---@param severity number? Public ENCOUNTER_WARNING severity.
---@return boolean
function DBM:ConsumeBlizzYouSpecialWarning(severity)
	local now = GetTime()
	local consumed = false
	for mod, queue in pairs(blizzYouSpecialWarningQueue) do
		local i = 1
		local found = false
		while i <= #queue.ordered do
			local entry = queue.ordered[i]
			if now - entry.queueTime > (entry.expireSeconds or 1.5) then
				-- Stale, discard
				removeBlizzYouSpecialWarningQueueEntry(queue, entry)
			elseif not found and (entry.matchSeverity == nil or entry.matchSeverity == severity) then
				removeBlizzYouSpecialWarningQueueEntry(queue, entry)
				if entry.specWarn then
					private.blizzYouConsuming = true
					local ok = xpcall(entry.specWarn.Show, geterrorhandler(), entry.specWarn, entry.count)
					private.blizzYouConsuming = false
					if ok and entry.voiceName then
						entry.specWarn:Play(entry.voiceName)
					end
					consumed = consumed or ok
				end
				found = true
			else
				i = i + 1
			end
		end
		if #queue.ordered == 0 then
			blizzYouSpecialWarningQueue[mod] = nil
		end
	end
	return consumed
end

---@diagnostic disable: inject-field
local frame = CreateFrame("Frame", "DBMSpecialWarning", UIParent)
local font1 = frame:CreateFontString("DBMSpecialWarning1", "OVERLAY", "ZoneTextFont")
font1:SetWidth(1024)
font1:SetHeight(0)
font1:SetPoint("TOP", 0, 0)
local font2 = frame:CreateFontString("DBMSpecialWarning2", "OVERLAY", "ZoneTextFont")
font2:SetWidth(1024)
font2:SetHeight(0)
font2:SetPoint("TOP", font1, "BOTTOM", 0, 0)
frame:SetMovable(true)
frame:SetWidth(1)
frame:SetHeight(1)
frame:SetFrameStrata("HIGH")
frame:SetClampedToScreen(true)
frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)

local font1elapsed, font2elapsed, moving
local font2Secret = false

local function fontHide1()
	local duration = DBM.Options.SpecialWarningDuration2
	if font1elapsed > duration * 1.3 then
		font1:Hide()
		if frame.font1ticker then
			frame.font1ticker:Cancel()
			frame.font1ticker = nil
		end
	elseif font1elapsed > duration then
		font1elapsed = font1elapsed + 0.05
		local alpha = 1 - (font1elapsed - duration) / (duration * 0.3)
		font1:SetAlpha(alpha > 0 and alpha or 0)
	else
		font1elapsed = font1elapsed + 0.05
		font1:SetAlpha(1)
	end
end

local function fontHide2()
	local duration = DBM.Options.SpecialWarningDuration2
	if font2elapsed > duration * 1.3 then
		font2:Hide()
		if frame.font2ticker then
			frame.font2ticker:Cancel()
			frame.font2ticker = nil
		end
	elseif font2elapsed > duration then
		font2elapsed = font2elapsed + 0.05
		local alpha = 1 - (font2elapsed - duration) / (duration * 0.3)
		font2:SetAlpha(alpha > 0 and alpha or 0)
	else
		font2elapsed = font2elapsed + 0.05
		font2:SetAlpha(1)
	end
end

local specialWarningFontResetNotified = false
local function getSafeSpecialWarningFontSettings(self)
	local font = self.Options.SpecialWarningFont == "standardFont" and private.standardFont or self.Options.SpecialWarningFont
	local size = self.Options.SpecialWarningFontSize2
	local style = (self.Options.SpecialWarningFontStyle and not DBM:IsNoneValue(self.Options.SpecialWarningFontStyle)) and self.Options.SpecialWarningFontStyle or ""
	if not DBM:IsFontValid(font, private.standardFont, size, style) then
		self.Options.SpecialWarningFont = self.DefaultOptions.SpecialWarningFont
		self.Options.SpecialWarningFontSize2 = self.DefaultOptions.SpecialWarningFontSize2
		self.Options.SpecialWarningFontStyle = self.DefaultOptions.SpecialWarningFontStyle
		if not specialWarningFontResetNotified then
			self:AddMsg("Invalid Special Warning font settings were detected and reset to defaults.")
			specialWarningFontResetNotified = true
		end
		font = self.Options.SpecialWarningFont == "standardFont" and private.standardFont or self.Options.SpecialWarningFont
		size = self.Options.SpecialWarningFontSize2
		style = (self.Options.SpecialWarningFontStyle and not DBM:IsNoneValue(self.Options.SpecialWarningFontStyle)) and self.Options.SpecialWarningFontStyle or ""
	end
	return font, size, style
end

function DBM:UpdateSpecialWarningOptions()
	frame:ClearAllPoints()
	frame:SetPoint(self.Options.SpecialWarningPoint, UIParent, self.Options.SpecialWarningPoint, self.Options.SpecialWarningX, self.Options.SpecialWarningY)
	local font, size, style = getSafeSpecialWarningFontSettings(self)
	font1:SetFont(font, size, style)
	font2:SetFont(font, size, style)
	font1:SetTextColor(unpack(self.Options.SpecialWarningFontCol))
	font2:SetTextColor(unpack(self.Options.SpecialWarningFontCol))
	if self.Options.SpecialWarningFontShadow then
		font1:SetShadowOffset(1, -1)
		font2:SetShadowOffset(1, -1)
	else
		font1:SetShadowOffset(0, 0)
		font2:SetShadowOffset(0, 0)
	end
end

---@param text any
---@param force boolean?
---@param specWarnObject any
---@param number number? Value for sound, colors, and vibration settings lookup
---@param customIcon string|number? Custom Icon, Only used for secret textures so also used as a nil check
---@param noSound boolean?
function DBM:AddSpecialWarning(text, force, specWarnObject, number, customIcon, noSound)
	--Now, check if all special warning filters are enabled to save cpu and abort immediately if true and it comes from RAID_WARNING API
	if customIcon and self.Options.HideDBMWarnings or (self.Options.DontPlaySpecialWarningSound and self.Options.DontShowSpecialWarningFlash and self.Options.DontShowSpecialWarningText) then return end
	local added = false
	local formatedText
	if C_StringUtil and customIcon and self.Options.SpecialWarningIcon then
		formatedText = C_StringUtil.WrapString(text, customIcon and textureCode:format(customIcon) or "", self.Options.SpecialWarningIcon and customIcon and textureCode:format(customIcon) or "")
	else
		formatedText = text
	end
	local replaceLast = force or (frame.font1ticker and frame.font2ticker and (font2Secret or customIcon))
	if not self.Options.DontShowSpecialWarningText then
		if not frame.font1ticker then
			font1elapsed = 0
			font1.lastUpdate = GetTime()
			font1:SetText(formatedText)
			font1:Show()
			added = true
			frame.font1ticker = frame.font1ticker or C_Timer.NewTicker(0.05, fontHide1)
		elseif not frame.font2ticker or replaceLast then
			font2elapsed = 0
			font2.lastUpdate = GetTime()
			font2:SetText(formatedText)
			font2Secret = self:issecretvalue(formatedText)
			font2:Show()
			added = true
			frame.font2ticker = frame.font2ticker or C_Timer.NewTicker(0.05, fontHide2)
		end
		if not added then
			if not customIcon then
				--Secret slots are replaced above instead of being read back for rotation.
				local prevText1 = font2:GetText()
				font1:SetText(prevText1)
				font1elapsed = font2elapsed
				self:AddSpecialWarning(text, true, specWarnObject, number, customIcon, noSound)
			end
		end
	end
	--DUPLICATE CODE
	--This code is for special warnings that bypass normal "show" method of hard coded objects (such as midnight secrets)
	if customIcon or force then
		if number and not noSound and not self.Options.DontPlaySpecialWarningSound then
			self:PlaySpecialWarningSound(number, force, true)
		end
		if number then
			if self.Options["SpecialWarningFlash" .. number] and not self.Options.DontShowSpecialWarningFlash then
				if not force and self:IsTrivial() and self.Options.DontPlayTrivialSpecialWarningSound then return end--No flash if trivial
				local flashColor = self.Options["SpecialWarningFlashCol" .. number]
				local repeatCount = self.Options["SpecialWarningFlashCount" .. number] or 1
				self.Flash:Show(flashColor[1], flashColor[2], flashColor[3], self.Options["SpecialWarningFlashDura" .. number], self.Options["SpecialWarningFlashAlph" .. number], repeatCount - 1)
			end
			if not self.Options.DontDoSpecialWarningVibrate and self.Options["SpecialWarningVibrate" .. number] then
				self:VibrateController()
			end
		end
		if self.Options.ShowSWarningsInChat then
			local colorCode = ("|cff%.2x%.2x%.2x"):format(DBM.Options.SpecialWarningFontCol[1] * 255, DBM.Options.SpecialWarningFontCol[2] * 255, DBM.Options.SpecialWarningFontCol[3] * 255)
			local combinedText
			if C_StringUtil then
				combinedText = C_StringUtil.WrapString(formatedText, colorCode .. "[" .. L.MOVE_SPECIAL_WARNING_TEXT .. "] ", "|r")
			else
				combinedText = ("%s[%s] %s|r"):format(colorCode, L.MOVE_SPECIAL_WARNING_TEXT, formatedText)
			end
			self:AddMsg(combinedText)
		end
		--DUPLICATE CODE
	end
end

local anchorFrame
local function moveEnd(self)
	moving = false
	anchorFrame:Hide()
	font1elapsed = self.Options.SpecialWarningDuration2
	font2elapsed = self.Options.SpecialWarningDuration2
	frame:SetFrameStrata("HIGH")
	self:Unschedule(moveEnd)
	DBT:CancelBar(L.MOVE_SPECIAL_WARNING_BAR)
end

function DBM:MoveSpecialWarning()
	if not anchorFrame then
		anchorFrame = CreateFrame("Frame", nil, frame)
		anchorFrame:SetWidth(32)
		anchorFrame:SetHeight(32)
		anchorFrame:EnableMouse(true)
		anchorFrame:SetPoint("TOP", frame, "TOP", 0, 32)
		anchorFrame:RegisterForDrag("LeftButton")
		anchorFrame:SetClampedToScreen(true)
		anchorFrame:Hide()
		local texture = anchorFrame:CreateTexture()
		texture:SetTexture("Interface\\Addons\\DBM-Core\\textures\\dot.blp")
		texture:SetPoint("CENTER", anchorFrame, "CENTER", 0, 0)
		texture:SetWidth(32)
		texture:SetHeight(32)
		anchorFrame:SetScript("OnDragStart", function()
			frame:StartMoving()
			self:Unschedule(moveEnd)
			DBT:CancelBar(L.MOVE_SPECIAL_WARNING_BAR)
		end)
		anchorFrame:SetScript("OnDragStop", function()
			frame:StopMovingOrSizing()
			local point, _, _, xOfs, yOfs = frame:GetPoint(1)
			self.Options.SpecialWarningPoint = point
			self.Options.SpecialWarningX = xOfs
			self.Options.SpecialWarningY = yOfs
			self:Schedule(15, moveEnd, self)
			DBT:CreateBar(15, L.MOVE_SPECIAL_WARNING_BAR, private.isRetail and 237538 or 136106)
		end)
	end
	if anchorFrame:IsShown() then
		moveEnd(self)
	else
		moving = true
		anchorFrame:Show()
		self:AddSpecialWarning(L.MOVE_SPECIAL_WARNING_TEXT)
		self:AddSpecialWarning(L.MOVE_SPECIAL_WARNING_TEXT)
		self:Schedule(15, moveEnd, self)
		DBT:CreateBar(15, L.MOVE_SPECIAL_WARNING_BAR, private.isRetail and 237538 or 136106)
		frame:Show()
		frame:SetFrameStrata("TOOLTIP")
		frame:SetAlpha(1)
	end
end

---@class SpecialWarning
local specialWarningPrototype = private:GetPrototype("SpecialWarning")
local mt = {__index = specialWarningPrototype}

local function classColoringFunction(cap)
	cap = cap:sub(2, -2)
	local noStrip = cap:match("noStrip ")
	if not noStrip then
		local name = cap
		local playerClass, playerIcon = DBM:GetRaidClass(name)
		if playerClass ~= "UNKNOWN" then
			cap = DBM:GetShortServerName(cap)--Only run strip code on valid player classes
			local playerColor = RAID_CLASS_COLORS[playerClass]
			if playerColor then
				if playerIcon > 0 and playerIcon <= 8 then
					cap = ("|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_%d:0|t"):format(playerIcon) .. ("|r|cff%.2x%.2x%.2x%s|r|cff%.2x%.2x%.2x"):format(playerColor.r * 255, playerColor.g * 255, playerColor.b * 255, cap, DBM.Options.SpecialWarningFontCol[1] * 255, DBM.Options.SpecialWarningFontCol[2] * 255, DBM.Options.SpecialWarningFontCol[3] * 255)
				else
					cap = ("|r|cff%.2x%.2x%.2x%s|r|cff%.2x%.2x%.2x"):format(playerColor.r * 255, playerColor.g * 255, playerColor.b * 255, cap, DBM.Options.SpecialWarningFontCol[1] * 255, DBM.Options.SpecialWarningFontCol[2] * 255, DBM.Options.SpecialWarningFontCol[3] * 255)
				end
			end
		end
	else
		cap = cap:sub(9)
	end
	return cap
end

local function setText(announceType, spellId, stacks, customName)
	local text, spellName
	local defaultRenameName
	local fallbackSpellName
	local originalSpellName
	local effectiveSpellId = announceType == "gtfo" and 123456 or spellId
	if customName then
		defaultRenameName = customName
	elseif announceType == "gtfo" then
		defaultRenameName = "GTFO"
	else
		defaultRenameName = DBM:ParseSpellName(spellId, announceType) or CL.UNKNOWN
	end
	originalSpellName = DBM:ParseSpellName(spellId, announceType) or defaultRenameName
	if announceType == "gtfo" then
		fallbackSpellName = defaultRenameName
	else
		fallbackSpellName = customName or originalSpellName
	end
	if effectiveSpellId and DBM.Options.SpecialWarningShortText then
		spellName = DBM:GetRename(effectiveSpellId, fallbackSpellName, originalSpellName)
	else
		spellName = fallbackSpellName
	end
	if announceType == "prewarn" then
		if type(stacks) == "string" then
			text = L.AUTO_SPEC_WARN_TEXTS[announceType]:format(spellName, stacks)
		else
			text = L.AUTO_SPEC_WARN_TEXTS[announceType]:format(spellName, L.SEC_FMT:format(tostring(stacks or 5)))
		end
	elseif announceType == "blizztarget" then
		text = L.AUTO_ANNOUNCE_TEXTS.blizztarget:format(spellName)
	else
		text = L.AUTO_SPEC_WARN_TEXTS[announceType]:format(spellName)
	end
	return text, spellName
end

function specialWarningPrototype:SetText(customName)
	local text, spellName = setText(self.announceType, self.spellId, self.stacks, customName)
	self.text = text
	self.spellName = spellName
	self.customName = customName
	self.renameRevision = DBM:GetSpellRenameRevision()
end

---Update icon on object and nothing else.
---<br>Does not change spellId/spellkey associated with weakauras/callbacks
---@param altSpellId string|number
function specialWarningPrototype:UpdateIcon(altSpellId)
	self.icon = DBM:ParseSpellIcon(altSpellId, self.announceType, self.icon)
end

---Not to be confused with SetText, which only sets the text of object.
---<br>This changes actual ID so announce callback also swaps ID for WAs
---@param altSpellId string|number
function specialWarningPrototype:UpdateKey(altSpellId)
	self.spellId = altSpellId
	self.icon = DBM:ParseSpellIcon(altSpellId, self.announceType, self.icon)
	if self.announceType then
		--Regenerate auto localized text if it's an auto localized alert
		local text, spellName = setText(self.announceType, self.spellId, self.stacks)
		self.text = text
		self.spellName = spellName
		self.customName = nil
		self.renameRevision = DBM:GetSpellRenameRevision()
	else--Just regenerating spellName not message text because it's likely a custom text object such as NewSpecialWarning
		self.originalSpellName = DBM:ParseSpellName(altSpellId)
		self.spellName = DBM.Options.SpecialWarningShortText and DBM:GetRename(altSpellId, self.originalSpellName) or self.originalSpellName
	end
end

---@param self SpecialWarning
---@param soundId number?
---@param isNote boolean?
---@return boolean
local function canVoiceReplace(self, soundId, isNote)
	if isNote then--Sound ID 5 is Notes feature, this is always allowed to play
		return false
	end
	if private.voiceSessionDisabled or DBM:IsNoneValue(DBM.Options.ChosenVoicePack2) then
		return false
	end
	soundId = soundId or self.option and self.mod.Options[self.option .. "SWSound"] or self.flash
	local isVoicePackUsed
	if type(soundId) == "number" and soundId < 5 then--Value 1-4 are SW1 defaults, otherwise it's file data ID and handled by Custom
		isVoicePackUsed = DBM.Options.VPReplacesSADefault
	end
	return isVoicePackUsed
end

---@class SpecAnnounce0: SpecialWarning
---@field Show fun(self: SpecAnnounce0)
---@class SpecAnnounce1num: SpecialWarning
---@field Show fun(self: SpecAnnounce1num, arg1: number)
---@class SpecAnnounce1str: SpecialWarning
---@field Show fun(self: SpecAnnounce1str, arg1: string)
---@class SpecAnnounce1Annoying: SpecialWarning
---@field Show fun(self: SpecAnnounce1Annoying, arg1: string|unknown|nil)
---@class SpecAnnounce2strnum: SpecialWarning
---@field Show fun(self: SpecAnnounce2strnum, arg1: string, arg2: number)
---@class SpecAnnounce2numstr: SpecialWarning
---@field Show fun(self: SpecAnnounce2numstr, arg1: number, arg2: string)
---@class SpecAnnounce3numstrnum: SpecialWarning
---@field Show fun(self: SpecAnnounce3numstrnum, arg1: number, arg2: string, arg3: number|nil)
---@class SpecAnnounceBlizzYou: SpecialWarning
---@field Show fun(self: SpecAnnounceBlizzYou, count: number?, voiceName: string?, expireOverride: number?, matchSeverity: number?)

---Used to set fallback options to blizzard encounter API for hardcoded warnings to fall back on
---@param encounterEventId number|table EncounterEventID from EncounterEvent.db2 that matches event we're targetting
---@param voice VPSound voice pack media path
---@param voiceVersion number Required voice pack verion (if not met, falls back to default special warning sounds)
---@param color warningColorType? ColorId 1-4
---@param overrideType number? Optional override type for the alert
function specialWarningPrototype:SetAlert(encounterEventId, voice, voiceVersion, color, overrideType)
	if self.option and self.mod.Options[self.option] then
		self.mod:EnableAlertOptions(self.spellId, encounterEventId, voice, voiceVersion, color, overrideType, self.option)
	end
end

---@param self SpecialWarning
---@param secret boolean
---@param ... any
local function showSpecialWarning(self, secret, ...)
	if self.announceType == "blizztarget" then
		if not private.blizzTargetConsuming then
			local count, voiceName, expireOverride = ...
			DBM:QueueBlizzTargetSpecialWarning(self, count, voiceName, expireOverride)
			return
		end
	elseif self.announceType == "blizzyou" then
		if not private.blizzYouConsuming then
			local count, voiceName, expireOverride, matchSeverity = ...
			DBM:QueueBlizzYouSpecialWarning(self, count, voiceName, expireOverride, matchSeverity)
			return
		end
	end
	--Check if option for this warning is even enabled
	if (not self.option or self.mod.Options[self.option]) and not moving and frame then
		local renameSpellKey = DBM:NormalizeSpellRenameKey(self.spellId)
		if renameSpellKey and self.renameRevision ~= DBM:GetSpellRenameRevision() then
			if self.announceType then
				local text, spellName = setText(self.announceType, self.spellId, self.stacks, self.customName)
				self.text = text
				self.spellName = spellName
			else
				local originalSpellName = self.originalSpellName or DBM:ParseSpellName(self.spellId) or CL.UNKNOWN
				self.spellName = DBM.Options.SpecialWarningShortText and DBM:GetRename(self.spellId, originalSpellName) or originalSpellName
			end
			self.renameRevision = DBM:GetSpellRenameRevision()
		end
		local isSecretBlizzType = secret or self.announceType == "blizztarget" or self.announceType == "blizzyou" or DBM:hasanysecretvalues(...)
		--Now, check if all special warning filters are enabled to save cpu and abort immediately if true.
		if DBM.Options.HideDBMWarnings or (DBM.Options.DontPlaySpecialWarningSound and DBM.Options.DontShowSpecialWarningFlash and DBM.Options.DontShowSpecialWarningText) then return end
		--Next, we check if trash mod warning and if so check the filter trash warning filter for trivial difficulties
		if self.mod.isTrashMod and DBM.Options.FilterTrashWarnings2 and (self.mod:IsEasyDungeon() or DBM:IsTrivial()) then return end
		--Lastly, we check if it's a tank warning and filter if not in tank spec. This is done because tank warnings on by default and handled fluidly by spec, not option setting
		if self.announceType == "taunt" and not self.mod:IsTank() then return end--Don't tell non tanks to taunt, ever.
		local argTable
		if not isSecretBlizzType then
			-- Secret passthrough warnings avoid materializing arg tables from potentially secret args.
			argTable = {...}
		end
		-- add a default parameter for move away warnings
		if self.announceType == "gtfo" then
			if DBM:UnitBuff("player", 27827) then return end--Don't tell a priest in spirit of redemption form to GTFO, they can't, and they don't take damage from it anyhow
			if argTable and (#argTable == 0 or type(argTable[1]) ~= "string") then
				argTable[1] = self.spellName or L.BAD
			end
		end
		if argTable and #self.combinedtext > 0 then
			--Throttle spam.
			if DBM.Options.SWarningAlphabetical then
				table.sort(self.combinedtext)
			end
			local combinedText = table.concat(self.combinedtext, "<, >")
			if self.combinedcount == 1 then
				combinedText = combinedText .. " " .. L.GENERIC_WARNING_OTHERS
			elseif self.combinedcount > 1 then
				combinedText = combinedText .. " " .. L.GENERIC_WARNING_OTHERS2:format(self.combinedcount)
			end
			--Process
			for i = 1, #argTable do
				if type(argTable[i]) == "string" then
					argTable[i] = combinedText
				end
			end
		end
		--Grab count for both the callback and the notes feature
		local announceCount
		local secretCount = false
		if self.announceType and (self.announceType:find("count") or self.announceType == "blizztarget" or self.announceType == "blizzyou") then
			if self.announceType == "interruptcount" then
				announceCount = select(2, ...)--Count is the second argument, even with a secret target
			else
				announceCount = select(1, ...)
			end
			secretCount = DBM:issecretvalue(announceCount)
			if secretCount then
				announceCount = nil--Secret counts are display-only, not note indices or callback metadata
			elseif type(announceCount) == "string" then
				--Probably a hypehnated double count like inferno slice or marked for death
				--This is pretty atypical in newer content cause it's a bit hacky
				local mainCount = string.split("-", announceCount)
				announceCount = tonumber(mainCount)
			end
		end
		local message
		if argTable then
			message = stringUtils.pformat(self.text, unpack(argTable))
		elseif self.announceType == "gtfo" and not DBM:issecretvalue(select(1, ...)) and type(select(1, ...)) ~= "string" then
			message = stringUtils.secretFormat(self.text, self.spellName or L.BAD, select(2, ...))
		else
			message = stringUtils.secretFormat(self.text, ...)
		end
		local text = ("%s%s%s"):format(
			(DBM.Options.SpecialWarningIcon and self.icon and textureCode:format(self.icon)) or "",
			message,
			(DBM.Options.SpecialWarningIcon and self.icon and textureCode:format(self.icon)) or ""
		)
		local noteHasName = nil
		if self.option and not secretCount then
			local noteText = self.mod.Options[self.option .. "SWNote"]
			if noteText and type(noteText) == "string" and noteText ~= "" then--Filter false bool and empty strings
				if announceCount then--Counts support different note for EACH count
					local notesTable = {string.split("/", noteText)}
					noteText = notesTable[announceCount]
					if noteText and type(noteText) == "string" and noteText ~= "" then--Refilter after string split to make sure a note for this count exists
						local hasPlayerName = noteText:find(playerName)
						if DBM.Options.SWarnNameInNote and hasPlayerName then
							noteHasName = 5
						end
						if not isSecretBlizzType and self.announceType and not self.announceType:find("switch") then
							noteText = noteText:gsub(">.-<", classColoringFunction)--Class color note text before combining with warning text.
						end
						--Terminate special warning, it's an interrupt count warning without player name and filter enabled
						if (self.announceType == "interruptcount") and DBM.Options.FilterInterruptNoteName and not hasPlayerName then return end
						noteText = " (" .. noteText .. ")"
						text = ("%s%s"):format(text, noteText)
					end
				else--Non count warnings will have one note, period
					if DBM.Options.SWarnNameInNote and noteText:find(playerName) then
						noteHasName = 5
					end
					if not isSecretBlizzType and self.announceType and not self.announceType:find("switch") then
						noteText = noteText:gsub(">.-<", classColoringFunction)--Class color note text before combining with warning text.
					end
					noteText = " (" .. noteText .. ")"
					text = ("%s%s"):format(text, noteText)
				end
			end
		end
		--Text is disabled, suresss text from screen and chat frame
		if not DBM.Options.DontShowSpecialWarningText then
			--No stripping on switch warnings, ever. They will NEVER have player name, but often have adds with "-" in name
			if not isSecretBlizzType and self.announceType and not self.announceType:find("switch") then
				text = text:gsub(">.-<", classColoringFunction)
			end
			DBM:AddSpecialWarning(text, nil, self)
			if DBM.Options.ShowSWarningsInChat then
				local colorCode = ("|cff%.2x%.2x%.2x"):format(DBM.Options.SpecialWarningFontCol[1] * 255, DBM.Options.SpecialWarningFontCol[2] * 255, DBM.Options.SpecialWarningFontCol[3] * 255)
				self.mod:AddMsg(("%s[%s] %s|r"):format(colorCode, L.MOVE_SPECIAL_WARNING_TEXT, text), nil)
			end
		end
		self.combinedcount = 0
		self.combinedtext = {}
		if not UnitIsDeadOrGhost("player") then
			if noteHasName then
				if not DBM.Options.DontShowSpecialWarningFlash and DBM.Options.SpecialWarningFlash5 then--Not included in above if statement on purpose. we don't want to trigger else rule if noteHasName is true but SpecialWarningFlash5 is false
					local repeatCount = DBM.Options.SpecialWarningFlashCount5 or 1
					DBM.Flash:Show(DBM.Options.SpecialWarningFlashCol5[1], DBM.Options.SpecialWarningFlashCol5[2], DBM.Options.SpecialWarningFlashCol5[3], DBM.Options.SpecialWarningFlashDura5, DBM.Options.SpecialWarningFlashAlph5, repeatCount - 1)
				end
				if not DBM.Options.DontDoSpecialWarningVibrate and DBM.Options.SpecialWarningVibrate5 then
					DBM:VibrateController()
				end
			else
				local number = self.flash
				if not DBM.Options.DontShowSpecialWarningFlash and DBM.Options["SpecialWarningFlash" .. number] then
					local repeatCount = DBM.Options["SpecialWarningFlashCount" .. number] or 1
					local flashcolor = DBM.Options["SpecialWarningFlashCol" .. number]
					DBM.Flash:Show(flashcolor[1], flashcolor[2], flashcolor[3], DBM.Options["SpecialWarningFlashDura" .. number], DBM.Options["SpecialWarningFlashAlph" .. number], repeatCount - 1)
				end
				if not DBM.Options.DontDoSpecialWarningVibrate and DBM.Options["SpecialWarningVibrate" .. number] then
					DBM:VibrateController()
				end
			end
		end
		--Text: Full message text
		--Icon: Texture path/id for icon
		--Type: Announce type
		----Types: spell, ends, endtarget, fades, soon, bait, dispel, interrupt, interruptcount, you, youcount, youpos, soakpos, target, targetcount, defensive, taunt, close, move, keepmove, stopmove,
		----gtfo, dodge, dodgecount, dodgeloc, moveaway, moveawaycount, moveto, soak, jump, run, cast, lookaway, reflect, count, sooncount, stack, switch, switchcount, adds, addscount, addscustom, targetchange, prewarn
		------General Target Messages (but since it's a special warning, it applies to you in some way): target, targetcount
		------Fight Changes (Stages, adds, boss buff/debuff, etc): adds, addscount, addscustom, targetchange, switch, switchcount, ends, endtarget
		------General (can really apply to anything): spell, count, soon, sooncount, prewarn
		------Personal/Role (Applies to you, or your job): Everything Else
		--SpellId: Raw spell or encounter journal Id if available.
		--Mod ID: Encounter ID as string, or a generic string for mods that don't have encounter ID (such as trash, dummy/test mods)
		--boolean: Whether or not this warning is a special warning (higher priority). BW would call this "emphasized"
		--announceCount: If it's a count announce, this will provide access to the number value of that count. This, along with spellId should be used instead of message text scanning for most weak auras that need to target specific count casts
		DBM:FireEvent("DBM_Announce", text, self.icon, self.type, self.spellId, self.mod.id, true, announceCount)
		if DBM.Options.IgnoreBlizzAPI and self.spellId and self.spellName then
			if announceCount then
				DBM:Debug("|cff00ff00Showing hardcoded warning for |r spellID |cff69ccf0" .. self.spellId .. "|r spellName |cff69ccf0" .. self.spellName .. " (" .. announceCount .. ")|r", 3, nil, nil, true, true)
			else
				DBM:Debug("|cff00ff00Showing hardcoded warning for |r spellID |cff69ccf0" .. self.spellId .. "|r spellName |cff69ccf0" .. self.spellName .. "|r", 3, nil, nil, true, true)
			end
		end
		if self.sound and not DBM.Options.DontPlaySpecialWarningSound and (not self.option or not DBM:IsNoneValue(self.mod.Options[self.option .. "SWSound"])) then
			local soundId = self.option and self.mod.Options[self.option .. "SWSound"] or self.flash
			if noteHasName and type(soundId) == "number" then soundId = noteHasName end--Change number to 5 if it's not a custom sound, else, do nothing with it
			if self.hasVoice and canVoiceReplace(self, soundId, noteHasName and true) and self.hasVoice <= private.swFilterDisabled then return end
			DBM:PlaySpecialWarningSound(soundId or 1)
		end
	else
		self.combinedcount = 0
		self.combinedtext = {}
	end
end

function specialWarningPrototype:Show(...)
	showSpecialWarning(self, false, ...)
end

---Shows a secret player name without materializing it into a Lua table.
---@param self SpecialWarning
---@param className string|nil
---@param ... any
local function secretShowByClass(self, className, ...)
	local playerName = select(1, ...)
	if not DBM:issecretvalue(playerName) and playerName == nil then
		playerName = CL.UNKNOWN
	end
	if className then
		local classColor = C_ClassColor.GetClassColor(className)
		if classColor then
			playerName = classColor:WrapTextInColorCode(playerName)
		end
	end
	showSpecialWarning(self, true, playerName, select(2, ...))
end

---Shows a secret player name from an ENCOUNTER_WARNING target GUID without materializing it into a Lua table.
---Uses the localized warning text without name delimiters, then optionally class-colors the secret player name from its GUID.
---The GUID may be literal false to explicitly skip the class lookup and color wrapping.
---@param playerGUID WOWGUID|false|nil
---@param ... any
function specialWarningPrototype:SecretShowByGUID(playerGUID, ...)
	local className
	if playerGUID then
		local _
		_, className = GetPlayerInfoByGUID(playerGUID)
	end
	secretShowByClass(self, className, ...)
end

---Shows a unit's secret spell target without materializing it into a Lua table.
---@param unit enemyUIDs|targetUIDs
function specialWarningPrototype:SecretShowByUnit(unit)
	secretShowByClass(self, UnitSpellTargetClass(unit), UnitSpellTargetName(unit))
end

---Shows a unit's secret spell target after a delay.
---@param delay number
---@param unit enemyUIDs|targetUIDs
function specialWarningPrototype:ScheduleSecret(delay, unit)
	self.mod:Schedule(delay, function()
		self:SecretShowByUnit(unit)
	end)
end

---Object that's used when precision isn't possible (number of targets variable or unknown
---@param delay number
---@param ... any
function specialWarningPrototype:CombinedShow(delay, ...)
	if DBM:hasanysecretvalues(...) then
		DBMScheduler:Unschedule(self.Show, self.mod, self)
		self:Show(...)
		return
	end
	--Check if option for this warning is even enabled
	if self.option and not self.mod.Options[self.option] then return end
	--Now, check if all special warning filters are enabled to save cpu and abort immediately if true.
	if DBM.Options.HideDBMWarnings or (DBM.Options.DontPlaySpecialWarningSound and DBM.Options.DontShowSpecialWarningFlash and DBM.Options.DontShowSpecialWarningText) then return end
	--Next, we check if trash mod warning and if so check the filter trash warning filter for trivial difficulties
	if self.mod:IsEasyDungeon() and self.mod.isTrashMod and DBM.Options.FilterTrashWarnings2 then return end
	local argTable = {...}
	for i = 1, #argTable do
		if type(argTable[i]) == "string" then
			if #self.combinedtext < 6 then--Throttle spam. We may not need more than 5 targets..
				if not checkEntry(self.combinedtext, argTable[i]) then
					self.combinedtext[#self.combinedtext + 1] = argTable[i]
				end
			else
				self.combinedcount = self.combinedcount + 1
			end
		end
	end
	DBMScheduler:Unschedule(self.Show, self.mod, self)
	DBMScheduler:Schedule(delay or 0.5, self.Show, self.mod, self, ...)
end

---New object that allows defining count instead of scheduling for more efficient and immediate warnings when precise count is known
---@param maxTotal number
---@param ... any
function specialWarningPrototype:PreciseShow(maxTotal, ...)
	if DBM:hasanysecretvalues(...) then
		DBMScheduler:Unschedule(self.Show, self.mod, self)
		self:Show(...)
		return
	end
	--Check if option for this warning is even enabled
	if self.option and not self.mod.Options[self.option] then return end
	--Now, check if all special warning filters are enabled to save cpu and abort immediately if true.
	if DBM.Options.HideDBMWarnings or (DBM.Options.DontPlaySpecialWarningSound and DBM.Options.DontShowSpecialWarningFlash and DBM.Options.DontShowSpecialWarningText) then return end
	--Next, we check if trash mod warning and if so check the filter trash warning filter for trivial difficulties
	if self.mod:IsEasyDungeon() and self.mod.isTrashMod and DBM.Options.FilterTrashWarnings2 then return end
	local argTable = {...}
	for i = 1, #argTable do
		if type(argTable[i]) == "string" then
			if #self.combinedtext < 6 then--Throttle spam. We may not need more than 5 targets..
				if not checkEntry(self.combinedtext, argTable[i]) then
					self.combinedtext[#self.combinedtext + 1] = argTable[i]
				end
			else
				self.combinedcount = self.combinedcount + 1
			end
		end
	end
	DBMScheduler:Unschedule(self.Show, self.mod, self)
	local viableTotal = DBM:NumRealAlivePlayers()
	if (maxTotal == #self.combinedtext) or (viableTotal == #self.combinedtext) then--All targets gathered, show immediately
		self:Show(...)--Does this need self or mod? will it have this bug? https://github.com/DeadlyBossMods/DBM-Unified/issues/153
	else--And even still, use scheduling backup in case counts still fail
		DBMScheduler:Schedule(1.2, self.Show, self.mod, self, ...)
	end
end

---Used as a lazy antispam. Does NOT combine. Use CombinedShow for that
---@param delay number?
---@param ... any
function specialWarningPrototype:DelayedShow(delay, ...)
	DBMScheduler:Unschedule(self.Show, self.mod, self, ...)
	DBMScheduler:Schedule(delay or 0.5, self.Show, self.mod, self, ...)
end

---@param t number
---@param ... any
function specialWarningPrototype:Schedule(t, ...)
	local id = DBMScheduler:Schedule(t, self.Show, self.mod, self, ...)
	return id
end

---@param time number
---@param numAnnounces number?
---@param ... any
function specialWarningPrototype:Countdown(time, numAnnounces, ...)
	DBMScheduler:ScheduleCountdown(time, numAnnounces, self.Show, self.mod, self, ...)
end

---@param time number|table
---@param count number
function specialWarningPrototype:Loop(time, count)
	DBMScheduler:ScheduleLoop(time, self.Show, self.mod, self, count)
end

---@param t number|table
---@param count number
---@param name VPSound?
function specialWarningPrototype:LoopVoice(t, count, name)
	DBMScheduler:ScheduleLoop(t, self.Play, self.mod, self, count, nil, name)
end

function specialWarningPrototype:Cancel(_, ...) -- t, ...
	return DBMScheduler:Unschedule(self.Show, self.mod, self, ...)
end

---@param name VPSound?
---@param customPath? string|number
function specialWarningPrototype:Play(name, customPath)
	local voice = DBM.Options.ChosenVoicePack2
	local soundId = self.option and self.mod.Options[self.option .. "SWSound"] or self.flash
	if not canVoiceReplace(self, soundId) then return end
	if self.mod:IsEasyDungeon() and self.mod.isTrashMod and DBM.Options.FilterTrashWarnings2 then return end
	if ((not self.option or self.mod.Options[self.option])) and self.hasVoice <= private.swFilterDisabled then
		--Filter tank specific voice alerts for non tanks if tank filter enabled
		if (name == "changemt" or name == "tauntboss") and not self.mod:IsTank() then return end
		--Mute VP if SW sound is set to None in the boss mod.
		if DBM:IsNoneValue(soundId) then return end
		local path = customPath or ("Interface\\AddOns\\DBM-VP" .. voice .. "\\" .. name .. ".ogg")
		DBM:PlaySoundFile(path)
	end
end

---@param t number
---@param name VPSound?
---@param customPath? string|number
function specialWarningPrototype:ScheduleVoice(t, name, customPath)
	if not canVoiceReplace(self) then return end
	DBMScheduler:Unschedule(self.Play, self.mod, self)--Allow ScheduleVoice to be used in same way as CombinedShow
	local id = DBMScheduler:Schedule(t, self.Play, self.mod, self, name, customPath)
	return id
end

---Object Permits scheduling voice multiple times for same object
---@param t number
---@param name VPSound?
---@param customPath? string|number
function specialWarningPrototype:ScheduleVoiceOverLap(t, name, customPath)
	if not canVoiceReplace(self) then return end
	local id = DBMScheduler:Schedule(t, self.Play, self.mod, self, name, customPath)
	return id
end

function specialWarningPrototype:CancelVoice(...)
	if not canVoiceReplace(self) then return end
	return DBMScheduler:Unschedule(self.Play, self.mod, self, ...)
end

---old constructor (no auto-localize)
---@param text string
---@param optionDefault SpecFlags|boolean?
---@param optionName string|optionNumbers|boolean? String for custom option name. Using false hides option completely
---@param optionVersion any optional: has to be number, but luaLS has a fit if we tell it that
---@param runSound number? 1 = Personal, 2 = Everyone, 3 = Very Important, 4 = Run Away
---@param hasVoice number? Voice pack version required for used sound file.
---@param difficulty number? Raid Difficulty index used for displaying difficulty icon next to option
---@param icon number|string? Use number for spellId, -number for journalID, number as string for textureID
---@param spellID string|number? Used to define a spellID used for GroupSpells and WeakAura key
---@param waCustomName any? Used to show custom name/text for Spell header (usually used when a made up SpellID is used)
---@param voiceFile VPSound? Used to tell GUI what voice file to play when using test button
function bossModPrototype:NewSpecialWarning(text, optionDefault, optionName, optionVersion, runSound, hasVoice, difficulty, icon, spellID, waCustomName, voiceFile)
	if not text then
		error("NewSpecialWarning: you must provide special warning text", 2)
	end
	if type(text) == "string" and text:match("OptionVersion") then
		error("NewSpecialWarning: you must provide remove optionversion hack for " .. optionDefault)
	end
	runSound = runSound or 1
	icon = DBM:ParseSpellIcon(icon)
	local warningText = self.localization.warnings[text]
	local spellName
	local originalSpellName
	local renameRevision
	if spellID then
		local baseSpellName = waCustomName or DBM:ParseSpellName(spellID) or CL.UNKNOWN
		originalSpellName = baseSpellName
		spellName = DBM.Options.SpecialWarningShortText and DBM:GetRename(spellID, baseSpellName) or baseSpellName
		renameRevision = DBM:GetSpellRenameRevision()
	end
	---@class SpecialWarning
	local obj = setmetatable(
		{
			objClass = "SpecialWarning",
			text = warningText,
			combinedtext = {},
			combinedcount = 0,
			mod = self,
			sound = runSound > 0,
			flash = runSound,--Set flash color to hard coded runsound (even if user sets custom sounds)
			hasVoice = hasVoice,
			difficulty = difficulty,
			spellId = spellID,--For WeakAuras / other callbacks
			spellName = spellName,
			originalSpellName = originalSpellName,
			renameRevision = renameRevision,
			icon = icon,
			voiceFile = voiceFile,
		},
		mt
	)
	local optionId = optionName or optionName ~= false and text
	if optionId then
		obj.voiceOptionId = hasVoice and "Voice" .. optionId or nil
		obj.option = optionId .. (optionVersion or "")
		self:AddSpecialWarningOption(obj.option, optionDefault, runSound, "announce", spellID, nil, waCustomName)
	end
	tinsert(self.specwarns, obj)
	return obj
end

---@param self DBMMod
---@return SpecialWarning|SpecAnnounce0
local function newSpecialWarning(self, announceType, spellId, stacks, optionDefault, optionName, optionVersion, runSound, hasVoice, difficulty, iconOverride, voiceFile)
	if not spellId then
		error("newSpecialWarning: you must provide spellId", 2)
	end
	if type(optionName) == "number" then
		if optionName > 0 and optionName < 6 and optionVersion == nil then
			optionVersion = optionName
			optionName = nil
		else
			error("newSpecialWarning: numeric optionName is only supported as optionVersion shorthand for values 1-5.", 2)
		end
	end
	if type(optionVersion) == "string" then
		error("newSpecialWarning: string optionVersion legacy short-text path is removed. Use DBM:RegisterAltSpellName ahead of object creation.", 2)
	end
	if not runSound then
		runSound = 1
	end
	local objectSpellId = announceType == "gtfo" and 123456 or spellId
	local objectCustomName = announceType == "gtfo" and "GTFO" or nil
	local text, spellName = setText(announceType, objectSpellId, stacks, objectCustomName)
	local icon = iconOverride or DBM:ParseSpellIcon(spellId)
	---@class SpecialWarning
	local obj = setmetatable( -- todo: fix duplicate code
		{
			objClass = "SpecialWarning",
			text = text,
			combinedtext = {},
			combinedcount = 0,
			announceType = announceType,
			mod = self,
			sound = runSound > 0,
			flash = runSound,--Set flash color to hard coded runsound (even if user sets custom sounds)
			hasVoice = hasVoice,
			difficulty = difficulty,
			type = announceType,
			spellId = objectSpellId,
			spellName = spellName,
			customName = objectCustomName,
			renameRevision = DBM:GetSpellRenameRevision(),
			stacks = stacks,
			icon = icon,
			voiceFile = voiceFile,
		},
		mt
	)
	if optionName then
		obj.option = optionName
	elseif optionName ~= false then
		local difficultyIcon = ""
		if difficulty then
			--1 LFR, 2 Normal, 3 Heroic, 4 Mythic
			--Likely 1 and 2 will never be used, but being prototyped just in case
			local path = "AddOns\\DBM-Core\\textures"
			if difficulty == 3 then
				difficultyIcon = "|TInterface\\" .. path .. "\\uicombattimelinewarningicons.blp:18:18:0:0:512:256:367:399:1:33|t"
			elseif difficulty == 4 then
				difficultyIcon = "|TInterface\\" .. path .. "\\uicombattimelinewarningicons.blp:18:18:0:0:512:256:265:297:35:67|t"
			end
		end
		obj.option = "SpecWarn" .. spellId .. announceType .. (optionVersion or "")
		if announceType == "stack" then
			self.localization.options[obj.option] = difficultyIcon .. L.AUTO_SPEC_WARN_OPTIONS[announceType]:format(stacks or 3, spellId)
		elseif announceType == "prewarn" then
			self.localization.options[obj.option] = difficultyIcon .. L.AUTO_SPEC_WARN_OPTIONS[announceType]:format(tostring(stacks or 5), spellId)
		else
			self.localization.options[obj.option] = difficultyIcon .. L.AUTO_SPEC_WARN_OPTIONS[announceType]:format(spellId)
		end
	end
	if obj.option then
		self:AddSpecialWarningOption(obj.option, optionDefault, runSound, "announce", objectSpellId, announceType)
	end
	obj.voiceOptionId = hasVoice and "Voice" .. spellId or nil
	tinsert(self.specwarns, obj)
	return obj
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce0
function bossModPrototype:NewSpecialWarningSpell(spellId, optionDefault, ...)
	---@type SpecAnnounce0
	return newSpecialWarning(self, "spell", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce0
function bossModPrototype:NewSpecialWarningEnd(spellId, optionDefault, ...)
	---@type SpecAnnounce0
	return newSpecialWarning(self, "ends", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1str
function bossModPrototype:NewSpecialWarningEndTarget(spellId, optionDefault, ...)
	---@type SpecAnnounce1str
	return newSpecialWarning(self, "endtarget", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce0
function bossModPrototype:NewSpecialWarningFades(spellId, optionDefault, ...)
	---@type SpecAnnounce0
	return newSpecialWarning(self, "fades", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce0
function bossModPrototype:NewSpecialWarningSoon(spellId, optionDefault, ...)
	---@type SpecAnnounce0
	return newSpecialWarning(self, "soon", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce0
function bossModPrototype:NewSpecialWarningBait(spellId, optionDefault, ...)
	---@type SpecAnnounce0
	return newSpecialWarning(self, "bait", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1str
function bossModPrototype:NewSpecialWarningDispel(spellId, optionDefault, ...)
	---@type SpecAnnounce1str
	return newSpecialWarning(self, "dispel", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1str
function bossModPrototype:NewSpecialWarningInterrupt(spellId, optionDefault, ...)
	---@type SpecAnnounce1str
	return newSpecialWarning(self, "interrupt", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce2strnum
function bossModPrototype:NewSpecialWarningInterruptCount(spellId, optionDefault, ...)
	---@type SpecAnnounce2strnum
	return newSpecialWarning(self, "interruptcount", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce0
function bossModPrototype:NewSpecialWarningYou(spellId, optionDefault, ...)
	---@type SpecAnnounce0
	return newSpecialWarning(self, "you", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1num
function bossModPrototype:NewSpecialWarningYouCount(spellId, optionDefault, ...)
	---@type SpecAnnounce1num
	return newSpecialWarning(self, "youcount", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1str
function bossModPrototype:NewSpecialWarningYouPos(spellId, optionDefault, ...)
	---@type SpecAnnounce1str
	return newSpecialWarning(self, "youpos", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce2numstr
function bossModPrototype:NewSpecialWarningYouPosCount(spellId, optionDefault, ...)
	---@type SpecAnnounce2numstr
	return newSpecialWarning(self, "youposcount", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1str
function bossModPrototype:NewSpecialWarningSoakPos(spellId, optionDefault, ...)
	---@type SpecAnnounce1str
	return newSpecialWarning(self, "soakpos", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1str
function bossModPrototype:NewSpecialWarningTarget(spellId, optionDefault, ...)
	---@type SpecAnnounce1str
	return newSpecialWarning(self, "target", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1str
function bossModPrototype:NewSpecialWarningLink(spellId, optionDefault, ...)
	---@type SpecAnnounce1str
	return newSpecialWarning(self, "link", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce2numstr
function bossModPrototype:NewSpecialWarningTargetCount(spellId, optionDefault, ...)
	---@type SpecAnnounce2numstr
	return newSpecialWarning(self, "targetcount", spellId, nil, optionDefault, ...)
end

---Special object used for blizzard target announces using secret target pulled from ENCOUNTER_WARNING
---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce3numstrnum
function bossModPrototype:NewSpecialWarningBlizzTarget(spellId, optionDefault, ...)
	---@type SpecAnnounce3numstrnum
	return newSpecialWarning(self, "blizztarget", spellId, nil, optionDefault, ...)
end

---Special object for "on you" announces triggered by the next matching ENCOUNTER_WARNING within the expiry window (default 1.5 seconds).
---Show(count, voiceName, expireOverride, matchSeverity) optionally restricts interception to a public severity.
---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounceBlizzYou
function bossModPrototype:NewSpecialWarningBlizzYou(spellId, optionDefault, ...)
	---@type SpecAnnounceBlizzYou
	return newSpecialWarning(self, "blizzyou", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce0
function bossModPrototype:NewSpecialWarningDefensive(spellId, optionDefault, ...)
	---@type SpecAnnounce0
	return newSpecialWarning(self, "defensive", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1str
function bossModPrototype:NewSpecialWarningTaunt(spellId, optionDefault, ...)
	---@type SpecAnnounce1str
	return newSpecialWarning(self, "taunt", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1str
function bossModPrototype:NewSpecialWarningClose(spellId, optionDefault, ...)
	---@type SpecAnnounce1str
	return newSpecialWarning(self, "close", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce0
function bossModPrototype:NewSpecialWarningMove(spellId, optionDefault, ...)
	---@type SpecAnnounce0
	return newSpecialWarning(self, "move", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce0
function bossModPrototype:NewSpecialWarningKeepMove(spellId, optionDefault, ...)
	---@type SpecAnnounce0
	return newSpecialWarning(self, "keepmove", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce0
function bossModPrototype:NewSpecialWarningStopMove(spellId, optionDefault, ...)
	---@type SpecAnnounce0
	return newSpecialWarning(self, "stopmove", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecialWarning
function bossModPrototype:NewSpecialWarningGTFO(spellId, optionDefault, ...)
	return newSpecialWarning(self, "gtfo", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce0
function bossModPrototype:NewSpecialWarningDodge(spellId, optionDefault, ...)
	---@type SpecAnnounce0
	return newSpecialWarning(self, "dodge", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1num
function bossModPrototype:NewSpecialWarningDodgeCount(spellId, optionDefault, ...)
	---@type SpecAnnounce1num
	return newSpecialWarning(self, "dodgecount", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1str
function bossModPrototype:NewSpecialWarningDodgeLoc(spellId, optionDefault, ...)
	---@type SpecAnnounce1str
	return newSpecialWarning(self, "dodgeloc", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce0
function bossModPrototype:NewSpecialWarningMoveAway(spellId, optionDefault, ...)
	---@type SpecAnnounce0
	return newSpecialWarning(self, "moveaway", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1num
function bossModPrototype:NewSpecialWarningMoveAwayCount(spellId, optionDefault, ...)
	---@type SpecAnnounce1num
	return newSpecialWarning(self, "moveawaycount", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1str
function bossModPrototype:NewSpecialWarningMoveAwayTarget(spellId, optionDefault, ...)
	---@type SpecAnnounce1str
	return newSpecialWarning(self, "moveawaytarget", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1Annoying
function bossModPrototype:NewSpecialWarningMoveTo(spellId, optionDefault, ...)
	---@type SpecAnnounce1Annoying
	return newSpecialWarning(self, "moveto", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce0
function bossModPrototype:NewSpecialWarningSoak(spellId, optionDefault, ...)
	---@type SpecAnnounce0
	return newSpecialWarning(self, "soak", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1num
function bossModPrototype:NewSpecialWarningSoakCount(spellId, optionDefault, ...)
	---@type SpecAnnounce1num
	return newSpecialWarning(self, "soakcount", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce0
function bossModPrototype:NewSpecialWarningJump(spellId, optionDefault, ...)
	---@type SpecAnnounce0
	return newSpecialWarning(self, "jump", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce0
function bossModPrototype:NewSpecialWarningRun(spellId, optionDefault, optionName, optionVersion, runSound, ...)
	---@type SpecAnnounce0
	return newSpecialWarning(self, "run", spellId, nil, optionDefault, optionName, optionVersion, runSound or 4, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1num
function bossModPrototype:NewSpecialWarningRunCount(spellId, optionDefault, optionName, optionVersion, runSound, ...)
	---@type SpecAnnounce1num
	return newSpecialWarning(self, "runcount", spellId, nil, optionDefault, optionName, optionVersion, runSound or 4, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce0
function bossModPrototype:NewSpecialWarningCast(spellId, optionDefault, ...)
	---@type SpecAnnounce0
	return newSpecialWarning(self, "cast", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1str
function bossModPrototype:NewSpecialWarningLookAway(spellId, optionDefault, ...)
	---@type SpecAnnounce1str
	return newSpecialWarning(self, "lookaway", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1str
function bossModPrototype:NewSpecialWarningReflect(spellId, optionDefault, ...)
	---@type SpecAnnounce1str
	return newSpecialWarning(self, "reflect", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1num
function bossModPrototype:NewSpecialWarningCount(spellId, optionDefault, ...)
	---@type SpecAnnounce1num
	return newSpecialWarning(self, "count", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1num
function bossModPrototype:NewSpecialWarningSoonCount(spellId, optionDefault, ...)
	---@type SpecAnnounce1num
	return newSpecialWarning(self, "sooncount", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, stacks: number, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1num
function bossModPrototype:NewSpecialWarningStack(spellId, optionDefault, stacks, ...)
	---@type SpecAnnounce1num
	return newSpecialWarning(self, "stack", spellId, stacks, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce0
function bossModPrototype:NewSpecialWarningSwitch(spellId, optionDefault, ...)
	---@type SpecAnnounce0
	return newSpecialWarning(self, "switch", spellId, nil, optionDefault, ...)
end

---Switch object that has string for count
---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1num
function bossModPrototype:NewSpecialWarningSwitchCount(spellId, optionDefault, ...)
	---@type SpecAnnounce1num
	return newSpecialWarning(self, "switchcount", spellId, nil, optionDefault, ...)
end

---Switch object that has string for extra info (like target)
---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1str
function bossModPrototype:NewSpecialWarningSwitchCustom(spellId, optionDefault, ...)
	---@type SpecAnnounce1str
	return newSpecialWarning(self, "switchcustom", spellId, nil, optionDefault, ...)
end

---Generic alert for incoming adds without context
---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce0
function bossModPrototype:NewSpecialWarningAdds(spellId, optionDefault, ...)
	---@type SpecAnnounce0
	return newSpecialWarning(self, "adds", spellId, nil, optionDefault, ...)
end

---Generic alert for incoming adds without context, but with count
---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1num
function bossModPrototype:NewSpecialWarningAddsCount(spellId, optionDefault, ...)
	---@type SpecAnnounce1num
	return newSpecialWarning(self, "addscount", spellId, nil, optionDefault, ...)
end

---Generic alert for incoming adds, but with custom text
---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1str
function bossModPrototype:NewSpecialWarningAddsCustom(spellId, optionDefault, ...)
	---@type SpecAnnounce1str
	return newSpecialWarning(self, "addscustom", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce1str
function bossModPrototype:NewSpecialWarningTargetChange(spellId, optionDefault, ...)
	---@type SpecAnnounce1str
	return newSpecialWarning(self, "targetchange", spellId, nil, optionDefault, ...)
end

---@overload fun(self: DBMMod, spellId: number|string, optionDefault: SpecFlags|boolean?, time: number, optionName: string|optionNumbers|boolean?, optionVersion: number?, runSound: acceptedSASounds?, hasVoice: number?, difficulty: number?, iconOverride: number|string?, voiceFile: VPSound?): SpecAnnounce0
function bossModPrototype:NewSpecialWarningPreWarn(spellId, optionDefault, time, ...)
	---@type SpecAnnounce0
	return newSpecialWarning(self, "prewarn", spellId, time, optionDefault, ...)
end

---@param number number
---@param forceVoice string?
---@param forcePath string?
function DBM:PlayCountSound(number, forceVoice, forcePath)
	if number > 10 then return end
	local voice
	if forceVoice then--For options example
		voice = forceVoice
	else
		voice = self.Options.CountdownVoice
	end
	local path
	local maxCount = 5
	if forcePath then
		path = forcePath
	else
		for _, count in pairs(DBM:GetCountSounds()) do
			if count.value == voice then
				path = count.path
				maxCount = count.max
				break
			end
		end
	end
	if not path or (number > maxCount) then return end
	self:PlaySoundFile(path .. number .. ".ogg")
end

---@param soundId number|string
---@param force boolean?
---@param fromBlizzAPI boolean?
function DBM:PlaySpecialWarningSound(soundId, force, fromBlizzAPI)
	if fromBlizzAPI and self.Options.DisableSWSound then return end
	local sound
	if not force and self:IsTrivial() and self.Options.DontPlayTrivialSpecialWarningSound then
		sound = self.Options.RaidWarningSound
	else
		sound = type(soundId) == "number" and self.Options["SpecialWarningSound" .. (soundId == 1 and "" or soundId)] or soundId or self.Options.SpecialWarningSound
	end
	--No throttle if not from blizzard API, but 1 second throttle for same sound file if from blizzAPI since blizzard can send duplicate spammy events
	if not fromBlizzAPI or (fromBlizzAPI and self:AntiSpam(1, "PlaySpecialWarningSound", sound)) then
		self:PlaySoundFile(sound, nil, true)
	end
end

local function testWarningEnd()
	frame:SetFrameStrata("HIGH")
end

---@param text string?
---@param number number?
---@param noSound boolean?
---@param force boolean?
function DBM:ShowTestSpecialWarning(text, number, noSound, force, customIcon)
	if moving then
		return
	end
	self:AddSpecialWarning(text or L.MOVE_SPECIAL_WARNING_TEXT, force, nil, number, customIcon, noSound)
	frame:SetFrameStrata("TOOLTIP")
	self:Unschedule(testWarningEnd)
	self:Schedule(self.Options.SpecialWarningDuration2 * 1.3, testWarningEnd)
end
