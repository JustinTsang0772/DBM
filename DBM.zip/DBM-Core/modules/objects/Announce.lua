---@class DBMCoreNamespace
local private = select(2, ...)

local L = DBM_CORE_L
local CL = DBM_COMMON_L

local DBMScheduler = private:GetModule("DBMScheduler")
local stringUtils = private:GetPrototype("StringUtils")
local checkEntry = private:GetPrototype("TableUtils").checkEntry
local RAID_CLASS_COLORS = _G["CUSTOM_CLASS_COLORS"] or RAID_CLASS_COLORS-- for Phanx' Class Colors

---@class DBM
local DBM = private:GetPrototype("DBM")
---@class Announce
local announcePrototype = private:GetPrototype("Announce")
---@class DBMMod
local bossModPrototype = private:GetPrototype("DBMMod")

private.blizzTargetQueue = private.blizzTargetQueue or setmetatable({}, {__mode = "k"})
local blizzTargetQueue = private.blizzTargetQueue

local mt = {__index = announcePrototype}

---@param queue table
---@param entry table
local function removeBlizzTargetQueueEntry(queue, entry)
	for i = #queue.ordered, 1, -1 do
		if queue.ordered[i] == entry then
			table.remove(queue.ordered, i)
			break
		end
	end
end

---@param announceObject Announce
---@param count number?
function DBM:QueueBlizzTargetAnnounce(announceObject, count)
	if not announceObject or announceObject.announceType ~= "blizztarget" then return end
	local mod = announceObject.mod
	if not mod then return end
	local queue = blizzTargetQueue[mod]
	if not queue then
		queue = {
			ordered = {}
		}
		blizzTargetQueue[mod] = queue
	end
	local entry = {
		announce = announceObject,
		count = count
	}
	table.insert(queue.ordered, entry)
end

---@param formattedTargetName string
---@return boolean
function DBM:ConsumeBlizzTargetAnnounce(formattedTargetName)
	for mod, queue in pairs(blizzTargetQueue) do
		local entry
		if #queue.ordered > 0 then
			entry = queue.ordered[1]
			removeBlizzTargetQueueEntry(queue, entry)
		end
		if #queue.ordered == 0 then
			blizzTargetQueue[mod] = nil
		end
		if entry and entry.announce then
			entry.announce:Show(entry.count, formattedTargetName)
			return true
		end
	end
	return false
end

---@diagnostic disable: inject-field
local frame = CreateFrame("Frame", "DBMWarning", UIParent)
local font1u = CreateFrame("Frame", "DBMWarning1Updater", UIParent)
local font2u = CreateFrame("Frame", "DBMWarning2Updater", UIParent)
local font3u = CreateFrame("Frame", "DBMWarning3Updater", UIParent)
local font1 = frame:CreateFontString("DBMWarning1", "OVERLAY", "GameFontNormal")
font1:SetWidth(1024)
font1:SetHeight(0)
font1:SetPoint("TOP", 0, 0)
local font2 = frame:CreateFontString("DBMWarning2", "OVERLAY", "GameFontNormal")
font2:SetWidth(1024)
font2:SetHeight(0)
font2:SetPoint("TOP", font1, "BOTTOM", 0, 0)
local font3 = frame:CreateFontString("DBMWarning3", "OVERLAY", "GameFontNormal")
font3:SetWidth(1024)
font3:SetHeight(0)
font3:SetPoint("TOP", font2, "BOTTOM", 0, 0)
frame:SetMovable(true)
frame:SetWidth(1)
frame:SetHeight(1)
frame:SetFrameStrata("HIGH")
frame:SetClampedToScreen(true)
frame:SetPoint("CENTER", UIParent, "CENTER", 0, 300)
font1u:Hide()
font2u:Hide()
font3u:Hide()

local font1elapsed, font2elapsed, font3elapsed
local font2Secret, font3Secret = false, false

local function fontHide1(overrideDuration)
	local duration = overrideDuration or DBM.Options.WarningDuration2
	if font1elapsed > duration * 1.3 then
		font1u:Hide()
		font1:Hide()
		if frame.font1ticker then
			frame.font1ticker:Cancel()
			frame.font1ticker = nil
		end
	elseif font1elapsed > duration then
		font1elapsed = font1elapsed + 0.05
		local alpha = 1 - (font1elapsed - duration) / (duration * 0.3)
		font1:SetAlpha(alpha > 0 and alpha or 0)
	else
		font1elapsed = font1elapsed + 0.05
		font1:SetAlpha(1)
	end
end

local function fontHide2(overrideDuration)
	local duration = overrideDuration or DBM.Options.WarningDuration2
	if font2elapsed > duration * 1.3 then
		font2u:Hide()
		font2:Hide()
		if frame.font2ticker then
			frame.font2ticker:Cancel()
			frame.font2ticker = nil
		end
	elseif font2elapsed > duration then
		font2elapsed = font2elapsed + 0.05
		local alpha = 1 - (font2elapsed - duration) / (duration * 0.3)
		font2:SetAlpha(alpha > 0 and alpha or 0)
	else
		font2elapsed = font2elapsed + 0.05
		font2:SetAlpha(1)
	end
end

local function fontHide3(overrideDuration)
	local duration = DBM.Options.WarningDuration2
	if font3elapsed > duration * 1.3 then
		font3u:Hide()
		font3:Hide()
		if frame.font3ticker then
			frame.font3ticker:Cancel()
			frame.font3ticker = nil
		end
	elseif font3elapsed > duration then
		font3elapsed = font3elapsed + 0.05
		local alpha = 1 - (font3elapsed - duration) / (duration * 0.3)
		font3:SetAlpha(alpha > 0 and alpha or 0)
	else
		font3elapsed = font3elapsed + 0.05
		font3:SetAlpha(1)
	end
end

font1u:SetScript("OnUpdate", function(self)
	local diff = GetTime() - font1.lastUpdate
	local origSize = DBM.Options.WarningFontSize
	if diff > 0.4 then
		font1:SetTextHeight(origSize)
		self:Hide()
	elseif diff > 0.2 then
		font1:SetTextHeight(origSize * (1.5 - (diff - 0.2) * 2.5))
	else
		font1:SetTextHeight(origSize * (1 + diff * 2.5))
	end
end)

font2u:SetScript("OnUpdate", function(self)
	local diff = GetTime() - font2.lastUpdate
	local origSize = DBM.Options.WarningFontSize
	if diff > 0.4 then
		font2:SetTextHeight(origSize)
		self:Hide()
	elseif diff > 0.2 then
		font2:SetTextHeight(origSize * (1.5 - (diff - 0.2) * 2.5))
	else
		font2:SetTextHeight(origSize * (1 + diff * 2.5))
	end
end)

font3u:SetScript("OnUpdate", function(self)
	local diff = GetTime() - font3.lastUpdate
	local origSize = DBM.Options.WarningFontSize
	if diff > 0.4 then
		font3:SetTextHeight(origSize)
		self:Hide()
	elseif diff > 0.2 then
		font3:SetTextHeight(origSize * (1.5 - (diff - 0.2) * 2.5))
	else
		font3:SetTextHeight(origSize * (1 + diff * 2.5))
	end
end)

local warningFontResetNotified = false
local function getSafeWarningFontSettings(self)
	local font = self.Options.WarningFont == "standardFont" and private.standardFont or self.Options.WarningFont
	local size = self.Options.WarningFontSize
	local style = (self.Options.WarningFontStyle and not DBM:IsNoneValue(self.Options.WarningFontStyle)) and self.Options.WarningFontStyle or ""
	if not DBM:IsFontValid(font, private.standardFont, size, style) then
		self.Options.WarningFont = self.DefaultOptions.WarningFont
		self.Options.WarningFontSize = self.DefaultOptions.WarningFontSize
		self.Options.WarningFontStyle = self.DefaultOptions.WarningFontStyle
		if not warningFontResetNotified then
			self:AddMsg("Invalid Warning font settings were detected and reset to defaults.")
			warningFontResetNotified = true
		end
		font = self.Options.WarningFont == "standardFont" and private.standardFont or self.Options.WarningFont
		size = self.Options.WarningFontSize
		style = (self.Options.WarningFontStyle and not DBM:IsNoneValue(self.Options.WarningFontStyle)) and self.Options.WarningFontStyle or ""
	end
	return font, size, style
end

function DBM:UpdateWarningOptions()
	frame:ClearAllPoints()
	frame:SetPoint(self.Options.WarningPoint, UIParent, self.Options.WarningPoint, self.Options.WarningX, self.Options.WarningY)
	local font, size, style = getSafeWarningFontSettings(self)
	font1:SetFont(font, size, style)
	font2:SetFont(font, size, style)
	font3:SetFont(font, size, style)
	if self.Options.WarningFontShadow then
		font1:SetShadowOffset(1, -1)
		font2:SetShadowOffset(1, -1)
		font3:SetShadowOffset(1, -1)
	else
		font1:SetShadowOffset(0, 0)
		font2:SetShadowOffset(0, 0)
		font3:SetShadowOffset(0, 0)
	end
end

local textureCode = " |T%s:12:12|t "
local textureExp = " |T(%S+......%S+):12:12|t "--Fix texture file including blank not strips(example: Interface\\Icons\\Spell_Frost_Ring of Frost). But this have limitations. Since I'm poor at regular expressions, this is not good fix. Do you have another good regular expression, tandanu?

---@param text any
---@param force boolean?
---@param announceObject any
---@param useSound boolean?
---@param prefix boolean?
---@param overrideDuration number?
---@param customIcon string|number? Custom Icon, usually a "secret" icon path or texture id
function DBM:AddWarning(text, force, announceObject, useSound, prefix, overrideDuration, customIcon)
	if self.Options.DontShowBossAnnounces or self.Options.HideDBMWarnings then return end
	local added = false
	local hasCustomIcon = self:issecretvalue(customIcon) or (customIcon ~= nil and customIcon ~= false)
	if prefix then
		if self:issecretvalue(text) then
			text = ("|cffff7d0a<|r|cffffd200%s|r|cffff7d0a>|r %s"):format(L.DBM, text)
		else
			text = ("|cffff7d0a<|r|cffffd200%s|r|cffff7d0a>|r %s"):format(tostring(L.DBM), tostring(text))
		end
	end
	local formatedText
	if C_StringUtil and hasCustomIcon then
		local left, right = "", ""
		if self.Options.WarningIconLeft then
			left = textureCode:format(customIcon)
		end
		if self.Options.WarningIconRight then
			right = textureCode:format(customIcon)
		end
		formatedText = C_StringUtil.WrapString(text, left, right)
	else
		formatedText = text
	end
	local replaceLast = force or (frame.font1ticker and frame.font2ticker and frame.font3ticker and (font2Secret or font3Secret or hasCustomIcon))
	if not frame.font1ticker then
		font1elapsed = 0
		font1.lastUpdate = GetTime()
		font1:SetText(formatedText)
		font1:Show()
		font1u:Show()
		added = true
		frame.font1ticker = frame.font1ticker or C_Timer.NewTicker(0.05, function() fontHide1(overrideDuration) end)
	elseif not frame.font2ticker then
		font2elapsed = 0
		font2.lastUpdate = GetTime()
		font2:SetText(formatedText)
		font2Secret = self:issecretvalue(formatedText)
		font2:Show()
		font2u:Show()
		added = true
		frame.font2ticker = frame.font2ticker or C_Timer.NewTicker(0.05, function() fontHide2(overrideDuration) end)
	elseif not frame.font3ticker or replaceLast then
		font3elapsed = 0
		font3.lastUpdate = GetTime()
		font3:SetText(formatedText)
		font3Secret = self:issecretvalue(formatedText)
		font3:Show()
		font3u:Show()
		fontHide3()
		added = true
		frame.font3ticker = frame.font3ticker or C_Timer.NewTicker(0.05, function() fontHide3(overrideDuration) end)
	end
	if not added then
		if not hasCustomIcon then
			--Secret slots are replaced above instead of being read back for rotation.
			local prevText1 = font2:GetText()
			local prevText2 = font3:GetText()
			font1:SetText(prevText1)
			font1elapsed = font2elapsed
			font2:SetText(prevText2)
			font2elapsed = font3elapsed
			-- Prefix is already applied; let the recursive call own sound/chat output.
			return self:AddWarning(text, true, announceObject, useSound, nil, overrideDuration, customIcon)
		end
	end
	if useSound then
		self:PlaySoundFile(self.Options.RaidWarningSound, nil, true)
	end
	--Only manually chat frame here for secrets api
	if self.Options.ShowWarningsInChat and hasCustomIcon then
		if self.Options.WarningIconChat then
			self:AddMsg(formatedText, nil, nil, nil, nil, 2)
		else
			self:AddMsg(text, nil, nil, nil, nil, 2)
		end
	end
end

---Displays a generic cast warning without caching, parsing or renaming secret spell metadata.
---Callers own their options, event registration, filtering, throttling and encounter timing.
---@param unit enemyUIDs|targetUIDs Public event unit token
---@param spellID number May be secret; passed directly to C_Spell
---@param color warningColorType? Warning color index; defaults to 3
---@param useSound boolean? Defaults to true; false keeps the warning silent
---@param showTargets boolean? Defaults to true; false skips target lookups
function DBM:AddSecretGenericWarning(unit, spellID, color, useSound, showTargets)
	if self.Options.DontShowBossAnnounces or self.Options.HideDBMWarnings then return end
	local warningColor = self.Options.WarningColors[color or 3]
	local colorCode = ("|cff%02x%02x%02x"):format(math.floor(warningColor.r * 255), math.floor(warningColor.g * 255), math.floor(warningColor.b * 255))
	local text = C_Spell.GetSpellName(spellID)
	if not self:issecretvalue(text) and text == nil then
		text = CL.UNKNOWN
	end
	text = C_StringUtil.WrapString(text, colorCode, "|r")
	if showTargets ~= false then
		local targetName = UnitSpellTargetName(unit)
		if self:issecretvalue(targetName) or targetName ~= nil then
			local className = UnitSpellTargetClass(unit)
			--Secret class tokens may be nil-checked and passed directly to the color API.
			if className ~= nil then
				local classColor = C_ClassColor.GetClassColor(className)
				if classColor then
					targetName = classColor:WrapTextInColorCode(targetName)
				end
			end
			text = L.GENERIC_TRASH_TARGET:format(text, targetName)
		end
	end
	local icon = C_Spell.GetSpellTexture(spellID)
	if not self:issecretvalue(icon) and icon == nil then
		icon = 136116
	end
	self:AddWarning(text, nil, nil, useSound ~= false, nil, nil, icon)
end

do
	local anchorFrame
	local function moveEnd(self)
		anchorFrame:Hide()
		if anchorFrame.ticker then
			anchorFrame.ticker:Cancel()
			anchorFrame.ticker = nil
		end
		font1elapsed = self.Options.WarningDuration2
		font2elapsed = self.Options.WarningDuration2
		font3elapsed = self.Options.WarningDuration2
		frame:SetFrameStrata("HIGH")
		self:Unschedule(moveEnd)
		DBT:CancelBar(L.MOVE_WARNING_BAR)
	end

	function DBM:MoveWarning()
		if not anchorFrame then
			anchorFrame = CreateFrame("Frame", nil, frame)
			anchorFrame:SetWidth(32)
			anchorFrame:SetHeight(32)
			anchorFrame:EnableMouse(true)
			anchorFrame:SetPoint("TOP", frame, "TOP", 0, 32)
			anchorFrame:RegisterForDrag("LeftButton")
			anchorFrame:SetClampedToScreen(true)
			anchorFrame:Hide()
			local texture = anchorFrame:CreateTexture()
			texture:SetTexture("Interface\\Addons\\DBM-Core\\textures\\dot.blp")
			texture:SetPoint("CENTER", anchorFrame, "CENTER", 0, 0)
			texture:SetWidth(32)
			texture:SetHeight(32)
			anchorFrame:SetScript("OnDragStart", function()
				frame:StartMoving()
				self:Unschedule(moveEnd)
				DBT:CancelBar(L.MOVE_WARNING_BAR)
			end)
			anchorFrame:SetScript("OnDragStop", function()
				frame:StopMovingOrSizing()
				local point, _, _, xOfs, yOfs = frame:GetPoint(1)
				self.Options.WarningPoint = point
				self.Options.WarningX = xOfs
				self.Options.WarningY = yOfs
				self:Schedule(15, moveEnd, self)
				DBT:CreateBar(15, L.MOVE_WARNING_BAR, private.isRetail and 237538 or 136106)
			end)
		end
		if anchorFrame:IsShown() then
			moveEnd(self)
		else
			anchorFrame:Show()
			anchorFrame.ticker = anchorFrame.ticker or C_Timer.NewTicker(5, function() self:AddWarning(L.MOVE_WARNING_MESSAGE) end)
			self:AddWarning(L.MOVE_WARNING_MESSAGE)
			self:Schedule(15, moveEnd, self)
			DBT:CreateBar(15, L.MOVE_WARNING_BAR, private.isRetail and 237538 or 136106)
			frame:Show()
			frame:SetFrameStrata("TOOLTIP")
			frame:SetAlpha(1)
		end
	end
end


-- TODO: is there a good reason that this is a weak table?
local cachedColorFunctions = setmetatable({}, {__mode = "kv"})

local function setText(announceType, spellId, castTime, preWarnTime, customName)
	local spellName
	local baseSpellName
	if customName then
		baseSpellName = customName
	else
		baseSpellName = DBM:ParseSpellName(spellId, announceType) or CL.UNKNOWN
	end
	if spellId and DBM.Options.WarningShortText then
		spellName = DBM:GetRename(spellId, baseSpellName)
	else
		spellName = baseSpellName
	end
	local text
	if announceType == "cast" then
		local spellHaste = select(4, DBM:GetSpellInfo(10059)) / 10000 -- 10059 = Stormwind Portal, should have 10000 ms cast time
		local timer = (select(4, DBM:GetSpellInfo(spellId)) or 1000) / spellHaste
		text = L.AUTO_ANNOUNCE_TEXTS[announceType]:format(spellName, castTime or (timer / 1000))
	elseif announceType == "prewarn" then
		if type(preWarnTime) == "string" then
			error("preWarnTime is string. Notify DBM Authors")
		else
			text = L.AUTO_ANNOUNCE_TEXTS[announceType]:format(spellName, L.SEC_FMT:format(tostring(preWarnTime or 5)))
		end
	elseif announceType == "stage" or announceType == "prestage" then
		text = L.AUTO_ANNOUNCE_TEXTS[announceType]:format(tostring(spellId))
	elseif announceType == "stagechange" then
		text = L.AUTO_ANNOUNCE_TEXTS.spell
	else
		text = L.AUTO_ANNOUNCE_TEXTS[announceType]:format(spellName)
	end
	return text, spellName
end

function announcePrototype:SetText(customName)
	local text, spellName = setText(self.announceType, self.spellId, self.castTime, self.preWarnTime, customName)
	self.text = text
	self.spellName = spellName
	self.customName = customName
	self.renameRevision = DBM:GetSpellRenameRevision()
end

---Update icon on object and nothing else.
---<br>Does not change spellId/spellkey associated with weakauras/callbacks
---@param altSpellId string|number
function announcePrototype:UpdateIcon(altSpellId)
	self.icon = DBM:ParseSpellIcon(altSpellId, self.announceType, self.icon)
end

---Not to be confused with SetText, which only sets the text of object.
---<br>This changes actual ID so announce callback also swaps ID for WAs
---@param altSpellId string|number
function announcePrototype:UpdateKey(altSpellId)
	self.spellId = altSpellId
	self.icon = DBM:ParseSpellIcon(altSpellId, self.announceType, self.icon)
	if self.announceType then
		--Regenerate auto localized text if it's an auto localized alert
		local text, spellName = setText(self.announceType, self.spellId, self.castTime, self.preWarnTime)
		self.text = text
		self.spellName = spellName
		self.customName = nil
		self.renameRevision = DBM:GetSpellRenameRevision()
	else--Just regenerating spellName not message text because it's likely a custom text object such as NewSpecialWarning
		self.originalSpellName = DBM:ParseSpellName(altSpellId)
		self.spellName = DBM.Options.WarningShortText and DBM:GetRename(altSpellId, self.originalSpellName) or self.originalSpellName
	end
end

---Function used for changing warning color on fly when used for multiple warning priorities
---@param color number 1 = Positive Message, 2 = Normal Message, 3 - Higher Priority, 4 - Highest Priority
function announcePrototype:UpdateColor(color)
	self.color = DBM.Options.WarningColors[color or 1]
end

---@class Announce0: Announce
---@field Show fun(self: Announce0)
---@class Announce1: Announce
---@field Show fun(self: Announce1, arg1: string|number)
---@class Announce1Num: Announce
---@field Show fun(self: Announce1Num, arg1: number)
---@class Announce2: Announce
---@field Show fun(self: Announce2, arg1: string|number, arg2: string|number)
---@class Announce2StrNum: Announce
---@field Show fun(self: Announce2StrNum, arg1: string|number, arg2: number)
---@class Announce2NumStr: Announce
---@field Show fun(self: Announce2NumStr, arg1: number, arg2: string|number)

---Used to set fallback options to blizzard encounter API for hardcoded warnings to fall back on
---@param encounterEventId number|table EncounterEventID from EncounterEvent.db2 that matches event we're targetting
---@param voice VPSound voice pack media path
---@param voiceVersion number Required voice pack verion (if not met, falls back to default special warning sounds)
---@param color warningColorType? ColorId 1-4
---@param overrideType number? Optional override type for the alert
function announcePrototype:SetAlert(encounterEventId, voice, voiceVersion, color, overrideType)
	if self.option and self.mod.Options[self.option] then
		self.mod:EnableAlertOptions(self.spellId, encounterEventId, voice, voiceVersion, color, overrideType, self.option, true)
	end
end

-- TODO: this function is an abomination, it needs to be rewritten. Also: check if these work-arounds are still necessary
---@param self Announce
---@param secret boolean
---@param ... any
local function showAnnounce(self, secret, ...) -- todo: reduce amount of unneeded strings
	if self.announceType == "blizztarget" then
		local count, targetName = ...
		if select("#", ...) < 2 or type(targetName) ~= "string" then
			DBM:QueueBlizzTargetAnnounce(self, count)
			return
		end
	end
	if not self.option or self.mod.Options[self.option] then
		if DBM.Options.DontShowBossAnnounces or DBM.Options.HideDBMWarnings then return end	-- don't show the announces if the spam filter option is set
		if DBM.Options.DontShowTargetAnnouncements and (self.announceType == "target" or self.announceType == "targetcount") and not self.noFilter then return end--don't show announces that are generic target announces
		local renameSpellKey = DBM:NormalizeSpellRenameKey(self.spellId)
		if renameSpellKey and self.renameRevision ~= DBM:GetSpellRenameRevision() then
			if self.announceType then
				local text, spellName = setText(self.announceType, self.spellId, self.castTime, self.preWarnTime, self.customName)
				self.text = text
				self.spellName = spellName
			else
				local originalSpellName = self.originalSpellName or DBM:ParseSpellName(self.spellId) or CL.UNKNOWN
				self.spellName = DBM.Options.WarningShortText and DBM:GetRename(self.spellId, originalSpellName) or originalSpellName
			end
			self.renameRevision = DBM:GetSpellRenameRevision()
		end
		local isSecretBlizzType = secret or self.announceType == "blizztarget" or DBM:hasanysecretvalues(...)
		local argTable
		if not isSecretBlizzType then
			--Don't create table out of args if it has secrets
			argTable = {...}
		end
		local colorCode = ("|cff%.2x%.2x%.2x"):format(self.color.r * 255, self.color.g * 255, self.color.b * 255)
		if argTable and #self.combinedtext > 0 then
			--Throttle spam.
			if DBM.Options.WarningAlphabetical then
				table.sort(self.combinedtext)
			end
			local combinedText = table.concat(self.combinedtext, "<, >")
			if self.combinedcount == 1 then
				combinedText = combinedText .. " " .. L.GENERIC_WARNING_OTHERS
			elseif self.combinedcount > 1 then
				combinedText = combinedText .. " " .. L.GENERIC_WARNING_OTHERS2:format(self.combinedcount)
			end
			--Process
			for i = 1, #argTable do
				if type(argTable[i]) == "string" then
					argTable[i] = combinedText
				end
			end
		end
		local announceCount
		--blizztarget purposely omited from here even though it's also a count warning, we don't want to perform any extra actions on secrets
		if self.announceType and (self.announceType == "count" or self.announceType == "targetcount" or self.announceType == "sooncount" or self.announceType == "incomingcount") then--Don't use find "count" here, it'll match countdown
			--Stage triggers don't pass count, but they do not need to, there is a stage callback and trigger option in WA that should be used
			local count = select(1, ...)
			if not DBM:issecretvalue(count) and type(count) == "number" then
				announceCount = count
			end
		end
		local message
		if argTable then
			message = stringUtils.pformat(self.text, unpack(argTable))
		else
			message = stringUtils.secretFormat(self.text, ...)
		end
		--This might still throw errors if we don't use C_StringUtil.WrapText instead. Will test
		local text = ("%s%s%s|r%s"):format(
			(DBM.Options.WarningIconLeft and self.icon and textureCode:format(self.icon)) or "",
			colorCode,
			message,
			(DBM.Options.WarningIconRight and self.icon and textureCode:format(self.icon)) or ""
		)
		self.combinedcount = 0
		self.combinedtext = {}
		--Avoid computational actions on secret passthrough warnings
		if not isSecretBlizzType then
			if not cachedColorFunctions[self.color] then
				local color = self.color -- upvalue for the function to colorize names, accessing self in the colorize closure is not safe as the color of the announce object might change (it would also prevent the announce from being garbage-collected but announce objects are never destroyed)
				cachedColorFunctions[color] = function(cap)
					cap = cap:sub(2, -2)
					local noStrip = cap:match("noStrip ")
					if not noStrip then
						local name = cap
						local playerClass, playerIcon = DBM:GetRaidClass(name)
						if playerClass ~= "UNKNOWN" then
							cap = DBM:GetShortServerName(cap)--Only run realm strip function if class color was valid (IE it's an actual playername)
						end
						local playerColor = RAID_CLASS_COLORS[playerClass] or color
						if playerColor then
							if playerIcon > 0 and playerIcon <= 8 then
								cap = ("|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_%d:0|t"):format(playerIcon) .. ("|r|cff%.2x%.2x%.2x%s|r|cff%.2x%.2x%.2x"):format(playerColor.r * 255, playerColor.g * 255, playerColor.b * 255, cap, color.r * 255, color.g * 255, color.b * 255)
							else
								cap = ("|r|cff%.2x%.2x%.2x%s|r|cff%.2x%.2x%.2x"):format(playerColor.r * 255, playerColor.g * 255, playerColor.b * 255, cap, color.r * 255, color.g * 255, color.b * 255)
							end
						end
					else
						cap = cap:sub(9)
					end
					return cap
				end
			end
			text = text:gsub(">.-<", cachedColorFunctions[self.color])
		end
		DBM:AddWarning(text, nil, self)
		if DBM.Options.ShowWarningsInChat then
			if not DBM.Options.WarningIconChat and isSecretBlizzType then
				text = ("%s%s|r"):format(colorCode, message)
			elseif not DBM.Options.WarningIconChat then
				text = text:gsub(textureExp, "") -- textures @ chat frame can (and will) distort the font if using certain combinations of UI scale, resolution and font size TODO: is this still true as of cataclysm?
			end
			self.mod:AddMsg(text, nil)
		end
		--Message: Full message text
		--Icon: Texture path/id for icon
		--Type: Announce type
		----Types: you, target, targetcount, targetsource, spell, ends, endtarget, fades, fadesoon, adds, count, stack, cast, soon, sooncount, prewarn, bait, stage, stagechange, prestage, moveto
		------Personal/Role (Applies to you, or your job): you, stack, bait, moveto, fades, fadesoon
		------General Target Messages (informative, doesn't usually apply to you): target, targetsource, targetcount
		------Fight Changes (Stages, adds, boss buff/debuff, etc): stage, stagechange, prestage, adds, ends, endtarget
		------General (can really apply to anything): spell, count, soon, sooncount, prewarn
		--SpellId: Raw spell or encounter journal Id if available.
		--Mod ID: Encounter ID as string, or a generic string for mods that don't have encounter ID (such as trash, dummy/test mods)
		--boolean: Whether or not this warning is a special warning (higher priority). BW would call this "emphasized"
		--announceCount: If it's a count announce, this will provide access to the number value of that count. This, along with spellId should be used instead of message text scanning for most weak auras that need to target specific count casts
		DBM:FireEvent("DBM_Announce", message, self.icon, self.type, self.spellId, self.mod.id, false, announceCount)
		if DBM.Options.IgnoreBlizzAPI and self.spellId and self.spellName then
			if announceCount then
				DBM:Debug("|cff00ff00Showing hardcoded warning for |r spellID |cff69ccf0" .. self.spellId .. "|r spellName |cff69ccf0" .. self.spellName .. " (" .. announceCount .. ")|r", 3, nil, nil, true, true)
			else
				DBM:Debug("|cff00ff00Showing hardcoded warning for |r spellID |cff69ccf0" .. self.spellId .. "|r spellName |cff69ccf0" .. self.spellName .. "|r", 3, nil, nil, true, true)
			end
		end
		if self.sound > 0 then--0 means muted, 1 means no voice pack support, 2 means voice pack version/support
			if self.sound > 1 and not DBM:IsNoneValue(DBM.Options.ChosenVoicePack2) and DBM.Options.VPReplacesAnnounce and not private.voiceSessionDisabled and self.sound <= private.swFilterDisabled then return end
			if not self.option or not DBM:IsNoneValue(self.mod.Options[self.option .. "SWSound"]) then
				DBM:PlaySoundFile(DBM.Options.RaidWarningSound, nil, true)--Validate true
			end
		end
	else
		self.combinedcount = 0
		self.combinedtext = {}
	end
end

function announcePrototype:Show(...)
	showAnnounce(self, false, ...)
end

---Shows a secret player name without materializing it into a Lua table.
---@param self Announce
---@param className string|nil
---@param ... any
local function secretShowByClass(self, className, ...)
	local playerName = select(1, ...)
	if not DBM:issecretvalue(playerName) and playerName == nil then
		playerName = CL.UNKNOWN
	end
	if className then
		local classColor = C_ClassColor.GetClassColor(className)
		if classColor then
			playerName = classColor:WrapTextInColorCode(playerName)
		end
	end
	showAnnounce(self, true, playerName, select(2, ...))
end

---Shows a secret player name from an ENCOUNTER_WARNING target GUID without materializing it into a Lua table.
---Optionally class-colors the secret player name from its GUID.
---@param playerGUID WOWGUID|false|nil
---@param ... any
function announcePrototype:SecretShowByGUID(playerGUID, ...)
	local className
	if playerGUID then
		local _
		_, className = GetPlayerInfoByGUID(playerGUID)
	end
	secretShowByClass(self, className, ...)
end

---Shows a unit's secret spell target without materializing it into a Lua table.
---@param unit enemyUIDs|targetUIDs
function announcePrototype:SecretShowByUnit(unit)
	secretShowByClass(self, UnitSpellTargetClass(unit), UnitSpellTargetName(unit))
end

---Shows a unit's secret spell target after a delay.
---@param delay number
---@param unit enemyUIDs|targetUIDs
function announcePrototype:ScheduleSecret(delay, unit)
	self.mod:Schedule(delay, function()
		self:SecretShowByUnit(unit)
	end)
end

---Object that's used when precision isn't possible (number of targets variable or unknown)
---@param delay number
---@param ... any
function announcePrototype:CombinedShow(delay, ...)
	if DBM:hasanysecretvalues(...) then
		DBMScheduler:Unschedule(self.Show, self.mod, self)
		self:Show(...)
		return
	end
	if self.option and not self.mod.Options[self.option] then return end
	if DBM.Options.DontShowBossAnnounces or DBM.Options.HideDBMWarnings then return end	-- don't show the announces if the spam filter option is set
	if DBM.Options.DontShowTargetAnnouncements and (self.announceType == "target" or self.announceType == "targetcount") and not self.noFilter then return end--don't show announces that are generic target announces
	local argTable = {...}
	for i = 1, #argTable do
		if type(argTable[i]) == "string" then
			if #self.combinedtext < 7 then--Throttle spam. We may not need more than 6 targets..
				if not checkEntry(self.combinedtext, argTable[i]) then
					self.combinedtext[#self.combinedtext + 1] = argTable[i]
				end
			else
				self.combinedcount = self.combinedcount + 1
			end
		end
	end
	DBMScheduler:Unschedule(self.Show, self.mod, self)
	DBMScheduler:Schedule(delay or 0.5, self.Show, self.mod, self, ...)
end

---New object that allows defining count instead of scheduling for more efficient and immediate warnings when precise count is known
---@param maxTotal number
---@param ... any
function announcePrototype:PreciseShow(maxTotal, ...)
	if DBM:hasanysecretvalues(...) then
		DBMScheduler:Unschedule(self.Show, self.mod, self)
		self:Show(...)
		return
	end
	if self.option and not self.mod.Options[self.option] then return end
	if DBM.Options.DontShowBossAnnounces or DBM.Options.HideDBMWarnings then return end	-- don't show the announces if the spam filter option is set
	if DBM.Options.DontShowTargetAnnouncements and (self.announceType == "target" or self.announceType == "targetcount") and not self.noFilter then return end--don't show announces that are generic target announces
	local argTable = {...}
	for i = 1, #argTable do
		if type(argTable[i]) == "string" then
			if #self.combinedtext < 7 then--Throttle spam. We may not need more than 6 targets..
				if not checkEntry(self.combinedtext, argTable[i]) then
					self.combinedtext[#self.combinedtext + 1] = argTable[i]
				end
			else
				self.combinedcount = self.combinedcount + 1
			end
		end
	end
	DBMScheduler:Unschedule(self.Show, self.mod, self)
	local viableTotal = DBM:NumRealAlivePlayers()
	if (maxTotal <= #self.combinedtext + self.combinedcount) or (viableTotal <= #self.combinedtext + self.combinedcount) then--All targets gathered, show immediately
		self:Show(...)--Does this need self or mod? will it have this bug? https://github.com/DeadlyBossMods/DBM-Unified/issues/153
	else--And even still, use scheduling backup in case counts still fail
		DBMScheduler:Schedule(1.2, self.Show, self.mod, self, ...)
	end
end

---@param t number
---@param ... any
function announcePrototype:Schedule(t, ...)
	local id = DBMScheduler:Schedule(t, self.Show, self.mod, self, ...)
	return id
end

---@param time number?
---@param numAnnounces number?
---@param ... any
function announcePrototype:Countdown(time, numAnnounces, ...)
	DBMScheduler:ScheduleCountdown(time, numAnnounces, self.Show, self.mod, self, ...)
end

---@param time number|table
---@param count number
function announcePrototype:Loop(time, count)
	DBMScheduler:ScheduleLoop(time, self.Show, self.mod, self, count)
end

function announcePrototype:Cancel(...)
	return DBMScheduler:Unschedule(self.Show, self.mod, self, ...)
end

---@param name VPSound?
---@param customPath? string|number
function announcePrototype:Play(name, customPath)
	local voice = DBM.Options.ChosenVoicePack2
	if DBM.Options.HideDBMWarnings then return end
	if private.voiceSessionDisabled or DBM:IsNoneValue(voice) or not DBM.Options.VPReplacesAnnounce then return end
	if DBM.Options.DontShowTargetAnnouncements and (self.announceType == "target" or self.announceType == "targetcount") and not self.noFilter then return end--don't show announces that are generic target announces
	if (not DBM.Options.DontShowBossAnnounces and (not self.option or self.mod.Options[self.option])) and self.sound <= private.swFilterDisabled then
		--Filter tank specific voice alerts for non tanks if tank filter enabled
		if (name == "changemt" or name == "tauntboss") and not self.mod:IsTank() then return end
		local path = customPath or ("Interface\\AddOns\\DBM-VP" .. voice .. "\\" .. name .. ".ogg")
		DBM:PlaySoundFile(path)
	end
end

---@param t number
---@param name VPSound?
---@param customPath? string|number
function announcePrototype:ScheduleVoice(t, name, customPath)
	if private.voiceSessionDisabled or DBM:IsNoneValue(DBM.Options.ChosenVoicePack2) or not DBM.Options.VPReplacesAnnounce then return end
	DBMScheduler:Unschedule(self.Play, self.mod, self)--Allow ScheduleVoice to be used in same way as CombinedShow
	local id = DBMScheduler:Schedule(t, self.Play, self.mod, self, name, customPath)
	return id
end

---Object Permits scheduling voice multiple times for same object
---@param t number
---@param name VPSound?
---@param customPath? string|number
function announcePrototype:ScheduleVoiceOverLap(t, name, customPath)
	if private.voiceSessionDisabled or DBM:IsNoneValue(DBM.Options.ChosenVoicePack2) or not DBM.Options.VPReplacesAnnounce then return end
	local id = DBMScheduler:Schedule(t, self.Play, self.mod, self, name, customPath)
	return id
end

function announcePrototype:CancelVoice(...)
	if private.voiceSessionDisabled or DBM:IsNoneValue(DBM.Options.ChosenVoicePack2) or not DBM.Options.VPReplacesAnnounce then return end
	return DBMScheduler:Unschedule(self.Play, self.mod, self, ...)
end

---old constructor (no auto-localize)
---@param text string
---@param color warningColorType?
---@param icon number|string? Use number for spellId, -number for journalID, number as string for textureID
---@param optionDefault SpecFlags|boolean?
---@param optionName string|boolean? String for custom option name. Using false hides option completely
---@param soundOption number|boolean? 0 = No Sound, 1 = Sound with no voice pack support, >=2 = Voice pack version/support
---@param spellID number|string? Used to define a spellID used for GroupSpells and WeakAura key
---@param waCustomName any? Used to show custom name/text for Spell header (usually used when a made up SpellID is used)
function bossModPrototype:NewAnnounce(text, color, icon, optionDefault, optionName, soundOption, spellID, waCustomName)
	if not text then
		error("NewAnnounce: you must provide announce text", 2)
	end
	if type(text) == "number" then
		DBM:Debug("|cffff0000NewAnnounce: Non auto localized text cannot be numbers, fix this for |r" .. text)
	end
	if type(optionName) == "number" then
		DBM:Debug("|cffff0000NewAnnounce: Non auto localized optionNames cannot be numbers, fix this for |r" .. text)
		optionName = nil
	end
	if soundOption and type(soundOption) == "boolean" then
		soundOption = 0--No Sound
	end
	icon = DBM:ParseSpellIcon(icon)
	local spellName
	local originalSpellName
	local renameRevision
	if spellID then
		local baseSpellName = waCustomName or DBM:ParseSpellName(spellID) or CL.UNKNOWN
		originalSpellName = baseSpellName
		spellName = DBM.Options.WarningShortText and DBM:GetRename(spellID, baseSpellName) or baseSpellName
		renameRevision = DBM:GetSpellRenameRevision()
	end
	---@class Announce
	local obj = setmetatable(
		{
			objClass = "Announce",
			text = self.localization.warnings[text],
			combinedtext = {},
			combinedcount = 0,
			color = DBM.Options.WarningColors[color or 1] or DBM.Options.WarningColors[1],
			sound = soundOption or 1,
			mod = self,
			icon = icon,
			spellId = spellID,--For WeakAuras / other callbacks
			spellName = spellName,
			originalSpellName = originalSpellName,
			renameRevision = renameRevision,
		},
		mt
	)
	if optionName then
		obj.option = optionName
		self:AddBoolOption(obj.option, optionDefault, "announce", nil, nil, nil, spellID, nil, waCustomName)
	elseif optionName ~= false then
		obj.option = text
		self:AddBoolOption(obj.option, optionDefault, "announce", nil, nil, nil, spellID, nil, waCustomName)
	end
	tinsert(self.announces, obj)
	return obj
end

-- new constructor (partially auto-localized warnings and options, yay!)
---@return Announce|Announce0|Announce1|Announce2
local function newAnnounce(self, announceType, spellId, color, icon, optionDefault, optionName, castTime, preWarnTime, soundOption, noFilter)
	if not spellId then
		error("newAnnounce: you must provide spellId", 2)
	end
	local optionVersion
	if type(optionName) == "number" then
		if optionName > 0 and optionName < 6 then
			optionVersion = optionName
			optionName = nil
		else
			error("newAnnounce: numeric optionName is only supported as optionVersion shorthand for values 1-5.", 2)
		end
	end
	if type(preWarnTime) == "string" then
		error("newAnnounce: string preWarnTime legacy short-text path is removed. Use DBM:RegisterAltSpellName in module setup.", 2)
	end
	if soundOption and type(soundOption) == "boolean" then
		soundOption = 0--No Sound
	end
	local text, spellName = setText(announceType, spellId, castTime, preWarnTime)
	icon = DBM:ParseSpellIcon(icon or spellId)
	---@class Announce
	local obj = setmetatable( -- todo: fix duplicate code
		{
			objClass = "Announce",
			text = text,
			combinedtext = {},
			combinedcount = 0,
			announceType = announceType,
			color = DBM.Options.WarningColors[color or 1] or DBM.Options.WarningColors[1],
			mod = self,
			icon = icon,
			sound = soundOption or 1,
			type = announceType,
			spellId = spellId,
			spellName = spellName,
			customName = nil,
			renameRevision = DBM:GetSpellRenameRevision(),
			noFilter = noFilter,
			castTime = castTime,
			preWarnTime = preWarnTime,
		},
		mt
	)
	if optionName then
		obj.option = optionName
		self:AddBoolOption(obj.option, optionDefault, "announce", nil, nil, nil, spellId, announceType)
	elseif optionName ~= false then
		obj.option = "announce" .. spellId .. announceType .. (optionVersion or "")
		self:AddBoolOption(obj.option, optionDefault, "announce", nil, nil, nil, spellId, announceType)
		if noFilter and announceType == "target" then
			self.localization.options[obj.option] = L.AUTO_ANNOUNCE_OPTIONS["targetNF"]:format(spellId)
		else
			self.localization.options[obj.option] = L.AUTO_ANNOUNCE_OPTIONS[announceType]:format(spellId)
		end
	end
	tinsert(self.announces, obj)
	return obj
end

---@overload fun(self, spellId: number|string, color: number?, icon: number|string?, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, castTime: number?, preWarnTime: number?, soundOption: number|boolean?, noFilter: boolean?): Announce0
function bossModPrototype:NewYouAnnounce(spellId, color, ...)
	---@type Announce0
	return newAnnounce(self, "you", spellId, color or 1, ...)
end

---@param spellId number|string
---@param color warningColorType?
---@param icon number|string?
---@param optionDefault SpecFlags|boolean?
---@param optionName string|optionNumbers|boolean?
---@param castTime number?
---@param preWarnTime number?
---@param soundOption number|boolean?
function bossModPrototype:NewTargetNoFilterAnnounce(spellId, color, icon, optionDefault, optionName, castTime, preWarnTime, soundOption) -- spellId, color, icon, optionDefault, optionName, castTime, preWarnTime, soundOption, noFilter
	---@type Announce1
	return newAnnounce(self, "target", spellId, color or 3, icon, optionDefault, optionName, castTime, preWarnTime, soundOption, true)
end

---@overload fun(self, spellId: number|string, color: number?, icon: number|string?, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, castTime: number?, preWarnTime: number?, soundOption: number|boolean?, noFilter: boolean?): Announce1
function bossModPrototype:NewTargetAnnounce(spellId, color, ...)
	---@type Announce1
	return newAnnounce(self, "target", spellId, color or 3, ...)
end

---Special object used for blizzard target announces using secret target pulled from ENCOUNTER_WARNING
---@param spellId number|string
---@param color warningColorType?
---@param icon number|string?
---@param optionDefault SpecFlags|boolean?
---@param optionName string|optionNumbers|boolean?
---@param castTime number?
---@param preWarnTime number?
---@param soundOption number|boolean?
function bossModPrototype:NewBlizzTargetAnnounce(spellId, color, icon, optionDefault, optionName, castTime, preWarnTime, soundOption)
	--Purposely not typecast, it'll be using secret target we can't validate
	return newAnnounce(self, "blizztarget", spellId, color or 3, icon, optionDefault, optionName, castTime, preWarnTime, soundOption, true)
end

---@overload fun(self, spellId: number|string, color: number?, icon: number|string?, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, castTime: number?, preWarnTime: number?, soundOption: number|boolean?, noFilter: boolean?): Announce2
function bossModPrototype:NewTargetSourceAnnounce(spellId, color, ...)
	---@type Announce2
	return newAnnounce(self, "targetsource", spellId, color or 3, ...)
end

---@overload fun(self, spellId: number|string, color: number?, icon: number|string?, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, castTime: number?, preWarnTime: number?, soundOption: number|boolean?, noFilter: boolean?): Announce2NumStr
function bossModPrototype:NewTargetCountAnnounce(spellId, color, ...)
	---@type Announce2NumStr
	return newAnnounce(self, "targetcount", spellId, color or 3, ...)
end

---@overload fun(self, spellId: number|string, color: number?, icon: number|string?, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, castTime: number?, preWarnTime: number?, soundOption: number|boolean?, noFilter: boolean?): Announce0
function bossModPrototype:NewSpellAnnounce(spellId, color, ...)
	---@type Announce0
	return newAnnounce(self, "spell", spellId, color or 2, ...)
end

---@overload fun(self, spellId: number|string, color: number?, icon: number|string?, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, castTime: number?, preWarnTime: number?, soundOption: number|boolean?, noFilter: boolean?): Announce1
function bossModPrototype:NewSpellSourceAnnounce(spellId, color, ...)
	---@type Announce1
	return newAnnounce(self, "spellsource", spellId, color or 2, ...)
end

---@overload fun(self, spellId: number|string, color: number?, icon: number|string?, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, castTime: number?, preWarnTime: number?, soundOption: number|boolean?, noFilter: boolean?): Announce0
function bossModPrototype:NewIncomingAnnounce(spellId, color, ...)
	---@type Announce0
	return newAnnounce(self, "incoming", spellId, color or 2, ...)
end

---@overload fun(self, spellId: number|string, color: number?, icon: number|string?, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, castTime: number?, preWarnTime: number?, soundOption: number|boolean?, noFilter: boolean?): Announce1Num
function bossModPrototype:NewIncomingCountAnnounce(spellId, color, ...)
	---@type Announce1Num
	return newAnnounce(self, "incomingcount", spellId, color or 2, ...)
end

---@overload fun(self, spellId: number|string, color: number?, icon: number|string?, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, castTime: number?, preWarnTime: number?, soundOption: number|boolean?, noFilter: boolean?): Announce0
function bossModPrototype:NewEndAnnounce(spellId, color, ...)
	---@type Announce0
	return newAnnounce(self, "ends", spellId, color or 2, ...)
end

---@overload fun(self, spellId: number|string, color: number?, icon: number|string?, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, castTime: number?, preWarnTime: number?, soundOption: number|boolean?, noFilter: boolean?): Announce1
function bossModPrototype:NewEndTargetAnnounce(spellId, color, ...)
	---@type Announce1
	return newAnnounce(self, "endtarget", spellId, color or 2, ...)
end

---@overload fun(self, spellId: number|string, color: number?, icon: number|string?, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, castTime: number?, preWarnTime: number?, soundOption: number|boolean?, noFilter: boolean?): Announce0
function bossModPrototype:NewFadesAnnounce(spellId, color, ...)
	---@type Announce0
	return newAnnounce(self, "fades", spellId, color or 2, ...)
end

---@overload fun(self, spellId: number|string, color: number?, icon: number|string?, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, castTime: number?, preWarnTime: number?, soundOption: number|boolean?, noFilter: boolean?): Announce0
function bossModPrototype:NewFadesSoonAnnounce(spellId, color, ...)
	---@type Announce0
	return newAnnounce(self, "fadesoon", spellId, color or 2, ...)
end

---@overload fun(self, spellId: number|string, color: number?, icon: number|string?, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, castTime: number?, preWarnTime: number?, soundOption: number|boolean?, noFilter: boolean?): Announce1Num
function bossModPrototype:NewAddsLeftAnnounce(spellId, color, ...)
	---@type Announce1Num
	return newAnnounce(self, "addsleft", spellId, color or 3, ...)
end

---@overload fun(self, spellId: number|string, color: number?, icon: number|string?, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, castTime: number?, preWarnTime: number?, soundOption: number|boolean?, noFilter: boolean?): Announce1Num
function bossModPrototype:NewCountAnnounce(spellId, color, ...)
	---@type Announce1Num
	return newAnnounce(self, "count", spellId, color or 2, ...)
end

---@overload fun(self, spellId: number|string, color: number?, icon: number|string?, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, castTime: number?, preWarnTime: number?, soundOption: number|boolean?, noFilter: boolean?): Announce2StrNum
function bossModPrototype:NewStackAnnounce(spellId, color, ...)
	---@type Announce2StrNum
	return newAnnounce(self, "stack", spellId, color or 2, ...)
end

---@param spellId number|string
---@param castTime number?
---@param color warningColorType?
---@param icon number|string?
---@param optionDefault SpecFlags|boolean?
---@param optionName string|optionNumbers|boolean?
---@param soundOption number|boolean?
function bossModPrototype:NewCastAnnounce(spellId, color, castTime, icon, optionDefault, optionName, _, soundOption) -- spellId, color, castTime, icon, optionDefault, optionName, noArg, soundOption
	---@type Announce0
	return newAnnounce(self, "cast", spellId, color or 3, icon, optionDefault, optionName, castTime, nil, soundOption)
end

---@overload fun(self, spellId: number|string, color: number?, icon: number|string?, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, castTime: number?, preWarnTime: number?, soundOption: number|boolean?, noFilter: boolean?): Announce0
function bossModPrototype:NewSoonAnnounce(spellId, color, ...)
	---@type Announce0
	return newAnnounce(self, "soon", spellId, color or 2, ...)
end

---@overload fun(self, spellId: number|string, color: number?, icon: number|string?, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, castTime: number?, preWarnTime: number?, soundOption: number|boolean?, noFilter: boolean?): Announce1Num
function bossModPrototype:NewSoonCountAnnounce(spellId, color, ...)
	---@type Announce1Num
	return newAnnounce(self, "sooncount", spellId, color or 2, ...)
end

---This object disables sounds, it's almost always used in combation with a countdown timer. Even if not a countdown, its a text only spam not a sound spam
---@param spellId number|string
---@param castTime number?
---@param preWarnTime number?
---@param color warningColorType?
---@param icon number|string?
---@param optionDefault SpecFlags|boolean?
---@param optionName string|optionNumbers|boolean?
---@param noFilter boolean?
function bossModPrototype:NewCountdownAnnounce(spellId, color, icon, optionDefault, optionName, castTime, preWarnTime, _, noFilter) -- spellId, color, icon, optionDefault, optionName, castTime, preWarnTime, soundOption, noFilter
	---@type Announce1Num
	return newAnnounce(self, "countdown", spellId, color or 4, icon, optionDefault, optionName, castTime, preWarnTime, 0, noFilter)
end

---@param spellId number|string
---@param time number
---@param color warningColorType?
---@param icon number|string?
---@param optionDefault SpecFlags|boolean?
---@param optionName string|optionNumbers|boolean?
---@param soundOption number|boolean?
function bossModPrototype:NewPreWarnAnnounce(spellId, time, color, icon, optionDefault, optionName, _, soundOption) -- spellId, time, color, icon, optionDefault, optionName, noArg, soundOption
	---@type Announce0
	return newAnnounce(self, "prewarn", spellId, color or 2, icon, optionDefault, optionName, nil, time, soundOption)
end

---@overload fun(self, spellId: number|string, color: number?, icon: number|string?, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, castTime: number?, preWarnTime: number?, soundOption: number|boolean?, noFilter: boolean?): Announce0
function bossModPrototype:NewBaitAnnounce(spellId, color, ...)
	---@type Announce0
	return newAnnounce(self, "bait", spellId, color or 3, ...)
end

---@overload fun(self, spellId: number|string, color: number?, icon: number|string?, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, castTime: number?, preWarnTime: number?, soundOption: number|boolean?, noFilter: boolean?): Announce0
function bossModPrototype:NewPhaseAnnounce(stage, color, icon, ...)
	---@type Announce0
	return newAnnounce(self, "stage", stage, color or 2, icon or "136116", ...)
end

---@overload fun(self, spellId: number|string, color: number?, icon: number|string?, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, castTime: number?, preWarnTime: number?, soundOption: number|boolean?, noFilter: boolean?): Announce1
function bossModPrototype:NewPhaseChangeAnnounce(color, icon, ...)
	---@type Announce1
	return newAnnounce(self, "stagechange", 0, color or 2, icon or "136116", ...)
end

---@overload fun(self, spellId: number|string, color: number?, icon: number|string?, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, castTime: number?, preWarnTime: number?, soundOption: number|boolean?, noFilter: boolean?): Announce0
function bossModPrototype:NewPrePhaseAnnounce(stage, color, icon, ...)
	---@type Announce0
	return newAnnounce(self, "prestage", stage, color or 2, icon or "136116", ...)
end

---@overload fun(self, spellId: number|string, color: number?, icon: number|string?, optionDefault: SpecFlags|boolean?, optionName: string|optionNumbers|boolean?, castTime: number?, preWarnTime: number?, soundOption: number|boolean?, noFilter: boolean?): Announce1
function bossModPrototype:NewMoveToAnnounce(spellId, color, ...)
	---@type Announce1
	return newAnnounce(self, "moveto", spellId, color or 3, ...)
end
