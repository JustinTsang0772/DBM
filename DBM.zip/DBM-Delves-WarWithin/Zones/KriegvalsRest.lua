local mod	= DBM:NewMod("z2681", "DBM-Delves-WarWithin", 3)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20261019224209")
mod:SetHotfixNoticeRev(20240422000000)
mod:SetMinSyncRevision(20240422000000)
mod:SetZone(2681)

mod:RegisterCombat("scenario", 2681)
