local mod	= DBM:NewMod(2097, "DBM-Party-BfA", 9, 1002)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20260523021914")
mod:DisableHardcodedOptions()
mod:SetCreatureID(127479)
mod:SetEncounterID(2101)
mod:SetZone(1771)

mod:RegisterCombat("combat")

mod:RegisterEventsInCombat(
	"SPELL_CAST_START 257092 257608 257495",
	"CHAT_MSG_RAID_BOSS_EMOTE"
)

--TODO, figure out why cast time for upheavel isn't honoring 5 second pre coded
local warnUpheavel					= mod:NewTargetNoFilterAnnounce(257617, 2)
local warnUpheavelCast				= mod:NewCastAnnounce(257617, 2, 5)--Cast time until we have a target

local specWarnSandTrap				= mod:NewSpecialWarningDodge(257092, nil, nil, nil, 2, 2, nil, nil, "watchstep")
local specWarnUpheavel				= mod:NewSpecialWarningYou(257617, nil, nil, nil, 2, 2, nil, nil, "targetyou")
local yellUpheavel					= mod:NewYell(257617)
local specWarnSandstorm				= mod:NewSpecialWarningSpell(257495, nil, nil, nil, 2, 2, nil, nil, "aesoon")

--local timerReapSoulCD				= mod:NewNextTimer(13, 194956, nil, nil, nil, 5, nil, DBM_COMMON_L.TANK_ICON..DBM_COMMON_L.DEADLY_ICON)
local timerSandTrapCD				= mod:NewCDTimer(13.2, 257092, nil, nil, nil, 3)--14.2-18.6
local timerUpheavelCD				= mod:NewCDTimer(38.5, 257617, nil, nil, nil, 3)
local timerSandstormCD				= mod:NewCDTimer(34, 257495, nil, nil, nil, 2)--Health based?

function mod:OnCombatStart(delay)
	timerSandTrapCD:Start(8.1-delay)
	timerUpheavelCD:Start(20.2-delay)
	timerSandstormCD:Start(30.3-delay)
end

function mod:SPELL_CAST_START(args)
	local spellId = args.spellId
	if spellId == 257092 then
		specWarnSandTrap:Show()
		specWarnSandTrap:Play("watchstep")
		timerSandTrapCD:Start()
	elseif spellId == 257608 then
		warnUpheavelCast:Show()
		timerUpheavelCD:Start()
	elseif spellId == 257495 then
		specWarnSandstorm:Show()
		specWarnSandstorm:Play("aesoon")
		timerSandstormCD:Start()
	end
end

function mod:CHAT_MSG_RAID_BOSS_EMOTE(msg, _, _, _, targetname)
	if msg:find("spell:257617") then
		if targetname then--Normal, only one person affected, name in emote
			if targetname == UnitName("player") then
				specWarnUpheavel:Show()
				specWarnUpheavel:Play("targetyou")
				yellUpheavel:Yell()
			else
				warnUpheavel:Show(targetname)
			end
		end
	end
end
