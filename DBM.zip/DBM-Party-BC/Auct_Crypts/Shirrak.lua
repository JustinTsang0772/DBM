local mod	= DBM:NewMod(523, "DBM-Party-BC", 7, 247)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20260523021914")
mod:DisableHardcodedOptions()
mod:SetCreatureID(18371)
mod:SetEncounterID(1890)
mod:SetZone(558)

if not mod:IsRetail() then
	mod:SetModelID(18916)
end

mod:RegisterCombat("combat")

mod:RegisterEventsInCombat(
	"CHAT_MSG_RAID_BOSS_EMOTE"
)

local warnFocusFire		= mod:NewTargetAnnounce(32300, 3)

local specWarnFocusFire	= mod:NewSpecialWarningDodge(32300, nil, nil, nil, 1, 2, nil, nil, "watchstep")

function mod:CHAT_MSG_RAID_BOSS_EMOTE(_, _, _, _, target)
	local targetname = DBM:GetUnitFullName(target) or target
	if targetname == UnitName("player") then
		specWarnFocusFire:Show()
		specWarnFocusFire:Play("watchstep")
	else
		warnFocusFire:Show(target)
	end
end
