local mod	= DBM:NewMod(570, "DBM-Party-BC", 4, 260)
local L		= mod:GetLocalizedStrings()

if mod:IsRetail() then
	mod.statTypes = "normal,heroic,timewalker"
end

mod:SetRevision("20260523021914")
mod:DisableHardcodedOptions()
mod:SetCreatureID(17941)
mod:SetEncounterID(1939)
mod:SetZone(547)

if not mod:IsRetail() then
	mod:SetModelID(17728)
	mod:SetModelOffset(-0.4, 0, -0.3)
end

mod:RegisterCombat("combat")

mod:RegisterEventsInCombat(
	"SPELL_SUMMON 31991 31985 34980"
)

--TODO, add a switch warning for the totem you actually want to kill (healing one probably)
local WarnStoneskinTotem		= mod:NewSpellAnnounce(31985, 2)
local WarnHealingWard			= mod:NewSpellAnnounce(34980, 3)

local specWarnCorruptedNova		= mod:NewSpecialWarningMove(31991, false, nil, nil, 1, 2, nil, nil, "runaway")

function mod:SPELL_SUMMON(args)
	if args.spellId == 31991 then
		specWarnCorruptedNova:Show()
		specWarnCorruptedNova:Play("runaway")
	elseif args.spellId == 31985 then
		WarnStoneskinTotem:Show()
	elseif args.spellId == 34980 then
		WarnHealingWard:Show()
	end
end
