local mod	= DBM:NewMod(528, "DBM-Party-BC", 1, 248)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20260523021914")
mod:DisableHardcodedOptions()
mod:SetCreatureID(17308)
mod:SetEncounterID(1891)
mod:SetUsedIcons(8)
mod:SetZone(543)

if not mod:IsRetail() then
	mod:SetModelID(18237)
	mod:SetModelOffset(-2, 0.8, -1)
end

mod:RegisterCombat("combat")

mod:RegisterEventsInCombat(
	"SPELL_AURA_APPLIED 37566",
	"SPELL_AURA_REMOVED 37566"
)

local warnBane      = mod:NewTargetAnnounce(37566)

local specwarnBane  = mod:NewSpecialWarningMoveAway(37566, nil, nil, nil, 1, 2, nil, nil, "runout")
local yellBane		= mod:NewYell(37566)

local timerBane     = mod:NewTargetTimer(15, 37566, nil, nil, nil, 3)

mod:AddSetIconOption("SetIconOnBaneTarget", 37566, true, 0, {8})


function mod:SPELL_AURA_APPLIED(args)
	if args.spellId == 37566 then
		timerBane:Start(args.destName)
		if self.Options.SetIconOnBaneTarget then
			self:SetIcon(args.destName, 8, 15)
		end
		if args:IsPlayer() then
            specwarnBane:Show()
            specwarnBane:Play("runout")
            yellBane:Yell()
		else
			warnBane:Show(args.destName)
        end
	end
end

function mod:SPELL_AURA_REMOVED(args)
	if args.spellId == 37566 then
		timerBane:Stop(args.destName)
		if self.Options.SetIconOnBaneTarget then
			self:SetIcon(args.destName, 0)
		end
	end
end
